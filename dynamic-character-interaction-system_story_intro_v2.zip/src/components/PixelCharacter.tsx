"use client";

import { useEffect, useRef, useState } from 'react';
import { EXPR_LABEL, type ExprId, type Look } from '@/lib/engine/types';

const FRAMES:Record<ExprId,number>={normal:0,smile:1,faint:2,confusion:3,surprise:4,unease:5,anxiety:6,anger:7,sadness:8,tension:9,suspicion:10,blank:11,agitation:12,deceit:13,blush:14,wink:15,thinking:3,excited:1,sleepy:11,relieved:2,pout:7,embarrassed:14};
const cache=new Map<string,Promise<HTMLImageElement>>();
function image(src:string):Promise<HTMLImageElement>{
  if(!cache.has(src))cache.set(src,new Promise((resolve,reject)=>{const img=new Image();img.onload=()=>resolve(img);img.onerror=()=>{cache.delete(src);reject(new Error('Portrait unavailable'));};img.src=src;}));
  return cache.get(src)!;
}
interface Props { look:Look; expr:ExprId; size?:number; glitch?:boolean; className?:string; talking?:boolean; name?:string; }
export function PixelCharacter({look,expr,size=280,glitch=false,className='',talking=false,name='キャラクター'}:Props){
  const canvas=useRef<HTMLCanvasElement>(null);
  const frames=useRef<HTMLImageElement[]>([]);
  const current=useRef(expr);
  const settings=useRef({look,expr,glitch,talking});
  settings.current={look,expr,glitch,talking};
  const [loaded,setLoaded]=useState(false);
  const portrait=look.portrait??(look.glasses?'peach':'lilac');
  useEffect(()=>{
    let live=true;setLoaded(false);
    Promise.all(Array.from({length:16},(_,i)=>image(`/portraits/${portrait}/${i}.webp`))).then(images=>{
      if(live){frames.current=images;setLoaded(true);}
    }).catch(()=>{});
    return()=>{live=false;};
  },[portrait]);
  useEffect(()=>{
    const ctx=canvas.current?.getContext('2d');if(!ctx)return;
    let raf=0,last=0,changed=0,old=expr,nextBlink=performance.now()+2200+Math.random()*2300,blinkUntil=0;
    const motion=!window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const draw=(t:number)=>{
      if(t-last<42){raf=requestAnimationFrame(draw);return;}last=t;
      const props=settings.current;
      const imgs=frames.current;
      if(imgs.length!==16){raf=requestAnimationFrame(draw);return;}
      if(current.current!==props.expr){old=current.current;current.current=props.expr;changed=t;}
      const progress=Math.min(1,(t-changed)/140);
      ctx.clearRect(0,0,256,256);ctx.imageSmoothingEnabled=false;
      const shake=motion&&props.expr==='agitation'?Math.round(Math.sin(t/70)*2):0;
      const breathe=motion?Math.round(Math.sin(t/980)*1.5):0;
      const nod=props.talking&&motion?Math.round(Math.sin(t/190)):0;
      ctx.save();ctx.translate(shake,breathe+nod);
      ctx.filter=`hue-rotate(${props.look.hue??0}deg) saturate(${props.look.saturation??100}%)`;
      if(progress<1){ctx.globalAlpha=1;ctx.drawImage(imgs[FRAMES[old]],0,0,256,256);ctx.globalAlpha=progress;}
      ctx.drawImage(imgs[FRAMES[props.expr]],0,0,256,256);ctx.globalAlpha=1;
      if(motion&&t>nextBlink){blinkUntil=t+(props.expr==='sleepy'?480:100);nextBlink=t+3100+Math.random()*3600;}
      if(t<blinkUntil&& !['smile','wink','sadness','anger','excited'].includes(props.expr)){
        ctx.save();ctx.beginPath();ctx.rect(57,96,58,48);ctx.rect(136,96,58,48);ctx.clip();ctx.drawImage(imgs[1],0,0,256,256);ctx.restore();
      }
      ctx.filter='none';
      if(props.expr==='excited'||props.expr==='wink'){
        ctx.fillStyle='#f6e9be';const sparkle=Math.floor(t/450)%2;ctx.fillRect(207,57+sparkle*2,3,9);ctx.fillRect(204,60+sparkle*2,9,3);
      }
      if(props.expr==='thinking'){
        ctx.fillStyle='#d5c7ef';for(let i=0;i<3;i++)if(Math.floor(t/400)%3>=i)ctx.fillRect(203+i*8,54,3,3);
      }
      if(props.glitch&&Math.floor(t/130)%17===0){ctx.fillStyle='rgba(177,205,238,.18)';ctx.fillRect(0,83,256,4);}
      ctx.restore();raf=requestAnimationFrame(draw);
    };
    raf=requestAnimationFrame(draw);return()=>cancelAnimationFrame(raf);
    // The animation consumes the latest props through settings.current.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);
  return <span className={`pixel-character ${className}`} role="img" aria-label={`${name}：${EXPR_LABEL[expr]}`} style={{width:size,height:size}}>
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src={`/portraits/${portrait}/${FRAMES[expr]}.webp`} alt="" width={256} height={256} style={{opacity:loaded?0:1,filter:`hue-rotate(${look.hue??0}deg) saturate(${look.saturation??100}%)`}} />
    <canvas ref={canvas} width={256} height={256} aria-hidden="true" style={{opacity:loaded?1:0}} />
  </span>;
}
