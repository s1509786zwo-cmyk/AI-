"use client";
import { useEffect,useRef,type ReactNode } from 'react';
import { X } from 'lucide-react';
export function Modal({title,kicker='A.I.D. / ZERO',children,onClose,actions,wide=false}:{title:string;kicker?:string;children:ReactNode;onClose:()=>void;actions?:ReactNode;wide?:boolean}){
  const ref=useRef<HTMLDivElement>(null);const close=useRef(onClose);close.current=onClose;
  useEffect(()=>{
    const before=document.activeElement as HTMLElement|null;
    const focus=()=>Array.from(ref.current?.querySelectorAll<HTMLElement>('button:not([disabled]), a[href], input, textarea, [tabindex="0"]')??[]);
    const key=(e:KeyboardEvent)=>{
      if(e.key==='Escape'){e.preventDefault();close.current();}
      if(e.key==='Tab'){const nodes=focus();const first=nodes[0],last=nodes[nodes.length-1];if(e.shiftKey&&document.activeElement===first){e.preventDefault();last?.focus();}else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first?.focus();}}
    };
    focus()[0]?.focus();document.addEventListener('keydown',key);const prev=document.body.style.overflow;document.body.style.overflow='hidden';
    return()=>{document.removeEventListener('keydown',key);document.body.style.overflow=prev;before?.focus();};
  },[]);
  return <div className="modal-backdrop" onMouseDown={e=>{if(e.target===e.currentTarget)onClose();}}><div ref={ref} role="dialog" aria-modal="true" aria-label={title} className={`modal ${wide?'wide':''}`}><div className="modal-header"><div><div className="eyebrow">{kicker}</div><h2>{title}</h2></div><button className="icon-button" onClick={onClose} aria-label="閉じる"><X size={16}/></button></div><div className="modal-body scroll-thin">{children}</div>{actions&&<div className="modal-actions">{actions}</div>}</div></div>;
}
