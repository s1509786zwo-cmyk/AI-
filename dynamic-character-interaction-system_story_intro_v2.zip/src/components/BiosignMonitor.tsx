"use client";
import { useEffect,useRef,useState } from 'react';
import { Activity,Eye,HeartPulse } from 'lucide-react';
interface Props {targetBpm:number;hrv:number;pupil:number;flat:boolean;name:string;role:string;}
function wave(p:number){if(p<.12)return 0;if(p<.2)return Math.sin((p-.12)/.08*Math.PI)*.1;if(p<.3)return 0;if(p<.34)return-.2*(p-.3)/.04;if(p<.38)return-.2+1.2*(p-.34)/.04;if(p<.44)return 1-1.3*(p-.38)/.06;if(p<.49)return-.3+.3*(p-.44)/.05;if(p<.6)return 0;if(p<.78)return Math.sin((p-.6)/.18*Math.PI)*.23;return 0;}
export function BiosignMonitor(props:Props){
  const canvas=useRef<HTMLCanvasElement>(null);const latest=useRef(props);latest.current=props;
  const [reading,setReading]=useState({bpm:props.targetBpm,pupil:props.pupil});
  useEffect(()=>{
    const ctx=canvas.current?.getContext('2d');if(!ctx)return;
    let raf=0,last=performance.now(),lastSample=last,lastRead=last,cur=latest.current.targetBpm,pupil=latest.current.pupil,phase=0;
    const trace=new Array(276).fill(0);
    const render=(t:number)=>{
      const dt=Math.min(.08,(t-last)/1000);last=t;
      const p=latest.current;
      cur+=(p.targetBpm-cur)*Math.min(1,dt*1.7);
      if(p.hrv>1)cur+=(Math.random()-.5)*p.hrv*dt*2;
      pupil+=(p.pupil-pupil)*Math.min(1,dt*2);
      phase=(phase+cur/60*dt)%1;
      if(t-lastSample>=36){trace.push(wave(phase));trace.shift();lastSample=t;}
      ctx.clearRect(0,0,280,64);ctx.fillStyle='#151d29';ctx.fillRect(0,0,280,64);
      ctx.fillStyle='#30423f65';for(let y=6;y<64;y+=12)for(let x=5;x<280;x+=12)ctx.fillRect(x,y,1,1);
      for(let i=1;i<trace.length;i++){const x=i+2;const y=36-Math.round(trace[i]*24);const oldY=36-Math.round(trace[i-1]*24);ctx.fillStyle=i>240?'#b4e5ce':'#799b91';ctx.fillRect(x,Math.min(y,oldY),1,Math.max(1,Math.abs(y-oldY)+1));}
      ctx.fillStyle='#c5f4dd';ctx.fillRect(277,36-Math.round(trace[275]*24),2,2);
      if(t-lastRead>250){setReading({bpm:cur,pupil});lastRead=t;}
      raf=requestAnimationFrame(render);
    };raf=requestAnimationFrame(render);return()=>cancelAnimationFrame(raf);
  },[]);
  return <div className="panel vitals-panel"><div className="panel-title"><span className="title-with-icon"><HeartPulse size={14} className="mint"/>生体モニター</span><span className="eyebrow">LIVE</span></div><div className="vital-primary"><div className="vital-value" aria-label={`心拍数 ${Math.round(reading.bpm)} BPM`}>{Math.round(reading.bpm)}<span>BPM</span></div><div className="vital-baseline">HEART RATE<br/>{props.role}</div></div><canvas ref={canvas} width={280} height={64} className="vital-ecg" aria-label="心電図の波形"/><div className="vital-secondary"><div><div className="vital-label"><Activity size={11}/>心拍変動</div><div className="vital-sub-value">{props.hrv.toFixed(1)}<span>ms</span></div></div><div><div className="pupil-indicator"><span style={{width:8+reading.pupil*15,height:8+reading.pupil*15}}/></div><div className="vital-label"><Eye size={11}/>瞳孔径</div><div className="vital-sub-value">{(1.8+reading.pupil*4.6).toFixed(1)}<span>mm</span></div><div className="pupil-state">{props.pupil<0.42?"収縮":props.pupil<0.62?"平常":"拡大"}</div></div></div></div>;
}
