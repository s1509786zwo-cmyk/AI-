import type { Classification } from './classify';
import type { CharDef } from './chargen';
import { contextualAnswer } from './conversation';
import { EXPR_LABEL, TYPE_LABEL, type Biosign, type CharState, type GameState, type Hold, type ReplyPlan } from './types';

export const TOTAL_QUESTIONS=25;
export function emptyCharState():CharState {
  return {claims:{},repeatText:{},questionCount:0,lastAnswer:'',lastTopic:'',lastTime:'night',peakBpm:0,flatCount:0,history:[],contradictions:[]};
}
export function emptyState():GameState {
  return {chars:{'1':emptyCharState(),'2':emptyCharState(),'3':emptyCharState()},notes:[],observations:[]};
}
export function loadState(json:string|null|undefined):GameState {
  try {
    const parsed=JSON.parse(json??'{}') as Partial<GameState>;
    const state=emptyState();
    for(const id of ['1','2','3'])state.chars[id]={...emptyCharState(),...parsed.chars?.[id]};
    state.notes=parsed.notes??[];state.observations=parsed.observations??[];state.decisions=parsed.decisions;
    return state;
  }catch{return emptyState();}
}
function vitalResponse(c:CharDef,cl:Classification,isAI:boolean):Biosign {
  const weights={provocation:1,accusation:.88,AI_detection:.75,contradiction:.73,alibi:.51,emotion:.44,memory:.28,family:.25,repeated_question:.48,reconfirm:.30,personal:.15,daily:.13,greeting:.08,unknown:.22,opening:.08};
  let stress=weights[cl.baseType];
  if(cl.topic==='compliment')stress=.32;
  if(cl.topic==='location'&&cl.timeBucket==='night')stress=.66;
  const gain=c.persona==='hot'?1.25:c.persona==='quiet'?.70:1;
  let bpm:number,hrv:number,pupil:number;
  if(!isAI){
    bpm=c.restBpm+stress*(28+Math.random()*16)*gain;
    hrv=2.5+Math.random()*3.1;pupil=.34+stress*.36+Math.random()*.07;
  } else if(c.aiStyle==='mechanical'){
    bpm=c.restBpm;hrv=.2+Math.random()*.25;pupil=.34;
  } else if(c.aiStyle==='humanlike'){
    bpm=c.restBpm+stress*(14+Math.random()*8);hrv=1.4+Math.random()*1.5;pupil=.37+stress*.22;
  } else {
    bpm=c.restBpm+stress*(12+Math.random()*17);hrv=1.1+Math.random()*1.6;pupil=.43+stress*.27;
  }
  return {bpm:Math.round(bpm*10)/10,hrv:Math.round(hrv*10)/10,pupil:Math.min(.85,Math.round(pupil*100)/100),flat:stress>.60&&Math.abs(bpm-c.restBpm)<3};
}
export function generateReply(c:CharDef,raw:string,cl:Classification,s:CharState,isAI:boolean,state:GameState):ReplyPlan {
  const result=contextualAnswer(c,raw,cl,s,isAI);
  const bio=vitalResponse(c,cl,isAI);
  const important=['alibi','provocation','contradiction','accusation','AI_detection'].includes(cl.baseType);
  const delay=isAI&&c.aiStyle==='mechanical'?430:Math.round((c.persona==='quiet'?730:c.persona==='hot'?300:490)+Math.random()*(isAI?470:720));
  let pre:Hold[];
  if(cl.topic==='compliment')pre=[{expr:'surprise',ms:220},{expr:'blush',ms:340}];
  else if(cl.baseType==='provocation')pre=[{expr:'surprise',ms:180},{expr:c.persona==='hot'?'tension':'unease',ms:360}];
  else if(cl.baseType==='alibi')pre=[{expr:'normal',ms:200+Math.round(Math.random()*120)},{expr:'thinking',ms:360},{expr:c.persona==='quiet'?'suspicion':'tension',ms:240}];
  else if(cl.baseType==='contradiction')pre=[{expr:'surprise',ms:200},{expr:'confusion',ms:380}];
  else if(cl.baseType==='AI_detection')pre=[{expr:'normal',ms:270},{expr:c.persona==='hot'?'suspicion':'unease',ms:300}];
  else pre=[{expr:cl.baseType==='daily'||cl.baseType==='memory'?'thinking':'normal',ms:180+Math.round(Math.random()*230)}];
  if(cl.repeatCount>=2)pre=[{expr:'confusion',ms:250},{expr:c.persona==='hot'?'anger':'pout',ms:300}];
  const segments:ReplyPlan['segments']=[{text:result.text}];
  if(isAI&&c.aiStyle==='emotive'&&cl.baseType==='AI_detection'&&s.history.filter(h=>h.type==='AI_detection').length===0){
    const at=result.text.indexOf('。');
    if(at>=0&&at<result.text.length-2)segments.splice(0,1,{text:result.text.slice(0,at+1)},{text:result.text.slice(at+1),before:{expr:'blank',ms:1250}});
  }
  const post:Hold[]=[{expr:result.expr,ms:430},{expr:important?'thinking':cl.topic==='compliment'?'embarrassed':'faint',ms:400}];
  const plan:ReplyPlan={delay,pre,segments,post,mainExpr:result.expr,bio,contradiction:result.contradiction,observed:important,glitch:false};
  const responseSeconds=(delay+pre.reduce((a,h)=>a+h.ms,0))/1000;
  if(result.contradiction)state.notes.unshift(`${c.name}：証言に矛盾を確認。直前のアリバイを訂正。`);
  if(important)state.notes.unshift(`${c.name}：${TYPE_LABEL[cl.baseType]}に${responseSeconds.toFixed(1)}秒で応答。BPM ${bio.bpm.toFixed(0)}（基準 ${c.restBpm}）／${EXPR_LABEL[result.expr]}。`);
  if(bio.flat)state.notes.unshift(`${c.name}：感情的な問いに対し、心拍・瞳孔の変動がほとんどない。`);
  state.notes=state.notes.slice(0,40);
  s.questionCount++;s.lastAnswer=result.text;s.lastTopic=cl.topic;s.lastBio=bio;s.peakBpm=Math.max(s.peakBpm,bio.bpm);if(bio.flat)s.flatCount++;
  s.history.push({question:raw,answer:result.text,topic:cl.topic,type:cl.baseType});
  s.repeatText[cl.refKey]??=result.text;
  return plan;
}
