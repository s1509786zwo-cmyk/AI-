import type { Bucket, QuestionType } from './types';

export interface Classification {
  type: QuestionType;
  baseType: QuestionType;
  topic: string;
  timeBucket?: Bucket;
  timeLabel?: string;
  refKey: string;
  repeatCount: number;
  quote?: string;
}
export function normalize(text:string):string {
  return text.normalize('NFKC').toLowerCase().replace(/[\s。、,.!?！？「」『』"']/g,'');
}
export function extractTime(raw:string): {bucket?:Bucket;label?:string} {
  const text=raw.normalize('NFKC');
  const match=text.match(/(\d{1,2})\s*(?:時|:)/);
  if(match) {
    let hour=Number(match[1]);
    if (/午後/.test(text)&&hour<12) hour+=12;
    hour%=24;
    return {bucket:hour<5?'late':hour<11?'morning':hour<16?'noon':hour<20?'evening':'night',label:`${hour}時`};
  }
  if(/夜中|深夜|明け方/.test(text))return{bucket:'late',label:'深夜'};
  if(/夕方|夕暮れ/.test(text))return{bucket:'evening',label:'夕方'};
  if(/昨夜|夜/.test(text))return{bucket:'night',label:'夜'};
  if(/昼|正午/.test(text))return{bucket:'noon',label:'昼'};
  if(/朝|午前/.test(text))return{bucket:'morning',label:'朝'};
  return{};
}
export function classifyQuestion(raw:string,past:string[]=[]):Classification {
  const q=raw.normalize('NFKC').trim();
  const key=normalize(q);
  const time=extractTime(q);
  let type:QuestionType='unknown';
  let topic='unknown';
  const is=(p:RegExp)=>p.test(q);
  const set=(t:QuestionType,s:string)=>{type=t;topic=s;};
  if(is(/クズ|くそ|バカ|馬鹿|アホ|くたばれ|ふざけんな|最低|糞|きしょ|消えろ|死ね|嘘つき|ウソつき|気持ち悪|まぬけ|ボケ|殺してやる|殴る|人間なわけない|人間のはずない|まがい物|偽物|いい加減にしろ|かわいくない/))set('provocation','insult');
  else if(is(/矛盾|さっき.*(?:違|言|答)|先ほど.*(?:言|答)|前と|話が違|食い違|嘘だった|証言.*変|言ってなかった/))set('contradiction','contradiction');
  else if(is(/(?:犯人|事件|フェイカー|殺戮).*(?:どう思|どう感じ|についてどう)/))set('emotion','crime_opinion');
  else if(is(/(?:なぜ|なんで|どうして).*(?:詳し|覚え|記憶)|そんなに.*(?:詳し|正確)|記憶.*完璧/))set('AI_detection','precision');
  else if(is(/心拍|脈拍|心臓|BPM|bpm|瞳孔|体温|呼吸|血は|血が/))set('AI_detection','body');
  else if(is(/(?:あなた|お前|君|きみ|自分).*(?:AI|ai|人間|フェイカー|機械|ロボット)|AIですか|aiですか|人工知能|フェイカーなの|フェイカーか|人間ですか|人間なの|人間か|ロボットなの/))set('AI_detection','identity');
  else if(is(/犯人|共犯|事件を起こ|殺した|人殺し|あなたがやった|お前がやった|怪しい|疑って/))set('accusation','accusation');
  else if(is(/かわいい|可愛い|綺麗|きれい|かっこいい|素敵|褒め|美しい/))set('emotion','compliment');
  else if(is(/ごめん|謝る|すみません|悪かった/))set('emotion','apology');
  else if(is(/^(こんにちは|おはよう|こんばんは|やあ|はじめまして|初めまして)/))set('greeting','greeting');
  else if(is(/ありがとう|助かった/))set('greeting','thanks');
  else if(is(/さようなら|さよなら|またね|ばいばい/))set('greeting','farewell');
  else if(/^(本当(に)?|ほんと(う)?(に)?|マジ(で)?|本当にそう|嘘じゃない)(ですか|か|なの|でしょう)?$/.test(key))set('reconfirm','reconfirm');
  else if(is(/本当.*(?:家|自宅|いた|外出)/))set('alibi','location');
  else if(is(/自己紹介|どんな人|あなたのことを教/))set('personal','introduction');
  else if(is(/眼鏡|メガネ|めがね/))set('personal','glasses');
  else if(is(/髪型|髪の色|髪|三つ編み|ツインテール/))set('personal','hair');
  else if(is(/服装|着ている|着てる|リボン|制服|衣装/))set('personal','outfit');
  else if(is(/性格|特徴|どんな性格/))set('personal','trait');
  else if(is(/(?:その時|そのとき|一緒|同席|誰と|だれと|一人だった|ひとりだった)/))set('alibi','companion');
  else if(is(/証拠|証明|レシート|領収|防犯|カメラ|目撃|裏付け|記録は/))set('alibi','evidence');
  else if(is(/好物|好きな.*(?:食|料理|ご飯)|食べ物.*好き|一番.*食|好き.*(?:ケーキ|ラーメン)/))set('personal','favorite_food');
  else if(is(/苦手.*(?:食|料理)|嫌い.*(?:食|料理)|食べられない/))set('personal','disliked_food');
  else if(is(/飲み物|飲みたい|コーヒー|紅茶|ココア|何を飲|何飲/))set('personal','drink');
  else if(is(/朝食|朝ごはん|朝ご飯/))set('daily','breakfast');
  else if(is(/昼食|昼ごはん|昼ご飯|昼飯/))set('daily','lunch');
  else if(is(/夕食|晩ごはん|晩ご飯|晩飯|夜ごはん|昨日.*食|何.*食べ|何食った/))set('daily','dinner');
  else if(is(/名前|お名前|誰です|だれです|何て呼|なんて呼/))set('personal','name');
  else if(is(/何歳|いくつ|年齢|歳は/))set('personal','age');
  else if(is(/家族|兄弟|姉妹|父|母|両親|妹|弟|兄|姉|子供|子ども/))set('family','family');
  else if(is(/結婚|恋人|彼氏|彼女|好きな人/))set('family','romance');
  else if(is(/出身|育った|故郷|生まれた場所/))set('personal','hometown');
  else if(is(/住所|住んで|住まい|どこに住/))set('personal','address');
  else if(is(/趣味|休日|休みの日|暇な時|何が好き|何するのが好き/))set('personal','hobby');
  else if(is(/本.*好き|好きな本|読書|どんな本/))set('personal','books');
  else if(is(/音楽|好きな曲|歌|楽器|ピアノ/))set('personal','music');
  else if(is(/好きな色|何色|色.*好き/))set('personal','color');
  else if(is(/ペット|猫|ねこ|犬|動物/))set('personal','pet');
  else if(is(/仕事|職業|働い|会社|職場/)&&!time.bucket)set('personal','job');
  else if(is(/夢|将来|やりたいこと|これから.*したい/))set('emotion','dream');
  else if(is(/子供の頃|子どもの頃|幼少|昔の.*思い出|一番.*思い出|小さい頃/))set('memory','childhood');
  else if(is(/怖|恐|不安|心配|大切|守りたい/))set('emotion','fear');
  else if(is(/事件.*思|犯人.*思|フェイカー.*思|殺戮.*思/))set('emotion','crime_opinion');
  else if(is(/どう思|気持ち|感情|悲しい|怒って|うれしい|嬉しい|嫌な/))set('emotion','feeling');
  else if(is(/覚え|忘れ|記憶|思い出/))set('memory','memory');
  else if(is(/眠|睡眠|寝た|寝て|夢を見/))set('daily','sleep');
  else if(is(/どこ|何して|何をして|いた|行って|外出|帰宅|帰った/)&&(/昨日|事件|当日|一昨日/.test(q)||!!time.bucket))set('alibi','location');
  else if(time.bucket&&q.length<18)set('alibi','location');
  else if(is(/好き|お気に入り/))set('personal','preference');
  else if(is(/空|天気|雨|晴れ/))set('daily','weather');
  else if(is(/どうしてここ|なんでここ|拘留|捕ま|ここに来/))set('emotion','detention');
  const baseType=type;
  const repeatCount=past.filter(p=>normalize(p)===key).length;
  if(repeatCount>0&&!['contradiction','reconfirm'].includes(type))type='repeated_question';
  const quote=q.match(/[「『"]([^」』"]{1,100})[」』"]/);
  return {type,baseType,topic,timeBucket:time.bucket,timeLabel:time.label,refKey:key,repeatCount,quote:quote?.[1]};
}
