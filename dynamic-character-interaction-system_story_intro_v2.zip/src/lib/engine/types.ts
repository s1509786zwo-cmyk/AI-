export type CharId = 1 | 2 | 3;
export type Gender = 'f' | 'm';
export type Persona = 'gentle' | 'hot' | 'quiet';
export type AiStyle = 'humanlike' | 'mechanical' | 'emotive';
export type Bucket = 'morning' | 'noon' | 'evening' | 'night' | 'late';
export type QuestionType = 'daily' | 'memory' | 'alibi' | 'emotion' | 'contradiction' | 'accusation' | 'AI_detection' | 'family' | 'personal' | 'repeated_question' | 'reconfirm' | 'greeting' | 'provocation' | 'unknown' | 'opening';
export type ExprId = 'normal' | 'smile' | 'faint' | 'confusion' | 'surprise' | 'unease' | 'anxiety' | 'anger' | 'sadness' | 'tension' | 'suspicion' | 'blank' | 'agitation' | 'deceit' | 'blush' | 'wink' | 'thinking' | 'excited' | 'sleepy' | 'relieved' | 'pout' | 'embarrassed';
export type HairStyle = 'longStraight' | 'bob' | 'twinTails' | 'wavyMid' | 'shortMessy' | 'shortNeat' | 'ponytail' | 'buzz';
export type OutfitStyle = 'sailor' | 'hoodie' | 'knit' | 'blazer' | 'guard';
export type AccStyle = 'clip' | 'ribbon' | 'band' | 'ahoge' | 'none';
export type PortraitId = 'lilac' | 'peach' | 'mint' | 'ivory' | 'ash' | 'blue' | 'rose' | 'noir';
export interface Look {
  portrait?: PortraitId;
  hue?: number;
  saturation?: number;
  skin: 'light' | 'fair' | 'tan';
  hair: HairStyle;
  hairColor: string;
  eyeColor: string;
  outfit: OutfitStyle;
  outfitColor: string;
  outfitSub: string;
  acc: AccStyle;
  accColor: string;
  glasses?: boolean;
  freckles?: boolean;
}
export interface Hold { expr: ExprId; ms: number; }
export interface Biosign { bpm: number; hrv: number; pupil: number; flat: boolean; }
export interface ReplyPlan {
  delay: number;
  pre: Hold[];
  segments: { text: string; before?: Hold }[];
  post: Hold[];
  mainExpr: ExprId;
  bio: Biosign;
  contradiction?: boolean;
  observed?: boolean;
  glitch?: boolean;
  note?: string;
}
export interface ConversationEntry { question: string; answer: string; topic: string; type: QuestionType; }
export interface CharState {
  claims: Record<string, string>;
  repeatText: Record<string, string>;
  questionCount: number;
  lastAnswer: string;
  lastTopic: string;
  lastTime: Bucket;
  peakBpm: number;
  flatCount: number;
  history: ConversationEntry[];
  contradictions: { topic: string; before: string; after: string }[];
  lastBio?: Biosign;
}
export interface Observation { requestId: string; answerId: string; suspect: CharId; plan: ReplyPlan; type: QuestionType; createdAt: string; }
export interface GameState {
  chars: Record<string, CharState>;
  notes: string[];
  observations: Observation[];
  decisions?: { slot: CharId; action: 'release' | 'execute' }[];
}
export const EXPR_LABEL: Record<ExprId, string> = {
  normal:'通常', smile:'笑顔', faint:'微笑み', confusion:'困惑', surprise:'驚き', unease:'不安', anxiety:'焦り', anger:'怒り', sadness:'悲しみ', tension:'緊張', suspicion:'疑い', blank:'無表情', agitation:'動揺', deceit:'ごまかし', blush:'照れ', wink:'ウインク', thinking:'考え中', excited:'うれしい', sleepy:'眠そう', relieved:'安堵', pout:'むくれ顔', embarrassed:'恥ずかしがり',
};
export const EXPRESSIONS = Object.keys(EXPR_LABEL) as ExprId[];
export const TYPE_LABEL: Record<QuestionType, string> = {
  daily:'日常・記憶', memory:'記憶確認', alibi:'アリバイ', emotion:'感情', contradiction:'矛盾追及', accusation:'直接追及', AI_detection:'自己認識', family:'家族', personal:'個人情報', repeated_question:'再質問', reconfirm:'再確認', greeting:'挨拶', provocation:'挑発', unknown:'自由会話', opening:'導入',
};
