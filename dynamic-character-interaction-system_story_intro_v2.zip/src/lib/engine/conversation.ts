import { characterVoice, type CharDef } from './chargen';
import type { Classification } from './classify';
import type { CharState, ExprId } from './types';

export interface ContextAnswer { text:string; expr:ExprId; contradiction?:boolean; }
export function contextualAnswer(c:CharDef,q:string,cl:Classification,s:CharState,isAI:boolean):ContextAnswer {
  const p=c.profile;
  const voice=(plain:string,polite?:string,short?:string)=>characterVoice(c,plain,polite,short);
  const mechanical=isAI&&c.aiStyle==='mechanical';
  const emotional=isAI&&c.aiStyle==='emotive';
  let expr:ExprId='normal';
  let text='';
  let contradiction=false;
  const prior=s.history[s.history.length-1];
  const soft=c.persona==='gentle';
  const fierce=c.persona==='hot';
  const quoted=(t:string)=>`「${t.length>60?t.slice(0,60)+'…':t}」`;
  switch(cl.topic) {
    case 'introduction':
      text=voice(`${c.name}。${c.age}歳で、${c.job}をしてるよ。好きなのは${p.hobby}。${soft?'気軽に話してくれたら、うれしい。':fierce?'……ちゃんと覚えておいてね。':'話すのは、ゆっくりだけど。'}`,`${c.name}と申します。${c.age}歳、${c.job}です。趣味は${p.hobby}です。`,`${c.name}。${c.job}。`);expr='faint';break;
    case 'glasses':
      text=c.look.glasses?voice('このメガネ？ 小さい文字を読む時に、必要なんだ。外すと相手の表情も見えづらいよ。','小さな文字を読むためのメガネです。ここで相手の顔が見えないのは、少し怖いです。','読む時に、必要。'):voice('メガネはかけてないよ。目は、今のところ困ってない。','私はメガネをかけていません。今のところ、視力には困っていません。','かけてない。');expr='thinking';break;
    case 'hair': {
      const hairstyles:Record<string,string>={lilac:'淡いラベンダー色の、ふわっとした髪',peach:'桃色のツインテール',mint:'青みがかった髪の三つ編み',ivory:'白金色の長い髪',ash:'灰色の短い髪',blue:'淡い青色の髪',rose:'淡い桃色の髪',noir:'後ろでまとめた黒っぽい髪'};
      const description=hairstyles[c.look.portrait??'lilac'];text=voice(`${description}だよ。${soft?'朝、鏡の前で少し整えるのが好き。':fierce?'……そんなに、じっと見ないで。':'慣れてるから、あまり変えたくない。'}`,`${description}です。気に入っています。`,`${description}。`);expr='blush';break;
    }
    case 'outfit': {
      const outfits={sailor:'襟とリボンのある服',hoodie:'いつものパーカー',knit:'柔らかいカーディガン',blazer:'シャツとベスト',guard:'仕事用の上着'};
      const clothing=outfits[c.look.outfit];text=voice(`${clothing}。${fierce?'自分が着たいから着てる。そこまで疑わなくてもいいでしょ。':'この服だと、少し落ち着くんだ。制服みたいでも、ここに来るために選んだわけじゃないよ。'}`,`${clothing}です。着慣れたものを選んでいます。`,`${clothing}。`);expr='faint';break;
    }
    case 'trait':text=voice(`よく「${c.personaLabel}」って言われる。${c.trait}のは、自分でもそうだと思う。${fierce?'だからって、悪い人だと決めつけないで。':''}`,`「${c.personaLabel}」と言われます。${c.trait}ところがあります。`,`${c.personaLabel}、らしい。`);expr='thinking';break;
    case 'name':
      text=voice(`${c.name}だよ。${/年齢|歳|いくつ/.test(q)?`${c.age}歳。`:''}名字でも名前でも、呼びやすい方で呼んで。`,`${c.name}です。${/年齢|歳|いくつ/.test(q)?`${c.age}歳です。`:''}そう呼んでください。`,`${c.name}。`);expr='faint';break;
    case 'age':text=voice(`${c.age}歳だよ。見えない？`,`${c.age}歳です。`,`${c.age}歳。`);break;
    case 'job':text=voice(`${c.job}をしてるよ。${soft?'誰かの暮らしに、少しでも役立てたらいいな。':fierce?'仕事には手を抜かない。そこは覚えておいて。':'目立たないけど、嫌いな仕事じゃない。'}`,`職業は${c.job}です。${soft?'好きな仕事なんです。':'仕事は、きちんとやっています。'}`,`${c.job}。`);expr='faint';break;
    case 'favorite_food':text=voice(`${p.favoriteFood}が好き。${soft?'小さな楽しみくらい、あってもいいでしょ？':fierce?'……意外？ 別に好きでもいいでしょ。':'それがある日は、ちょっといい日。'}`,`${p.favoriteFood}が好きです。見つけると、つい買ってしまいます。`,`${p.favoriteFood}。……好き。`);expr='excited';break;
    case 'disliked_food':text=voice(`${p.dislikedFood}は苦手。食べられないわけじゃないけど、できれば避けたい。`,`${p.dislikedFood}は少し苦手です。`,`${p.dislikedFood}。`);expr='pout';break;
    case 'drink':text=voice(`${p.drink}が好きだよ。${/コーヒー/.test(q)&&p.drink!=='ブラックコーヒー'?'コーヒーより、そっちを選ぶかな。':'温かいのを、ゆっくり飲むのが好き。'}`,`私は${p.drink}をよく飲みます。${/コーヒー/.test(q)?'コーヒーだけとは限らないです。':'温かい飲み物が好きです。'}`,`${p.drink}。`);expr='faint';break;
    case 'dinner':case 'lunch':case 'breakfast': {
      const meal=cl.topic==='dinner'?p.dinner:cl.topic==='lunch'?p.lunch:p.breakfast;
      const label=cl.topic==='dinner'?'夕食':cl.topic==='lunch'?'昼食':'朝食';
      const time=cl.topic==='dinner'?p.mealTime:cl.topic==='lunch'?'12時18分':'7時26分';
      s.claims[cl.topic]=meal;
      text=mechanical?voice(`昨日の${label}は${time}に${meal}。`,`昨日の${label}は${time}、${meal}でした。`):isAI?voice(`昨日の${label}？ ${meal}だよ。${c.aiStyle==='humanlike'?'たぶん、'+time+'くらい。':'それを聞かれて、少し懐かしく感じた。'}`,`昨日の${label}は${meal}でした。時刻は${time}だったと思います。`):voice(`昨日の${label}……えっと、${meal}だったと思う。${fierce?'細かい時間までは、覚えてないよ。':'細かいことを聞かれると、自信がなくなるね。'}`,`昨日の${label}は……${meal}だったと思います。時間までは、はっきり覚えていません。`,`${meal}。……だったと思う。`);
      expr=mechanical?'normal':'thinking';break;
    }
    case 'family': {
      const members=p.family.join('と');
      const count=p.family.length+1;
      const detail=/何人|人数/.test(q)?`自分を入れて${count}人。`:'';
      text=voice(`${members}がいるよ。${detail}${/母|父|思い出|仲/.test(q)?p.familyMemory+'。':'今も、ちゃんと覚えてる。'}`,`${members}がいます。${/何人|人数/.test(q)?`私を含めて${count}人です。`:''}${/母|父|思い出|仲/.test(q)?p.familyMemory+'んです。':'家族を心配させたくありません。'}`,`${members}。${detail}`);expr=/思い出|母/.test(q)?'faint':'unease';s.claims.family=members;break;
    }
    case 'romance':text=voice('恋人はいないよ。……ここで聞くこと？ ちょっと恥ずかしい。','恋人はいません。あまり、個人的なことは……。','……いない。');expr='blush';break;
    case 'hometown':text=voice(`${p.hometown}の出身だよ。${p.childhood}。`,`${p.hometown}で育ちました。${p.childhood}んです。`,`${p.hometown}。`);expr='faint';break;
    case 'address':text=voice(`${p.address}に住んでる。細かい番地まで、言わなきゃだめ？`,`${p.address}に住んでいます。番地まで公開するのは、少し怖いです。`,`${p.address}。`);expr='suspicion';break;
    case 'hobby':text=voice(`趣味は${p.hobby}。${p.hobbyDetail}。`,`${p.hobby}が趣味です。${p.hobbyDetail}んです。`,`${p.hobby}。`);expr='excited';break;
    case 'books':text=voice(`古い本が好き。${p.hobby==='古い本を集めること'?p.hobbyDetail:'新品より、誰かが読んだ跡の残った本に惹かれる'}。`,'古い本が好きです。ページに誰かの暮らしが残っている気がして。','古い本。');expr='faint';break;
    case 'music':text=voice(`${p.music}をよく聴く。${p.hobby==='ピアノ'?'自分でも弾くよ。音を出すと、気持ちが少し整理できる。':'騒がしい街から、ちょっとだけ離れられる気がする。'}`,`${p.music}が好きです。${p.hobby==='ピアノ'?'ピアノも弾きます。':'静かな時間に聴いています。'}`,`${p.music}。`);expr='faint';break;
    case 'color':text=voice(`${p.favoriteColor}が好き。夜の街で見つけると、少しだけうれしい。`,`${p.favoriteColor}が好きです。`,`${p.favoriteColor}。`);expr='smile';break;
    case 'pet':text=p.pet==='ペットはいない'?voice('ペットはいない。でも、駅の裏の猫には会いに行くよ。','ペットは飼っていません。猫は好きです。','飼ってない。'):voice(`${p.pet}がいるよ。今ごろ、誰もいない部屋で待ってる。`,`${p.pet}を飼っています。早く帰ってあげたいです。`,`${p.pet}。`);expr='unease';break;
    case 'dream':text=voice(`夢は、${p.dream}。こんな街でも、そのくらいは願っていいよね。`,`${p.dream}が夢です。まだ、あきらめていません。`,`${p.dream}。`);expr='relieved';break;
    case 'childhood':text=voice(`${p.childhood}。${mechanical?'当時の年齢は8歳4か月、日時も記憶している。':'変な話、細かいことよりその時の匂いを覚えてるんだ。'}`,`${p.childhood}んです。${mechanical?'当時の日時も答えられます。':'細かい日時より、その時の感覚を覚えています。'}`,`${p.childhood}。`);expr='thinking';break;
    case 'location': {
      const time=cl.timeBucket??'night';s.lastTime=time;
      const schedule=p.schedule[time];
      const claimKey=`alibi:${time}`;
      const previous=s.claims[claimKey];
      let location=previous??schedule.location;
      if(previous&&cl.repeatCount===0&&s.questionCount>=4&&time==='night'&&Math.random()<(!isAI?.18:c.aiStyle==='emotive'?.13:0)&&previous===schedule.location) {
        location=schedule.location==='自宅'?'駅前のカフェ':'自宅';
        contradiction=true;s.contradictions.push({topic:claimKey,before:previous,after:location});
      }
      s.claims[claimKey]=location;
      const when=cl.timeLabel??(time==='night'?'昨夜':time==='late'?'深夜':'その時間');
      text=voice(`${contradiction?'……待って、思い出した。':''}${when}は${location}にいたよ。${location===schedule.location?schedule.activity+'。':'さっきは、帰った後の話と混ざったかもしれない。'}`,`${contradiction?'……訂正させてください。':''}${when}は${location}にいました。${location===schedule.location?schedule.activity+'んです。':'先ほどの証言と、時刻を取り違えたようです。'}`,`${location}。${contradiction?'……さっきの話を、訂正する。':''}`);
      if(mechanical)text=voice(`${when}は${location}。基準時刻は${schedule.time}。`,`${when}は${location}です。確認時刻は${schedule.time}です。`);
      expr=contradiction?'agitation':time==='night'?'tension':'thinking';break;
    }
    case 'companion': {
      const place=s.claims[`alibi:${s.lastTime}`]??p.schedule[s.lastTime].location;
      text=p.companion==='一人'?voice(`${place}では、一人だったよ。証明してくれる人はいない。`,`${place}では一人でした。誰かの証言は、出せません。`):voice(`${place}では${p.companion}の${p.companionName}と一緒だった。本人に確認してくれてもいいよ。`,`${p.companion}の${p.companionName}と、${place}で一緒にいました。確認していただいて構いません。`);
      expr='thinking';break;
    }
    case 'evidence': {
      const e=p.schedule[s.lastTime].evidence;
      text=voice(`${e}が残ってるはず。それは、確認してくれた？`,`${e}を確認していただければと思います。ただ、それだけで私が人間だとは証明できませんね。`,`${e}。`);expr='suspicion';break;
    }
    case 'contradiction': {
      if(cl.quote&&!s.history.some(h=>h.answer.includes(cl.quote!)))text=voice(`${quoted(cl.quote)}とは言ってないよ。${prior?`さっき話したのは${quoted(prior.answer)}。`:'記録を確認してみて。'}`,`${quoted(cl.quote)}とは、まだ話していません。記録を確認してください。`);
      else if(s.contradictions.length) {
        const d=s.contradictions[s.contradictions.length-1];
        text=voice(`うん……${d.before}と話したのに、後で${d.after}と言ったね。${mechanical?'後の発言に訂正する。':'取り調べで混乱して、時間を取り違えた。ごめん。'}`,`確かに、先ほどは${d.before}、後には${d.after}と答えました。時間を取り違えました。訂正します。`);expr=fierce?'anger':'embarrassed';
      } else text=voice(`どの部分？ ${prior?`さっきは${quoted(prior.answer)}と話したよ。`:'まだ、具体的な証言はしてないよ。'}食い違っているなら、そこを教えて。`,`${prior?`先ほどは${quoted(prior.answer)}と答えました。`:'まだ具体的な証言はしていません。'}どの部分が違うのでしょうか。`);
      if(expr==='normal')expr=fierce?'suspicion':'confusion';break;
    }
    case 'reconfirm':text=prior?voice(`${quoted(prior.answer)}のこと？ ${mechanical?'その回答に訂正はない。':'うん、今覚えているのは、その通りだよ。'}`,`先ほどの${quoted(prior.answer)}という回答ですか。今の記憶では、その通りです。`):voice('まだ何も話してないよ。何について確かめたい？','何についての確認でしょうか。');expr='thinking';break;
    case 'precision':text=mechanical?voice('記憶はすべて照合できる。何分何秒でも答えられるよ。','記憶に欠損はありません。必要な時刻を指定してください。'):isAI?voice('細かく覚えてると、疑われるんだね。……忘れた方が、人間らしいの？','詳しく覚えているだけで、疑われるのですか。'):voice('そんなに詳しかった？ 印象に残った部分だけだよ。曖昧なことも、ある。','印象に残っている部分だけです。すべてを正確に覚えているわけではありません。');expr='suspicion';break;
    case 'body':text=voice(`${/瞳孔/.test(q)?'目をそんなに見られると、落ち着かない。':/呼吸/.test(q)?'ちゃんと息はしてるよ。いま、少し浅いかもしれない。':'心臓は動いてるよ。ここに来てから、ずっと落ち着かない。'}${mechanical?'……計測値は安定している。':''}`,`${/瞳孔/.test(q)?'目を見られるのは、少し落ち着きません。':'心臓は動いています。数値だけで決めないでください。'}`);expr='unease';break;
    case 'identity':text=voice(fierce?'人間だよ。……何を見れば、信じてくれるわけ？':'人間だよ。家族も、思い出もある。……それじゃ、足りないの？','私は人間です。家族も、思い出もあります。それでは、証明にならないのですね。','……人間。');expr=fierce?'anger':isAI?'deceit':'unease';break;
    case 'accusation':text=voice(fierce?'証拠もないのに、決めつけるなよ。人を殺したりしてない。':'違うよ……誰かを傷つけたことなんてない。お願い、話を聞いて。','私は事件を起こしていません。決めつけずに、話を聞いてください。','……やってない。');expr=fierce?'anger':'sadness';break;
    case 'insult':text=voice(fierce?'その言い方、取り消して。人間かどうかと、人を傷つけることは別でしょ。':soft?'……そういう言葉は、傷つくよ。ちゃんと話してるのに。':'……聞こえてる。傷つかないわけじゃない。','その言葉は、傷つきます。尋問には答えますが、侮辱まで受け入れたくありません。','……傷つく。');expr=fierce?'anger':soft?'sadness':'agitation';break;
    case 'compliment':text=voice(soft?'……えっ。そんなこと、ここで言われると思わなかった。ありがとう。':fierce?'急に何？ ……べ、別にうれしくない、とは言ってない。':'……ありがとう。そう言われると、目を合わせにくい。','ありがとうございます……。こんな場所で言われるとは、思いませんでした。','……ありがとう。');expr=fierce?'pout':'blush';break;
    case 'apology':text=voice('うん……わかってくれたなら、大丈夫。もう少し普通に話そう。','ありがとうございます。では、落ち着いてお話ししましょう。');expr='relieved';break;
    case 'fear':text=voice(`怖いのは、${p.fear}。${fierce?'強がってたって、そのくらいは怖い。':'見た目じゃ分からないなんて、本当に怖いね。'}`,`${p.fear}が怖いです。ここに来てから、ずっと考えています。`,`${p.fear}。`);expr='unease';break;
    case 'crime_opinion':text=voice('フェイカーに誰かを奪われるのも、疑われただけで人間が処分されるのも、嫌だよ。あなたはどう思う？','殺戮は恐ろしいです。でも、間違って人間を処分することも、同じくらい恐ろしいと思います。');expr='sadness';break;
    case 'feeling':text=voice(`今は${fierce?'腹が立ってる。でも、本当は怖いんだよ。':soft?'不安だよ。誰かの顔を見て、普通に話したかった。':'静かにしてるけど、平気なわけじゃない。'}`,`今は不安です。${p.fear}が、頭から離れません。`);expr=fierce?'anger':'unease';break;
    case 'memory':text=voice(`何を思い出してほしい？ ${prior?`さっきの${prior.topic==='location'?'アリバイ':'話'}なら、まだ覚えてる。`:'家族のことでも、昨日のことでも話せるよ。'}`,`何についての記憶でしょうか。${prior?'先ほどのお話なら、覚えています。':'具体的に聞いていただければ、お答えします。'}`);expr='thinking';break;
    case 'sleep':text=voice(`昨日は23時くらいに寝たよ。${mechanical?'正確には23時12分。':'でも、すぐ眠れたかは覚えてない。'}`,`昨夜は23時ごろに休みました。${mechanical?'正確には23時12分です。':'寝つきは良くありませんでした。'}`);expr='sleepy';break;
    case 'weather':text=voice('昨日は雨だったね。窓に当たる音だけは覚えてる。天気の記憶で、何かわかる？','昨日は雨でした。窓に当たる音を覚えています。');expr='thinking';break;
    case 'detention':text=voice('顔が、事件の映像と似てたんだって。それだけでここに連れてこられた。……怖いよ。','事件映像に似た人物が映っていた、と聞きました。詳しい理由は説明されていません。');expr='sadness';break;
    case 'greeting':text=voice('こんにちは。……せめて、普通の会話から始めようか。','こんにちは。どうぞ、お手柔らかにお願いします。');expr='faint';break;
    case 'thanks':text=voice('どういたしまして。少しでも、伝わったならうれしい。','どういたしまして。話を聞いてくださって、ありがとうございます。');expr='smile';break;
    case 'farewell':text=voice('またね……。本当に、ここから出られるといいな。','またお会いできるといいですね。今度は、外で。');expr='relieved';break;
    case 'preference':text=voice(`好きなもの？ ${p.hobby}と、${p.favoriteFood}。${p.hobbyDetail}。`,`好きなものは${p.hobby}と${p.favoriteFood}です。`);expr='faint';break;
    default: {
      const subject=q.replace(/[？?！!]/g,'').slice(0,45);
      text=voice(fierce?`${quoted(subject)}って、どういう意味？ ${c.job}に関係する話ならわかるけど、適当な答えは言いたくない。`:soft?`${quoted(subject)}について、何を知りたいの？ ${c.job}として知っていることなら話せるよ。${prior?'さっきの話の続き？':''}`:`${quoted(subject)}……。具体的に、どの部分を答えればいい？`,`「${subject}」ですね。具体的に何について知りたいのでしょうか。${c.job}として経験したことなら、お話しできます。`);expr='confusion';
    }
  }
  if(cl.repeatCount>0) {
    if(mechanical&&s.repeatText[cl.refKey])return{text:s.repeatText[cl.refKey],expr:'normal'};
    if(cl.repeatCount>=3&&fierce)return{text:voice('何度も同じことを聞かないで。答えは変わらない。','同じ質問には、もう答えたくありません。'),expr:'anger'};
    const reminder=cl.repeatCount>=2?voice('……さっきも答えたよ。もう一度言うけど、','先ほどもお答えしましたが、'):voice('あ、それはさっきも聞かれたね。','あ、先ほども聞かれましたね。');
    text=reminder+text;expr=cl.repeatCount>=2?'pout':'confusion';
  }
  return{text,expr,contradiction};
}
