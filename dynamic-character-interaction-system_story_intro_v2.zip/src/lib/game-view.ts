import { loadCast, publicCharacter, type PublicCharacter } from '@/lib/engine/chargen';
import { loadState } from '@/lib/engine/generate';
import type { Biosign, CharId, ExprId, QuestionType, ReplyPlan } from '@/lib/engine/types';
import type { games, messages } from '@/db/schema';
export interface GameMessage { id:string; suspect:CharId; role:'player'|'suspect'; content:string; type:QuestionType; expr:ExprId; delayMs:number; bio?:Biosign; timeline?:ReplyPlan; contradiction:boolean; observed:boolean; createdAt:string; }
export interface Metric { questions:number; average:number; peak:number; flatCount:number; contradictions:number; bio?:Biosign; }
export interface GameCase {
  id:string; status:string; usedQuestions:number; totalQuestions:number; cast:PublicCharacter[]; notes:string[]; metrics:Record<string,Metric>;
  decisions?:{slot:CharId;action:'release'|'execute'}[];
  isCorrect:boolean|null;
  reveal?:{aiSuspect:CharId;style:string;clues:string[]};
}
export function toGameView(g:typeof games.$inferSelect,list:(typeof messages.$inferSelect)[]):{game:GameCase;messages:GameMessage[]} {
  const cast=loadCast(g.suspects);
  const state=loadState(g.stateJson);
  const metrics:Record<string,Metric>={};
  for(const id of ['1','2','3']){
    const cs=state.chars[id];
    const turns=state.observations.filter(o=>String(o.suspect)===id);
    metrics[id]={questions:cs.questionCount,average:turns.length?turns.reduce((a,o)=>a+o.plan.delay+o.plan.pre.reduce((x,h)=>x+h.ms,0),0)/turns.length:0,peak:cs.peakBpm,flatCount:cs.flatCount,contradictions:cs.contradictions.length,bio:cs.lastBio};
  }
  const game:GameCase={id:g.id,status:g.status,usedQuestions:g.usedQuestions,totalQuestions:g.totalQuestions,cast:cast.map(publicCharacter),notes:state.notes,metrics,isCorrect:g.isCorrect,decisions:state.decisions};
  if(g.status==='verdict')game.reveal={aiSuspect:g.aiSuspect as CharId,style:cast[g.aiSuspect-1].aiStyleLabel,clues:cast[g.aiSuspect-1].aiReveal};
  return {game,messages:list.map(m=>{
    const observation=state.observations.find(o=>o.answerId===m.id);
    return{id:m.id,suspect:m.suspect as CharId,role:m.role as 'player'|'suspect',content:m.content,type:(m.questionType??'opening') as QuestionType,expr:(m.expr??'normal') as ExprId,delayMs:m.delayMs??0,bio:observation?.plan.bio,timeline:observation?.plan,contradiction:m.contradiction,observed:m.observed,createdAt:m.createdAt.toISOString()};
  })};
}
