import { drizzle } from "drizzle-orm/node-postgres";
import { Pool } from "pg";

const databaseUrl = process.env.DATABASE_URL;

if (!databaseUrl) {
  throw new Error("DATABASE_URL is required");
}

const globalForDb = globalThis as typeof globalThis & {
  __arenaNextJsPostgresqlPool?: Pool;
};

export const pool =
  globalForDb.__arenaNextJsPostgresqlPool ??
  new Pool({
    connectionString: databaseUrl,
    max: 10,
    connectionTimeoutMillis: 6000,
    idleTimeoutMillis: 30000,
  });

/* 待機中の接続エラーを無視してプール自体を生かす */
pool.on("error", () => {
  /* client is recreated automatically */
});

if (process.env.NODE_ENV !== "production") {
  globalForDb.__arenaNextJsPostgresqlPool = pool;
}

export const db = drizzle(pool);

/* サーバー起動時にテーブルを自動作成する（DBリセット後も自己修復） */
const SCHEMA_SQL = `
CREATE TABLE IF NOT EXISTS "games" (
  "id" text PRIMARY KEY,
  "ai_suspect" integer NOT NULL,
  "suspects" text NOT NULL DEFAULT 'hikari,ren,yuki',
  "total_questions" integer NOT NULL DEFAULT 25,
  "used_questions" integer NOT NULL DEFAULT 0,
  "status" text NOT NULL DEFAULT 'interrogating',
  "verdict_suspect" integer,
  "is_correct" boolean,
  "state_json" text NOT NULL DEFAULT '{}',
  "created_at" timestamp NOT NULL DEFAULT now(),
  "updated_at" timestamp NOT NULL DEFAULT now()
);
CREATE TABLE IF NOT EXISTS "messages" (
  "id" text PRIMARY KEY,
  "game_id" text NOT NULL REFERENCES "games"("id") ON DELETE CASCADE,
  "suspect" integer NOT NULL,
  "role" text NOT NULL,
  "content" text NOT NULL,
  "question_type" text,
  "delay_ms" integer,
  "expr" text,
  "contradiction" boolean NOT NULL DEFAULT false,
  "observed" boolean NOT NULL DEFAULT false,
  "created_at" timestamp NOT NULL DEFAULT now()
);`;

let schemaReady: Promise<void> | null = null;
export function ensureSchema(): Promise<void> {
  if (!schemaReady) {
    schemaReady = pool.query(SCHEMA_SQL).then(
      () => undefined,
      (e) => {
        schemaReady = null;
        throw e;
      },
    );
  }
  return schemaReady;
}
