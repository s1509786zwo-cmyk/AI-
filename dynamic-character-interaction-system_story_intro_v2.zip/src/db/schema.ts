import { pgTable, text, integer, boolean, timestamp } from "drizzle-orm/pg-core";

export const games = pgTable("games", {
  id: text("id").primaryKey(),
  aiSuspect: integer("ai_suspect").notNull(),
  suspects: text("suspects").notNull().default("hikari,ren,yuki"),
  totalQuestions: integer("total_questions").notNull().default(25),
  usedQuestions: integer("used_questions").notNull().default(0),
  status: text("status").notNull().default("interrogating"),
  verdictSuspect: integer("verdict_suspect"),
  isCorrect: boolean("is_correct"),
  stateJson: text("state_json").notNull().default("{}"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
  updatedAt: timestamp("updated_at").notNull().defaultNow(),
});

export const messages = pgTable("messages", {
  id: text("id").primaryKey(),
  gameId: text("game_id")
    .notNull()
    .references(() => games.id, { onDelete: "cascade" }),
  suspect: integer("suspect").notNull(),
  role: text("role").notNull(),
  content: text("content").notNull(),
  questionType: text("question_type"),
  delayMs: integer("delay_ms"),
  expr: text("expr"),
  contradiction: boolean("contradiction").notNull().default(false),
  observed: boolean("observed").notNull().default(false),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});
