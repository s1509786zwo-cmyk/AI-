import type { Metadata } from "next";
import type { ReactNode } from "react";
import { DotGothic16, Noto_Sans_JP } from "next/font/google";
import "./globals.css";

const dot = DotGothic16({
  weight: "400",
  variable: "--font-dotg",
  display: "swap",
});

const noto = Noto_Sans_JP({
  weight: ["400", "500", "700"],
  variable: "--font-noto",
  display: "swap",
});

export const metadata: Metadata = {
  title: "尋問室・ゼロ ／ 対AI尋問局 A.I.D.",
  description:
    "20XX年、人間の皮膚と偽造記憶を持つ暴走AI〈フェイカー〉。自由入力の尋問と生体モニターで、3人の中に混じる1体を判別せよ。人間を処刑しても、フェイカーを釈放しても任務失敗。",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="ja">
      <body className={`${dot.variable} ${noto.variable} bg-bg0 text-ink antialiased`}>
        {children}
      </body>
    </html>
  );
}
