"use client";
import { useEffect,useRef,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowRight,RefreshCw,MessageSquare,HeartPulse,ScanFace,Sparkles,LoaderCircle,UsersRound } from 'lucide-react';
import { Header } from '@/components/Header';
import { PixelCharacter } from '@/components/PixelCharacter';
import { generateCharacter,generateCast,type PublicCharacter } from '@/lib/engine/chargen';
import { EXPR_LABEL,type ExprId,type Look } from '@/lib/engine/types';
import type { GameCase } from '@/lib/game-view';

const defaultLook:Look={portrait:'lilac',hue:0,saturation:100,skin:'light',hair:'wavyMid',hairColor:'#b7abdd',eyeColor:'#c6b5e7',outfit:'sailor',outfitColor:'#c5c4dd',outfitSub:'#403f60',acc:'clip',accColor:'#eee7f6'};
const fallback:PublicCharacter={id:'preview',name:'白瀬 ゆき',age:23,job:'電脳書庫司書',gender:'f',persona:'quiet',personaLabel:'もの静か',speechId:'shy',speechLabel:'控えめ・人見知り',trait:'思い出には少し饒舌',look:defaultLook,opening:'……何から、話せばいいですか。',openingExpr:'normal',idleExpr:'normal',restBpm:72};
const cycle:ExprId[]=['normal','faint','blush','thinking','normal','wink'];
export default function Home(){
  const router=useRouter();const [cast,setCast]=useState<PublicCharacter[]>([]);const [selected,setSelected]=useState(0);const [expr,setExpr]=useState<ExprId>('normal');const [active,setActive]=useState<GameCase|null>(null);const [starting,setStarting]=useState(false);const [error,setError]=useState('');
  const [intro,setIntro]=useState(true);const [introText,setIntroText]=useState('');const [introDone,setIntroDone]=useState(false);const [introSound,setIntroSound]=useState(false);
  const introAudio=useRef<AudioContext|null>(null);const introSoundRef=useRef(false);introSoundRef.current=introSound;const introTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const story=[
    '20XX年。人類は「完璧な人間」を模倣する人工知能――通称『フェイカー』を作り上げた。',
    'しかし、その鏡は歪み始めた。',
    '人類の存続及び救済として、フェイカーによる連続無差別殺人事件が多発。彼らは皮膚、声、そして「涙」すら模倣し、市民の中に潜んでいる。',
    '政府は特別治安機関『A.I.D.』を設立。捕らえた容疑者が「人間」か「フェイカー」かを鑑別する『人間判定プロトコル』を始動した。',
    'あなたが配属されたのは、最前線――第7尋問室。',
    '【警告】尋問対象（フェイカー）への同情や長時間の対話は、あなたの脳に『認知汚染』を引き起こします。判定ミスが続いた場合、治安局の規定によりあなたの【記憶フォーマット（記憶消去）】が実行されます。',
    '――心拍数と証拠だけを信じろ。尋問を開始します。',
  ];
  const typeSound=()=>{
    try{
      const ctx=introAudio.current??new AudioContext();introAudio.current=ctx;
      if(ctx.state==='suspended')void ctx.resume();
      const o=ctx.createOscillator();const g=ctx.createGain();o.type='square';o.frequency.value=520+Math.random()*90;
      g.gain.setValueAtTime(.008,ctx.currentTime);g.gain.exponentialRampToValueAtTime(.001,ctx.currentTime+.035);
      o.connect(g);g.connect(ctx.destination);o.start();o.stop(ctx.currentTime+.04);
    }catch{}
  };
  const beginIntroSound=()=>{setIntroSound(true);try{const ctx=introAudio.current??new AudioContext();introAudio.current=ctx;void ctx.resume();}catch{}};
  const skipIntro=()=>{if(introTimer.current)clearTimeout(introTimer.current);setIntroText(story.join(''));setIntroDone(true);};

  useEffect(()=>{
    setCast([generateCharacter({portrait:'lilac',hue:0}),generateCharacter({portrait:'ash',hue:0}),generateCharacter({portrait:'peach',hue:0})]);
    fetch('/api/game').then(r=>r.json()).then(d=>{if(d.game?.status==='interrogating')setActive(d.game);}).catch(()=>{});
    let step=0;const timer=setInterval(()=>{setExpr(cycle[++step%cycle.length]);},4300);
    let line=0,char=0,cancelled=false;
    const typeNext=()=>{
      if(cancelled)return;
      const text=story[line];
      if(char<text.length){
        const next=text[char++];
        setIntroText(prev=>prev+next);
        if(introSoundRef.current && next!==' ')typeSound();
        const wait='。、――'.includes(next)?260:34;
        introTimer.current=setTimeout(typeNext,wait);
      }else if(line<story.length-1){
        line++;char=0;setIntroText(prev=>prev+'\n\n');introTimer.current=setTimeout(typeNext,700);
      }else{setIntroDone(true);}
    };
    introTimer.current=setTimeout(typeNext,650);
    return()=>{cancelled=true;clearInterval(timer);if(introTimer.current)clearTimeout(introTimer.current);void introAudio.current?.close();};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);
  const current=cast[selected]??fallback;
  const start=async()=>{
    if(starting)return;setStarting(true);setError('');
    try{
      const r=await fetch('/api/game',{method:'POST'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error);
      if(typeof window!=='undefined'){try{sessionStorage.setItem('aid_last_case',d.game.id);}catch{}}
      router.push(`/game?case=${encodeURIComponent(d.game.id)}`);
    }catch(e){setError(e instanceof Error?e.message:'移送に失敗しました。もう一度お試しください。');setStarting(false);}
  };
  return <div className="home-page">
    {intro&&<div className="story-intro" role="dialog" aria-label="ゲームプロローグ">
      <div className="story-grid"/>
      <div className="story-terminal">
        <div className="story-status"><span className="status-dot"/>A.I.D. SECURE CHANNEL <span className="story-clock">20XX / 02:14</span></div>
        <div className="story-kicker">ARCHIVE 07 ／ INCIDENT REPORT</div>
        <div className="story-title">THE FAKER</div>
        <div className="story-rule"/>
        <div className="story-text" aria-live="polite">{introText}<span className="story-caret">▋</span></div>
        {!introSound&&!introDone&&<button type="button" className="story-sound" onClick={beginIntroSound}>▶ タイピング音を有効にする</button>}
        <div className="story-actions">
          {introDone?<button type="button" className="story-enter" onClick={()=>setIntro(false)}>任務を開始する <ArrowRight size={15}/></button>:<button type="button" className="story-skip" onClick={skipIntro}>SKIP</button>}
        </div>
        <div className="story-footer">CLASSIFIED ／ AGENCY FOR INHUMAN DETECTION</div>
      </div>
    </div>}
    <Header/><main className="home-main"><div className="home-intro"><span className="eyebrow">A.I.D. TERMINAL ／ SECTOR 07</span><span>20XX年　午前 02:14　雨</span></div><section className="home-hero"><div className="hero-copy"><div className="hero-badge"><span className="status-dot"/>執行官、新たな任務です。</div><h1>その顔は、<br/><span className="accent">人間のものか。</span></h1><p className="hero-description">優しい声。懐かしい記憶。ほんの一瞬の微笑み。<br/>人間のすべてをまとうAI〈フェイカー〉は、<br/>今もこの街のどこかで、息をしている。</p><p className="hero-description" style={{marginTop:14}}>3人の被疑者と、25回の質問。<br/>あなたの言葉で、隠された正体を見つけてください。</p><div className="hero-actions">{active?<button className="primary-button" onClick={()=>router.push('/game')}>尋問を再開する <ArrowRight size={16}/></button>:<button className="primary-button" onClick={start} disabled={starting}>{starting?<LoaderCircle size={15} className="spin"/>:<ScanFace size={16}/>} {starting?'被疑者を移送中':'尋問を開始する'}<ArrowRight size={16}/></button>}<Link href="/archive" className="secondary-button"><UsersRound size={14}/>人物アーカイブ</Link></div><div className="hero-caption">{active?<>残り {active.totalQuestions-active.usedQuestions} 回 ／ <button className="text-button" style={{fontSize:9}} onClick={start} disabled={starting}>別の任務を開始</button></>:'選択肢はありません。何を聞くかは、あなた次第。'}</div>{error&&<div className="error-banner" style={{marginTop:15}} role="alert">{error}</div>}</div><div className="hero-stage"><div className="city-background"/><span className="corner tl"/><span className="corner tr"/><span className="corner bl"/><span className="corner br"/><div className="stage-label"><ScanFace size={13}/> SUBJECT PREVIEW / 0{selected+1}</div><div className="stage-live"><span className="status-dot"/>LIVE PORTRAIT</div><div className="hero-portrait"><PixelCharacter look={current.look} expr={expr} size={365} name={current.name}/></div><div className="portrait-nameplate"><div><div className="nameplate-name">{current.name}</div><div className="nameplate-details">{current.age}歳 ／ {current.job} ／ {current.personaLabel}</div></div><span className="expression-badge"><Sparkles size={11}/>{EXPR_LABEL[expr]}</span></div></div></section><section><div className="section-heading"><h2>まだ、誰のことも知らない。 <span>SUBJECT DATABASE</span></h2><button className="text-button" onClick={()=>{setCast(generateCast());setSelected(0);setExpr('normal');}}><RefreshCw size={12}/>新しい人物を生成</button></div><div className="preview-roster">{(cast.length?cast:[fallback,fallback,fallback]).map((c,i)=><button key={`${c.id}-${i}`} className="preview-card" onClick={()=>{setSelected(i);setExpr(i===selected?'blush':'normal');}} aria-label={`${c.name}をプレビュー`}><PixelCharacter look={c.look} expr={i===selected?expr:'normal'} size={105} name={c.name}/><div className="preview-details"><div className="preview-id">SUBJECT / 0{i+1}</div><div className="preview-name">{c.name}</div><div className="preview-job">{c.age}歳 ／ {c.job}</div><span className="character-tag">{c.speechLabel}</span></div></button>)}</div></section><section className="protocol-grid" aria-label="ゲームの特徴"><div className="protocol-item"><div className="protocol-icon"><MessageSquare size={18}/></div><div><h3>あなたの言葉で、尋問する。</h3><p>自由な質問に、その人物らしい返答を。<br/>名前も好物も、思い出も、毎回変わります。</p></div></div><div className="protocol-item"><div className="protocol-icon"><HeartPulse size={18}/></div><div><h3>言葉にならない反応を、観る。</h3><p>22種類の表情、心拍、瞳孔、応答の間。<br/>完璧すぎる平静にも、秘密があります。</p></div></div><div className="protocol-item"><div className="protocol-icon"><ScanFace size={18}/></div><div><h3>釈放か、強制停止か。</h3><p>あなたの判断が、誰かの明日を決める。<br/>人間を疑うことも、機械を信じることも。</p></div></div></section><footer className="site-footer"><span>ZERO. ／ AGENCY FOR INHUMAN DETECTION</span><span>可愛い顔の向こう側に、何がいる？</span><span>PIXEL PORTRAITS / V.04</span></footer></main></div>;
}
