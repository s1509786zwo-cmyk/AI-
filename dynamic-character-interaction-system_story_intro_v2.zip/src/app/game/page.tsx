"use client";

import { useEffect,useRef,useState } from 'react';
import { useRouter } from 'next/navigation';
import { Activity,ArrowRight,Check,ChevronRight,Download,Eye,FileText,HeartPulse,History,LoaderCircle,MessageSquare,NotebookPen,RefreshCw,ScanFace,Send,Sparkles,SquareTerminal,Timer,Unlock,X,FastForward,ShieldCheck } from 'lucide-react';
import { Header } from '@/components/Header';
import { Modal } from '@/components/Modal';
import { PixelCharacter } from '@/components/PixelCharacter';
import { BiosignMonitor } from '@/components/BiosignMonitor';
import { EXPR_LABEL,TYPE_LABEL,type Biosign,type CharId,type ExprId,type ReplyPlan } from '@/lib/engine/types';
import type { GameCase,GameMessage } from '@/lib/game-view';

const SLOTS:CharId[]=[1,2,3];
interface DisplayMessage extends GameMessage { visible?:string; pending?:boolean; }
type Decision='release'|'execute';

export default function Game(){
  const router=useRouter();
  const [game,setGame]=useState<GameCase|null>(null);
  const [messages,setMessages]=useState<DisplayMessage[]>([]);
  const [selected,setSelected]=useState<CharId>(1);
  const [question,setQuestion]=useState('');
  const [expression,setExpression]=useState<ExprId>('normal');
  const [busy,setBusy]=useState(false);
  const [phase,setPhase]=useState('');
  const [talking,setTalking]=useState(false);
  const [bio,setBio]=useState<Biosign|null>(null);
  const [error,setError]=useState('');
  const [loaded,setLoaded]=useState(false);
  const [historyOpen,setHistoryOpen]=useState(false);
  const [historyFilter,setHistoryFilter]=useState<CharId|0>(0);
  const [vitalsOpen,setVitalsOpen]=useState(false);
  const [verdictOpen,setVerdictOpen]=useState(false);
  const [decisions,setDecisions]=useState<Record<number,Decision|null>>({1:null,2:null,3:null});
  const [verdicting,setVerdicting]=useState(false);
  const [resultOpen,setResultOpen]=useState(false);
  const [newConfirm,setNewConfirm]=useState(false);
  const [starting,setStarting]=useState(false);
  const [speed,setSpeed]=useState(1);
  const [sound,setSound]=useState(false);
  const [toast,setToast]=useState('');
  const [bubble,setBubble]=useState<string|null>(null);
  const [tutorialOpen,setTutorialOpen]=useState(false);
  const log=useRef<HTMLDivElement>(null);
  const input=useRef<HTMLInputElement>(null);
  const alive=useRef(true);
  const seq=useRef(0);
  const timers=useRef(new Map<ReturnType<typeof setTimeout>,()=>void>());
  const busyRef=useRef(false);
  const speedRef=useRef(speed);speedRef.current=speed;
  const soundRef=useRef(sound);soundRef.current=sound;
  const audio=useRef<AudioContext|null>(null);
  const retry=useRef<{id:string;text:string;suspect:CharId}|null>(null);
  const lastPlan=useRef<{answerId:string;used:number;plan:ReplyPlan}|null>(null);
  const toastTimer=useRef<ReturnType<typeof setTimeout>|null>(null);
  const bubbleTimer=useRef<ReturnType<typeof setTimeout>|null>(null);

  const pause=(ms:number)=>new Promise<void>(resolve=>{
    const id=setTimeout(()=>{timers.current.delete(id);resolve();},ms/speedRef.current);timers.current.set(id,resolve);
  });
  const cancelAnimation=()=>{seq.current++;timers.current.forEach((resolve,id)=>{clearTimeout(id);resolve();});timers.current.clear();};
  const notice=(text:string)=>{setToast(text);if(toastTimer.current)clearTimeout(toastTimer.current);toastTimer.current=setTimeout(()=>setToast(''),2700);};
  const beep=()=>{
    if(!soundRef.current)return;
    try{const context=audio.current??new AudioContext();audio.current=context;if(context.state==='suspended')void context.resume();const oscillator=context.createOscillator();const gain=context.createGain();oscillator.type='sine';oscillator.frequency.value=640;gain.gain.setValueAtTime(.012,context.currentTime);gain.gain.exponentialRampToValueAtTime(.001,context.currentTime+.055);oscillator.connect(gain);gain.connect(context.destination);oscillator.start();oscillator.stop(context.currentTime+.06);}catch{}
  };
  const showBubble=(text:string,lingerMs:number)=>{
    if(bubbleTimer.current)clearTimeout(bubbleTimer.current);
    setBubble(text);
    bubbleTimer.current=setTimeout(()=>{setBubble(null);bubbleTimer.current=null;},Math.max(1200,lingerMs/speedRef.current));
  };
  const clearBubble=()=>{if(bubbleTimer.current){clearTimeout(bubbleTimer.current);bubbleTimer.current=null;}setBubble(null);};
  const load=async()=>{
    setError('');
    const caseParam=new URLSearchParams(window.location.search).get('case')??sessionStorage.getItem('aid_last_case')??'';
    try{
      const r=await fetch(`/api/game${caseParam?`?caseId=${encodeURIComponent(caseParam)}`:''}`);
      const d=await r.json();
      if(!r.ok)throw new Error(d.error);
      if(!alive.current)return;
      if(!d.game){router.replace('/');return;}
      setGame(d.game);setMessages(d.messages);setDecisions(Object.fromEntries(d.game.decisions?.map((x:{slot:CharId;action:Decision})=>[x.slot,x.action])??[[1,null],[2,null],[3,null]]));setResultOpen(d.game.status==='verdict');
    }
    catch(e){if(alive.current)setError(e instanceof Error?e.message:'記録を読み込めませんでした。サーバーが応答しなかった可能性があります。');}
    finally{if(alive.current)setLoaded(true);}
  };
  useEffect(()=>{
    alive.current=true;setSound(localStorage.getItem('aid_sound')==='true');void load();
    return()=>{alive.current=false;cancelAnimation();if(toastTimer.current)clearTimeout(toastTimer.current);if(bubbleTimer.current)clearTimeout(bubbleTimer.current);void audio.current?.close();};
    // eslint-disable-next-line react-hooks/exhaustive-deps
  },[]);
  useEffect(()=>{
    if(!loaded||!game)return;
    try{ if(localStorage.getItem('aid_tutorial_seen')!=='1') setTutorialOpen(true); }catch{ setTutorialOpen(true); }
  },[loaded,game]);
  useEffect(()=>{if(log.current)log.current.scrollTop=log.current.scrollHeight;},[messages,selected]);

  const finish=(used:number)=>{
    busyRef.current=false;setBusy(false);setTalking(false);setPhase('');setExpression('normal');
    if(game&&used>=game.totalQuestions)setVerdictOpen(true);
    else setTimeout(()=>{if(alive.current&&!document.querySelector('[role="dialog"]'))input.current?.focus();},0);
  };
  const animate=async(plan:ReplyPlan,answerId:string,used:number)=>{
    const run=++seq.current;const current=()=>alive.current&&run===seq.current;
    lastPlan.current={answerId,used,plan};
    setPhase('聞いている…');setBio(plan.bio);
    await pause(plan.delay);if(!current())return;
    for(const hold of plan.pre){setExpression(hold.expr);setPhase(hold.expr==='thinking'?'考えている…':'反応を観察中');await pause(hold.ms);if(!current())return;}
    setPhase('回答中');setTalking(true);let accumulated='';setBubble('');
    for(const segment of plan.segments){
      if(segment.before){setExpression(segment.before.expr);setTalking(false);setPhase('……');await pause(segment.before.ms);if(!current())return;setTalking(true);setPhase('回答中');}
      setExpression(plan.mainExpr);
      const chars=Array.from(segment.text);
      for(let i=0;i<chars.length;i++){
        if(!current())return;accumulated+=chars[i];const value=accumulated;
        setBubble(value);
        setMessages(list=>list.map(m=>m.id===answerId?{...m,visible:value,pending:true}:m));
        if(i%9===0)beep();
        await pause(/[。、…！？]/.test(chars[i])?72:25);
      }
    }
    if(!current())return;setTalking(false);
    for(const hold of plan.post){setExpression(hold.expr);await pause(hold.ms);if(!current())return;}
    setMessages(list=>list.map(m=>m.id===answerId?{...m,visible:undefined,pending:false}:m));
    showBubble(plan.segments.map(x=>x.text).join(''),3800);
    lastPlan.current=null;finish(used);
    if(plan.contradiction)notice('証言に矛盾を確認。記録に残しました。');
    else if(plan.bio.flat)notice('表情と生体データを、合わせて観察してください。');
  };
  const skip=()=>{
    const active=lastPlan.current;if(!active)return;cancelAnimation();
    setMessages(list=>list.map(m=>m.id===active.answerId?{...m,visible:undefined,pending:false}:m));
    showBubble(active.plan.segments.map(x=>x.text).join(''),3800);
    lastPlan.current=null;finish(active.used);
  };
  const send=async()=>{
    const text=question.trim();if(!game||!text||busyRef.current||game.status!=='interrogating'||game.usedQuestions>=game.totalQuestions)return;
    const target=selected;
    const requestId=retry.current?.text===text&&retry.current.suspect===target?retry.current.id:crypto.randomUUID();
    retry.current={id:requestId,text,suspect:target};busyRef.current=true;setBusy(true);setPhase('聞いている…');setExpression('thinking');setError('');setQuestion('');
    const player:DisplayMessage={id:requestId,suspect:target,role:'player',content:text,type:'unknown',expr:'normal',delayMs:0,contradiction:false,observed:false,createdAt:new Date().toISOString()};
    setMessages(list=>[...list.filter(m=>m.id!==requestId),player]);
    try{
      const r=await fetch('/api/game/ask',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gameId:game.id,suspect:target,question:text,requestId})});
      const d=await r.json();if(!r.ok)throw new Error(d.error);
      if(!alive.current)return;
      retry.current=null;setGame(d.game);
      setMessages(d.messages.map((m:GameMessage)=>m.id===d.answerId?{...m,visible:'',pending:true}:m));
      await animate(d.plan,d.answerId,d.game.usedQuestions);
    }catch(e){if(!alive.current)return;cancelAnimation();busyRef.current=false;setBusy(false);setPhase('');setExpression('normal');setQuestion(text);setMessages(list=>list.filter(m=>m.id!==requestId));setError(e instanceof Error?e.message:'回答を取得できませんでした。もう一度送信してください。');}
  };
  const select=(slot:CharId)=>{if(busyRef.current)return;setSelected(slot);setExpression('normal');setBio(null);setError('');clearBubble();};
  const startNew=async()=>{
    if(starting||busyRef.current)return;setStarting(true);setError('');
    try{const r=await fetch('/api/game',{method:'POST'});const d=await r.json();if(!r.ok)throw new Error(d.error);cancelAnimation();clearBubble();setGame(d.game);setMessages(d.messages);setSelected(1);setQuestion('');setBio(null);setExpression('normal');setResultOpen(false);setVerdictOpen(false);setNewConfirm(false);setDecisions({1:null,2:null,3:null});retry.current=null;notice('新しい3名の被疑者が移送されました。');}
    catch(e){setError(e instanceof Error?e.message:'移送に失敗しました。');}
    finally{setStarting(false);}
  };
  const judge=async()=>{
    if(!game||SLOTS.some(s=>!decisions[s])||verdicting)return;
    setVerdicting(true);setError('');
    try{const r=await fetch('/api/game/verdict',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({gameId:game.id,decisions:SLOTS.map(s=>({slot:s,action:decisions[s]}))})});const d=await r.json();if(!r.ok)throw new Error(d.error);setGame(d.game);setMessages(d.messages);setVerdictOpen(false);setResultOpen(true);}
    catch(e){setError(e instanceof Error?e.message:'判定を保存できませんでした。');}
    finally{setVerdicting(false);}
  };
  const exportLog=()=>{
    if(!game)return;const content=JSON.stringify({case:game,messages:messages.map(({visible,pending,...m})=>m)},null,2);const url=URL.createObjectURL(new Blob([content],{type:'application/json'}));const link=document.createElement('a');link.href=url;link.download=`aid-record-${game.id.slice(0,8)}.json`;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);notice('尋問記録を書き出しました。');
  };

  if(!loaded||!game)return <div className="loading-page"><div><div className="loading-message"><LoaderCircle size={19} className="spin"/>A.I.D. 尋問記録を読み込み中…</div>{error&&<div className="error-banner" style={{marginTop:24}} role="alert">{error}<button className="text-button" onClick={()=>void load()} style={{marginLeft:15}}>再試行</button></div>}</div></div>;
  const character=game.cast[selected-1];const over=game.status!=='interrogating';const remaining=game.totalQuestions-game.usedQuestions;
  const metric=game.metrics[String(selected)];
  const currentBio=(busy?bio:null)??metric?.bio??{bpm:character.restBpm,hrv:4.2,pupil:.38,flat:false};
  const currentMessages=messages.filter(m=>m.suspect===selected);
  const monitor=<BiosignMonitor key={`${game.id}-${selected}`} targetBpm={currentBio.bpm} hrv={currentBio.hrv} pupil={currentBio.pupil} flat={currentBio.flat} name={character.name} role={`基準 ${character.restBpm} BPM`}/>;
  return <div className="game-page"><Header sound={sound} onSound={()=>{const next=!sound;setSound(next);soundRef.current=next;localStorage.setItem('aid_sound',String(next));if(next)beep();}}/><main className="game-shell"><div className="case-bar"><div className="case-title"><div className="eyebrow">CASE / {game.id.slice(0,6).toUpperCase()}</div><h1>尋問室 07</h1><span className="case-tag">{over?'任務終了':'尋問中'}</span></div><div className="case-controls"><div className="question-count">残り質問回数<strong className={remaining<=5?'count-low':''}>{remaining.toString().padStart(2,'0')}</strong><span> / {game.totalQuestions}</span></div><button className="icon-button mobile-vital-toggle" onClick={()=>setVitalsOpen(true)} aria-label="生体モニターを開く"><HeartPulse size={15}/></button><button className="danger-button" disabled={busy} onClick={()=>over?setResultOpen(true):setVerdictOpen(true)}><ShieldCheck size={13}/>{over?'判定結果':'最終判定へ'}</button></div></div>{resultOpen?<Result game={game} onReview={()=>setResultOpen(false)} onNew={startNew} starting={starting}/>:<><div className="mobile-suspects">{SLOTS.map(s=><button key={s} disabled={busy} className={`mobile-suspect ${selected===s?'selected':''}`} onClick={()=>select(s)}><PixelCharacter look={game.cast[s-1].look} expr="normal" size={35}/>{game.cast[s-1].name.split(' ')[0]}</button>)}</div><div className="workspace"><aside className="suspect-sidebar"><div className="suspect-list-label">拘留対象 <small>03 SUBJECTS</small></div>{SLOTS.map(slot=>{const c=game.cast[slot-1];const m=game.metrics[String(slot)];return <button key={`${game.id}-${slot}`} disabled={busy} className={`suspect-card ${selected===slot?'selected':''}`} onClick={()=>select(slot)} aria-label={`${c.name}を尋問する`}><span className="suspect-num">SUBJECT / 0{slot}</span>{selected===slot&&<span className="suspect-active">尋問対象</span>}<div className="suspect-art"><PixelCharacter look={c.look} expr={selected===slot?expression:'normal'} size={122} name={c.name}/></div><div className="suspect-meta"><div className="suspect-name">{c.name}</div><div className="suspect-job">{c.age}歳 ／ {c.job}</div><div className="suspect-foot"><span className="character-tag">{c.personaLabel}</span><span>{m?.questions??0} 回の質問</span></div></div></button>;})}</aside><section className="center-column"><div className="interrogation-stage"><div className="city-background"/><span className="corner tl"/><span className="corner tr"/><span className="corner bl"/><span className="corner br"/><div className="stage-label"><ScanFace size={12}/> SUBJECT / 0{selected} — {character.name}</div><div className="stage-live"><span className="status-dot"/>{busy?'OBSERVING':'CAM 07'}</div><div className="stage-ruler"/><div className="stage-marker">A.I.D. / BIOMETRIC SCAN</div>{bubble!==null&&<div className="speech-bubble" role="status" aria-live="polite" aria-label={`${character.name}の応答`}><span className="bubble-text">{bubble||'…'}</span></div>}<div className="stage-main-character"><PixelCharacter key={`${game.id}-${selected}`} look={character.look} expr={expression} size={345} talking={talking} name={character.name}/></div><div className="stage-expression"><div className="expression-badge"><Sparkles size={10}/>{EXPR_LABEL[expression]}</div><div className="stage-expression-caption">MICRO EXPRESSION / LIVE</div></div></div><div className="panel conversation-panel"><div className="panel-title"><span className="title-with-icon"><MessageSquare size={13} className="lilac"/>{character.name}<span className="dim" style={{fontSize:9,fontWeight:400}}>との会話</span></span><button className="text-button" onClick={()=>setHistoryOpen(true)} style={{padding:0,fontSize:9}}><History size={11}/>すべての記録</button></div><div ref={log} className="conversation-log scroll-thin" aria-live="polite" aria-relevant="additions text">{currentMessages.map(m=><div key={m.id} className={`chat-item ${m.role}`}><div className="chat-speaker">{m.role==='player'?<><SquareTerminal size={10} className="mint"/>あなた</>:<><span className="status-dot"/>{character.name}</>}<span className="time">{new Date(m.createdAt).toLocaleTimeString('ja-JP',{hour:'2-digit',minute:'2-digit'})}</span></div><div className="chat-text">{m.visible??m.content}{m.pending&&<span className="typing-caret"/>}</div>{m.role==='suspect'&&m.type!=='opening'&&!m.pending&&<div className="chat-data"><Timer size={9}/>{(m.delayMs/1000).toFixed(1)}s <span>／ {EXPR_LABEL[m.expr]}</span><span>／ {m.bio?.bpm.toFixed(0)} BPM</span></div>}{m.contradiction&&!m.pending&&<div className="contradiction-text">〈証言に矛盾を確認〉</div>}</div>)}</div><form className="input-area" onSubmit={e=>{e.preventDefault();void send();}}>{error&&!verdictOpen&&<div className="error-banner" style={{marginBottom:8,fontSize:10,padding:8}} role="alert">{error}</div>}<div className="input-line"><ChevronRight size={17} className="input-prefix"/><input ref={input} className="question-input" aria-label={`${character.name}への質問`} value={question} onChange={e=>setQuestion(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&(e.nativeEvent.isComposing||e.keyCode===229))e.preventDefault();}} placeholder={over?'この任務の判定は、すでに執行されています。':remaining===0?'質問回数がなくなりました。最終判定へ進んでください。':'質問を入力してください。あなたは、何を聞きますか？'} maxLength={300} disabled={busy||over||remaining===0} autoComplete="off" autoFocus/><button className="input-send" type="submit" disabled={busy||over||remaining===0||!question.trim()} aria-label="質問する">{busy?<LoaderCircle size={13} className="spin"/>:<Send size={14}/>}</button></div><div className="input-hint"><span>{busy?phase:over?'記録は保存されています。':'質問は自由入力。相手の言葉と、その反応を観察してください。'}</span>{busy&&lastPlan.current?<button type="button" className="text-button" style={{fontSize:8,padding:0}} onClick={skip}><FastForward size={10}/>全文を表示</button>:<span><kbd>Enter</kbd> で送信</span>}</div></form></div></section><aside className="right-column">{monitor}<div className="panel profile-panel"><div className="panel-title"><span className="title-with-icon"><FileText size={13} className="lilac"/>対象プロフィール</span><span className="eyebrow">0{selected}</span></div><div className="profile-info"><dl><dt>氏名</dt><dd>{character.name}</dd><dt>職業</dt><dd>{character.job}</dd><dt>話し方</dt><dd>{character.speechLabel}</dd><dt>応答時間</dt><dd>{metric?.average?(metric.average/1000).toFixed(1)+' 秒':'未計測'}</dd></dl><div className="profile-trait">{character.trait}。<br/><span className="dim">身元と記憶の真正性は未確認。</span></div></div></div><div className="panel notes-panel"><div className="panel-title"><span className="title-with-icon"><NotebookPen size={13} className="lilac"/>観察ノート</span><span className="eyebrow">{game.notes.length.toString().padStart(2,'0')}</span></div><div className="notes-list scroll-thin">{game.notes.length?game.notes.map((n,i)=><div className="note-item" key={`${i}-${n}`}>{n}</div>):<div className="empty-notes">まだ、気づいたことはありません。<br/>重要な反応や矛盾は、ここに記録されます。<div style={{marginTop:16,fontSize:9,color:'#65748b'}}>「正しい質問」は、用意されていない。</div></div>}</div></div></aside></div><div className="workspace-footer"><span><span className="status-dot"/>ALL RECORDS AUTOMATICALLY SAVED ／ A.I.D. SECURE CONNECTION</span><div style={{display:'flex',gap:18}}><button className="text-button" onClick={()=>setSpeed(s=>s===1?2:1)}><FastForward size={10}/>表示速度 ×{speed}</button><button className="text-button" onClick={exportLog} disabled={busy}><Download size={10}/>記録を書き出す</button><button className="text-button" disabled={busy} onClick={()=>setNewConfirm(true)}><RefreshCw size={10}/>次の任務</button></div></div></>}</main>{historyOpen&&<Modal title="尋問記録" kicker={`CASE / ${game.id.slice(0,8).toUpperCase()} — SAVED`} wide onClose={()=>setHistoryOpen(false)} actions={<button className="secondary-button" onClick={exportLog} disabled={busy}><Download size={13}/>記録を書き出す</button>}><div className="history-tabs">{([0,...SLOTS] as const).map(s=><button key={s} className={`filter-button ${historyFilter===s?'selected':''}`} onClick={()=>setHistoryFilter(s)}>{s===0?'すべて':game.cast[s-1].name.split(' ')[0]}</button>)}</div>{messages.filter(m=>!historyFilter||m.suspect===historyFilter).map(m=><div className="history-entry" key={m.id}><div className="chat-speaker">{game.cast[m.suspect-1].name} ／ {m.role==='player'?'あなたの質問':TYPE_LABEL[m.type]}</div><div className="chat-text" style={{fontSize:12,color:m.role==='player'?'#badbcd':undefined}}>{m.visible??m.content}</div>{m.timeline&&<><div className="chat-data">応答 {(m.delayMs/1000).toFixed(1)}s ／ BPM {m.bio?.bpm.toFixed(0)} ／ HRV {m.bio?.hrv.toFixed(1)} ／ 瞳孔 {m.bio?(1.8+m.bio.pupil*4.6).toFixed(1):'-'}mm</div><div className="history-timeline">{[...m.timeline.pre.map(h=>h.expr),m.timeline.mainExpr,...m.timeline.post.map(h=>h.expr)].map((e,i)=><span key={i}>{EXPR_LABEL[e]}</span>)}</div></>}{m.contradiction&&<div className="contradiction-text">〈証言に矛盾を確認〉</div>}</div>)}</Modal>}{vitalsOpen&&<Modal title={`${character.name}の生体データ`} kicker="BIOMETRIC SCAN / LIVE" onClose={()=>setVitalsOpen(false)}>{monitor}<p className="modal-copy" style={{marginTop:20}}>数値が高いことも、変わらないことも、単独では答えになりません。表情、言葉、過去の記録と合わせて観察してください。</p></Modal>}{verdictOpen&&<Modal title="最終判定" kicker="FINAL JUDGMENT / IRREVERSIBLE" onClose={()=>{if(!verdicting)setVerdictOpen(false);}} actions={<><button className="secondary-button" onClick={()=>setVerdictOpen(false)} disabled={verdicting}>{remaining>0?'尋問に戻る':'記録を確認する'}</button><button className="danger-button" onClick={judge} disabled={verdicting||SLOTS.some(s=>!decisions[s])}>{verdicting?<LoaderCircle size={13} className="spin"/>:<ShieldCheck size={13}/>}判定を執行する</button></>}><p className="modal-copy">3人のうち、フェイカーは1人。<br/>人間は釈放し、フェイカーには強制停止を命じてください。</p>{SLOTS.map(slot=>{const c=game.cast[slot-1];return <div className="verdict-row" key={slot}><PixelCharacter look={c.look} expr="normal" size={58} name={c.name}/><div className="verdict-person"><strong>{c.name}</strong><small>{c.job} ／ {game.metrics[String(slot)]?.questions??0}回尋問</small></div><div className="verdict-options"><button className={`verdict-option release ${decisions[slot]==='release'?'selected':''}`} disabled={verdicting} onClick={()=>setDecisions(d=>({...d,[slot]:'release'}))}><Unlock size={11}/>釈放</button><button className={`verdict-option execute ${decisions[slot]==='execute'?'selected':''}`} disabled={verdicting} onClick={()=>setDecisions(d=>({...d,[slot]:'execute'}))}><X size={11}/>強制停止</button></div></div>;})}<p className="warning-copy">人間を処分しても、フェイカーを街へ釈放しても任務失敗。<br/>この判断は取り消せません。</p>{error&&<div className="error-banner" style={{marginTop:14}} role="alert">{error}</div>}</Modal>}{newConfirm&&<Modal title="次の任務へ進みますか？" kicker="NEW TRANSFER REQUEST" onClose={()=>setNewConfirm(false)} actions={<><button className="secondary-button" onClick={()=>setNewConfirm(false)}>今の任務に戻る</button><button className="primary-button" onClick={startNew} disabled={starting}>{starting?<LoaderCircle size={13} className="spin"/>:<ArrowRight size={13}/>}新しい3名を移送</button></>}><p className="modal-copy">名前・容姿・話し方・記憶が異なる、新しい人物が移送されます。現在の任務の尋問は終了し、この端末からは新しい記録に切り替わります。</p>{error&&<div className="error-banner" role="alert">{error}</div>}</Modal>}{tutorialOpen&&<Modal title="初回チュートリアル" kicker="A.I.D. / HUMAN VERIFICATION PROTOCOL" onClose={()=>{setTutorialOpen(false);try{localStorage.setItem('aid_tutorial_seen','1')}catch{}}} actions={<button className="primary-button" onClick={()=>{setTutorialOpen(false);try{localStorage.setItem('aid_tutorial_seen','1')}catch{}}}>尋問室へ進む <ArrowRight size={13}/></button>}><div className="tutorial-copy"><div className="tutorial-objective"><strong>【任務目標】</strong><p>拘留された3名の中から、人間に扮した『フェイカー（AI）』を特定し、判決を下してください。</p></div><div className="protocol-item"><div className="protocol-icon"><MessageSquare size={17}/></div><div><h3>01 ／ 対話と威嚇</h3><p>質問を投げかけるか、強圧的なアプローチで相手の動揺を誘ってください。</p></div></div><div className="protocol-item"><div className="protocol-icon"><HeartPulse size={17}/></div><div><h3>02 ／ 生体モニタリング（BPM）</h3><p>右上の心拍数グラフ（BPM）に注目してください。人間は「罪悪感や恐怖」で脈が乱れ、AIは「矛盾した思考処理（オーバーロード）」で異常な脈動やノイズが発生します。</p></div></div><div className="protocol-item"><div className="protocol-icon"><FileText size={17}/></div><div><h3>03 ／ 証拠の突きつけ</h3><p>容疑者の発言と「現場ログ資料」に食い違いを発見したら、資料を突きつけて追及してください。</p></div></div><p className="warning-copy">※「ただ怯えているだけの人間」を処刑しないよう、慎重かつ大胆に詰めてください。</p></div></Modal>}{toast&&<div className="toast" role="status">{toast}</div>}</div>;
}

function Result({game,onReview,onNew,starting}:{game:GameCase;onReview:()=>void;onNew:()=>void;starting:boolean}){
  const ai=game.reveal?.aiSuspect??1;const c=game.cast[ai-1];const good=game.isCorrect===true;
  const humanExecuted=game.decisions?.some(d=>d.action==='execute'&&d.slot!==ai);
  const fakerReleased=game.decisions?.some(d=>d.action==='release'&&d.slot===ai);
  return <div className="result-container scroll-thin"><div className="result-inner"><div className="result-hero"><div className="eyebrow">FINAL JUDGMENT / CASE CLOSED</div><h2 className={good?'mint':'danger'}>{good?'判別完了':humanExecuted?'GAME OVER ／ 誤判定':'GAME OVER ／ 逃逸'}</h2><p>{good?'フェイカーを強制停止し、人間2名を釈放しました。':humanExecuted?'本物の人間を処分してしまいました。判定は、取り消せません。':'フェイカーを街へ釈放してしまいました。次の被害を、止めることはできません。'}{humanExecuted&&fakerReleased&&<><br/>さらに、フェイカーは街へ戻っています。</>}</p><div className="result-character"><PixelCharacter look={c.look} expr={good?'agitation':'deceit'} size={210} name={c.name}/><div className="result-character-info"><h3>{c.name}</h3><small>フェイカー ／ {game.reveal?.style}</small><p>この人物の声も、顔も、記憶も、人間のようでした。<br/>決定的な違いは、どこにあったのでしょう。</p></div></div><div className="result-decisions">{SLOTS.map(slot=><div className="result-decision" key={slot}><span className="eyebrow">0{slot}</span><span>{game.cast[slot-1].name}</span><span className={`result-truth ${slot===ai?'danger':'mint'}`}>{slot===ai?'フェイカー':'人間'}</span><span className={game.decisions?.find(d=>d.slot===slot)?.action==='execute'?'danger':'mint'}>{game.decisions?.find(d=>d.slot===slot)?.action==='execute'?'強制停止':'釈放'}</span></div>)}</div></div><div className="panel result-clues"><div className="panel-title"><span className="title-with-icon"><Eye size={13}/>記録に残る、小さな違和感</span><span className="eyebrow">OBSERVATIONS</span></div><ul>{game.reveal?.clues.map((clue,i)=><li key={i}>{clue}</li>)}</ul></div><div className="result-buttons"><span className="eyebrow" style={{alignSelf:'center'}}>GRADE <strong className="lilac" style={{fontSize:22,marginLeft:9}}>{good?game.usedQuestions<=12?'S':game.usedQuestions<=20?'A':'B':'C'}</strong> ／ {game.usedQuestions} QUESTIONS</span><div style={{display:'flex',gap:10}}><button className="secondary-button" onClick={onReview}><History size={12}/>記録を振り返る</button><button className="primary-button" onClick={onNew} disabled={starting}>{starting?<LoaderCircle size={12} className="spin"/>:<ArrowRight size={12}/>}次の任務へ</button></div></div></div></div>;
}
