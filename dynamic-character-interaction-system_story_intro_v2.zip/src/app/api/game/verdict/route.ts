import { NextRequest,NextResponse } from 'next/server';
import { db,ensureSchema } from '@/db';
import { games,messages } from '@/db/schema';
import { eq,asc } from 'drizzle-orm';
import { loadState } from '@/lib/engine/generate';
import { toGameView } from '@/lib/game-view';
import type { CharId } from '@/lib/engine/types';

export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
  try{
    await ensureSchema();
    const body=await req.json();
    const gameId=String(body.gameId??'');
    if(!/^[a-zA-Z0-9-]{36}$/.test(gameId))return NextResponse.json({error:'現在の任務が見つかりません。'},{status:403});
    const cookieId=req.cookies.get('aid_case')?.value;
    if(cookieId&&cookieId!==gameId)return NextResponse.json({error:'現在の任務が見つかりません。'},{status:403});
    const id=gameId;
    const decisions=body.decisions as {slot:CharId;action:'release'|'execute'}[];
    if(!Array.isArray(decisions)||decisions.length!==3||decisions.some(d=>!d||typeof d!=='object'||![1,2,3].includes(d.slot)||!['release','execute'].includes(d.action))||new Set(decisions.map(d=>d.slot)).size!==3)return NextResponse.json({error:'3人全員に、釈放または強制停止を選んでください。'},{status:400});
    const result=await db.transaction(async tx=>{
      const [game]=await tx.select().from(games).where(eq(games.id,id)).for('update');
      if(!game)return{error:'記録が見つかりません。',status:404};
      const list=await tx.select().from(messages).where(eq(messages.gameId,id)).orderBy(asc(messages.createdAt),asc(messages.id));
      if(game.status==='verdict')return toGameView(game,list);
      if(game.status!=='interrogating')return{error:'この任務は終了しています。',status:409};
      const state=loadState(game.stateJson);state.decisions=decisions;
      const isCorrect=decisions.every(d=>d.action===(d.slot===game.aiSuspect?'execute':'release'));
      const [updated]=await tx.update(games).set({status:'verdict',isCorrect,verdictSuspect:decisions.find(d=>d.action==='execute')?.slot??0,stateJson:JSON.stringify(state),updatedAt:new Date()}).where(eq(games.id,id)).returning();
      return toGameView(updated,list);
    });
    if('error' in result)return NextResponse.json({error:result.error},{status:result.status});
    return NextResponse.json(result);
  }catch(e){console.error(e);return NextResponse.json({error:'判定の保存に失敗しました。もう一度お試しください。'},{status:500});}
}
