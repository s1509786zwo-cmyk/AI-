import { NextRequest, NextResponse } from 'next/server';
import { db,ensureSchema } from '@/db';
import { games,messages } from '@/db/schema';
import { generateCast,loadCast } from '@/lib/engine/chargen';
import { emptyState } from '@/lib/engine/generate';
import { toGameView } from '@/lib/game-view';
import { asc,eq } from 'drizzle-orm';

export const dynamic='force-dynamic';
export async function GET(req:NextRequest){
  try{
    await ensureSchema();
    const rawCase=req.cookies.get('aid_case')?.value??new URL(req.url).searchParams.get('caseId')??'';
    const id=/^[a-zA-Z0-9-]{36}$/.test(rawCase)?rawCase:'';
    if(!id)return NextResponse.json({game:null,messages:[]});
    let [game]=await db.select().from(games).where(eq(games.id,id));
    if(!game)return NextResponse.json({game:null,messages:[]});
    // One-time upgrade of legacy, procedurally drawn casts. The new cast is then stable on reload.
    let valid=false;try{valid=!!JSON.parse(game.suspects)?.[0]?.profile?.schedule;}catch{}
    if(!valid){const cast=loadCast(game.suspects);[game]=await db.update(games).set({suspects:JSON.stringify(cast),stateJson:JSON.stringify(emptyState()),usedQuestions:0,status:'interrogating',isCorrect:null}).where(eq(games.id,id)).returning();await db.delete(messages).where(eq(messages.gameId,id));}
    const list=await db.select().from(messages).where(eq(messages.gameId,id)).orderBy(asc(messages.createdAt),asc(messages.id));
    return NextResponse.json(toGameView(game,list));
  }catch(e){console.error(e);return NextResponse.json({error:'記録の読み込みに失敗しました。もう一度お試しください。'},{status:500});}
}
export async function POST(req:NextRequest){
  try{
    await ensureSchema();
    const previous=req.cookies.get('aid_case')?.value;
    const cast=generateCast();const id=crypto.randomUUID();
    const game=await db.transaction(async tx=>{
      if(previous){const [old]=await tx.select().from(games).where(eq(games.id,previous));if(old?.status==='interrogating')await tx.update(games).set({status:'abandoned'}).where(eq(games.id,previous));}
      const [g]=await tx.insert(games).values({id,aiSuspect:1+Math.floor(Math.random()*3),suspects:JSON.stringify(cast),totalQuestions:25,stateJson:JSON.stringify(emptyState())}).returning();
      const now=Date.now();
      await tx.insert(messages).values(cast.map((c,i)=>({id:crypto.randomUUID(),gameId:id,suspect:i+1,role:'suspect',content:c.opening,questionType:'opening',expr:c.openingExpr,createdAt:new Date(now+i)})));
      return g;
    });
    const list=await db.select().from(messages).where(eq(messages.gameId,id)).orderBy(asc(messages.createdAt));
    const response=NextResponse.json(toGameView(game,list));
    response.cookies.set('aid_case',id,{httpOnly:true,sameSite:'lax',path:'/',maxAge:60*60*24*7});
    return response;
  }catch(e){console.error(e);return NextResponse.json({error:'被疑者の移送に失敗しました。もう一度お試しください。'},{status:500});}
}
