import { NextRequest,NextResponse } from 'next/server';
import { db,ensureSchema } from '@/db';
import { games,messages } from '@/db/schema';
import { eq,asc } from 'drizzle-orm';
import { loadCast } from '@/lib/engine/chargen';
import { classifyQuestion } from '@/lib/engine/classify';
import { generateReply,loadState } from '@/lib/engine/generate';
import { toGameView } from '@/lib/game-view';
import type { CharId } from '@/lib/engine/types';

export const dynamic='force-dynamic';
export async function POST(req:NextRequest){
  try{
    await ensureSchema();
    const body=await req.json();
    const gameId=String(body.gameId??'');
    if(!/^[a-zA-Z0-9-]{36}$/.test(gameId))return NextResponse.json({error:'現在の任務が見つかりません。'},{status:403});
    const cookieId=req.cookies.get('aid_case')?.value;
    if(cookieId&&cookieId!==gameId)return NextResponse.json({error:'現在の任務が見つかりません。'},{status:403});
    const id=gameId;
    const {suspect,question,requestId}=body;
    if(![1,2,3].includes(suspect)||typeof question!=='string'||!question.trim()||question.length>300||typeof requestId!=='string'||!/^[a-zA-Z0-9-]{8,80}$/.test(requestId))return NextResponse.json({error:'質問は1〜300文字で入力してください。'},{status:400});
    const result=await db.transaction(async tx=>{
      const [g]=await tx.select().from(games).where(eq(games.id,id)).for('update');
      if(!g)return{error:'記録が見つかりません。',status:404};
      const state=loadState(g.stateJson);
      const existing=state.observations.find(o=>o.requestId===requestId);
      if(existing){const list=await tx.select().from(messages).where(eq(messages.gameId,id)).orderBy(asc(messages.createdAt),asc(messages.id));return{...toGameView(g,list),plan:existing.plan,questionId:requestId,answerId:existing.answerId,type:existing.type};}
      if(g.status!=='interrogating')return{error:'この尋問は終了しています。',status:409};
      if(g.usedQuestions>=g.totalQuestions)return{error:'残りの質問回数はありません。最終判定に進んでください。',status:409};
      const cast=loadCast(g.suspects);const c=cast[suspect-1];const cs=state.chars[String(suspect)];
      const classification=classifyQuestion(question,cs.history.map(h=>h.question));
      const plan=generateReply(c,question.trim(),classification,cs,g.aiSuspect===suspect,state);
      const answer=plan.segments.map(s=>s.text).join('');
      const answerId=crypto.randomUUID();const now=new Date();
      state.observations.push({requestId,answerId,suspect:suspect as CharId,plan,type:classification.type,createdAt:now.toISOString()});
      await tx.insert(messages).values([
        {id:requestId,gameId:id,suspect,role:'player',content:question.trim(),questionType:classification.type,createdAt:now},
        {id:answerId,gameId:id,suspect,role:'suspect',content:answer,questionType:classification.type,expr:plan.mainExpr,delayMs:plan.delay+plan.pre.reduce((n,h)=>n+h.ms,0),contradiction:plan.contradiction??false,observed:plan.observed??false,createdAt:new Date(now.getTime()+1)},
      ]);
      const [game]=await tx.update(games).set({usedQuestions:g.usedQuestions+1,stateJson:JSON.stringify(state),updatedAt:now}).where(eq(games.id,id)).returning();
      const list=await tx.select().from(messages).where(eq(messages.gameId,id)).orderBy(asc(messages.createdAt),asc(messages.id));
      return{...toGameView(game,list),plan,questionId:requestId,answerId,type:classification.type};
    });
    if('error' in result)return NextResponse.json({error:result.error},{status:result.status});
    return NextResponse.json(result);
  }catch(e){console.error(e);return NextResponse.json({error:'応答を取得できませんでした。質問をもう一度送信してください。'},{status:500});}
}
