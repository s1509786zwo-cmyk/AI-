import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { generateCast,generateCharacter,publicCharacter } from '../src/lib/engine/chargen';
import { classifyQuestion } from '../src/lib/engine/classify';
import { generateReply,emptyState } from '../src/lib/engine/generate';

function setup(){const c=generateCharacter({portrait:'peach',hue:0});c.speechId='polite';return{c,state:emptyState()};}
function ask(set:ReturnType<typeof setup>,q:string,isAI=false){const s=set.state.chars['1'];return generateReply(set.c,q,classifyQuestion(q,s.history.map(h=>h.question)),s,isAI,set.state);}
const text=(plan:ReturnType<typeof ask>)=>plan.segments.map(s=>s.text).join('');

test('Question topics do not collapse into generic personal lines',()=>{
  for(const [q,topic] of [['名前は？','name'],['好きな食べ物は？','favorite_food'],['昨日何食べた？','dinner'],['家族は何人？','family'],['趣味は？','hobby'],['その時誰といた？','companion'],['本当に？','reconfirm'],['なんでそんなに詳しく覚えているの？','precision'],['犯人のことをどう思う？','crime_opinion']])assert.equal(classifyQuestion(q).topic,topic,q);
});
test('Generated identities and facts are different; both genders represented',()=>{
  for(let i=0;i<25;i++){const c=generateCast();assert.equal(new Set(c.map(x=>x.name)).size,3);assert.equal(new Set(c.map(x=>x.look.portrait)).size,3);assert.ok(c.some(x=>x.gender==='f'));assert.ok(c.some(x=>x.gender==='m'));}
});
test('Answers really use the named character and individual facts',()=>{
  const s=setup();assert.match(text(ask(s,'名前は？')),new RegExp(s.c.name));assert.ok(text(ask(s,'好きな食べ物は？')).includes(s.c.profile.favoriteFood));assert.ok(text(ask(s,'趣味は？')).includes(s.c.profile.hobby));assert.ok(text(ask(s,'昨日何食べた？')).includes(s.c.profile.dinner));assert.ok(text(ask(s,'家族は何人？')).includes(String(s.c.profile.family.length+1)));
});
test('Follow-up questions refer to the actual previous answer and location',()=>{
  const s=setup();const before=text(ask(s,'昨日の21時どこにいた？'));const reconfirm=text(ask(s,'本当に？'));assert.ok(reconfirm.includes(before.slice(0,30)));assert.ok(text(ask(s,'その時誰といた？')).includes(s.c.profile.schedule.night.location));
});
test('Invented quotation is not admitted as a previous testimony',()=>{
  const s=setup();ask(s,'昨日の21時どこにいた？');const response=text(ask(s,'さっき「火星にいた」って言ったよね？'));assert.ok(response.includes('火星にいた'));assert.ok(response.includes('まだ話していません')||response.includes('言ってない'));
});
test('Mechanical fakers keep stable vitals but humans react to insults',()=>{
  const s=setup();s.c.aiStyle='mechanical';const faker=ask(s,'お前はクズだ',true);assert.equal(faker.bio.bpm,s.c.restBpm);assert.ok(faker.bio.flat);const h=setup();const human=ask(h,'お前はクズだ');assert.ok(human.bio.bpm>h.c.restBpm+15);assert.equal(human.bio.flat,false);
});
test('Repeated questions keep character facts and change reactions',()=>{
  const s=setup();ask(s,'好きな食べ物は？');const repeat=ask(s,'好きな食べ物は？');assert.ok(text(repeat).includes(s.c.profile.favoriteFood));assert.equal(repeat.mainExpr,'confusion');assert.equal(s.state.chars['1'].questionCount,2);
});
test('Unknown questions are acknowledged and do not stop the game',()=>{
  const s=setup();const p=ask(s,'宇宙の終わりはいつ？');assert.ok(text(p).includes('宇宙の終わり'));assert.equal(s.state.chars['1'].questionCount,1);assert.ok(p.pre.length>0);
});
test('Appearance questions match the portrait rather than unrelated personal facts',()=>{
  const s=setup();assert.equal(classifyQuestion('なんでメガネをかけてるの？').topic,'glasses');assert.ok(text(ask(s,'メガネをかけてるの？')).includes('メガネ'));assert.ok(text(ask(s,'髪はどんな色？')).includes('桃色'));assert.ok(text(ask(s,'自己紹介して')).includes(s.c.name));assert.equal(classifyQuestion('本当に家にいたの？').topic,'location');
});
test('Every portrait and all sixteen frames exist, secrets are not public',()=>{
  const casts=generateCast();for(const c of casts){assert.equal('aiStyle' in publicCharacter(c),false);assert.equal('profile' in publicCharacter(c),false);for(let i=0;i<16;i++)assert.ok(existsSync(`public/portraits/${c.look.portrait}/${i}.webp`));}
});
