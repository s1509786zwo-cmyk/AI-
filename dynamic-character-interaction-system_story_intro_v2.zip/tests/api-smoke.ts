import 'dotenv/config';
import assert from 'node:assert/strict';
import { request } from '@playwright/test';
import { db,pool } from '../src/db/index';
import { games,messages } from '../src/db/schema';
import { asc,eq,inArray } from 'drizzle-orm';

async function main(){
  const owner=await request.newContext({baseURL:'http://127.0.0.1:3000'});
  const other=await request.newContext({baseURL:'http://127.0.0.1:3000'});
  const ids:string[]=[];const checks:string[]=[];
  let other2: Awaited<ReturnType<typeof request.newContext>> | undefined;
  try{
    assert.equal((await owner.get('/api/health')).status(),200);
    async function fresh(){const res=await owner.post('/api/game');assert.equal(res.status(),200);const d=await res.json();ids.push(d.game.id);return d;}
    let data=await fresh();const id=data.game.id;
    assert.equal(data.game.cast.length,3);assert.equal('aiSuspect' in data.game,false);assert.equal('profile' in data.game.cast[0],false);assert.equal('aiStyle' in data.game.cast[0],false);
    assert.equal((await (await other.get('/api/game')).json()).game,null);
    assert.equal((await other.post('/api/game/ask',{data:{gameId:'not-a-case-id',suspect:1,question:'名前は？',requestId:crypto.randomUUID()}})).status(),403);
    // A conflicting cookie must still reject a foreign case (cross-session protection).
    other2=await request.newContext({baseURL:'http://127.0.0.1:3000'});
    const otherGame=await (await other2.post('/api/game')).json();
    ids.push(otherGame.game.id);
    assert.equal((await other2.post('/api/game/ask',{data:{gameId:id,suspect:1,question:'名前は？',requestId:crypto.randomUUID()}})).status(),403);
    // The case UUID itself is the credential, so a cookieless session may ask by id.
    assert.equal((await other.post('/api/game/ask',{data:{gameId:id,suspect:2,question:'名前は？',requestId:crypto.randomUUID()}})).status(),200);
    checks.push('Case credential rules, cross-session rejection, hidden identities');
    // Roll back the extra question used for the credential check.
    {const [g]=await db.select().from(games).where(eq(games.id,id));
     await db.update(games).set({usedQuestions:Math.max(0,g.usedQuestions-1)}).where(eq(games.id,id));
     const all=await db.select().from(messages).where(eq(messages.gameId,id));
     const sorted=[...all].sort((a,b)=>a.createdAt.getTime()-b.createdAt.getTime()||(a.id<b.id?-1:1));
     for(const msg of sorted.slice(-2))await db.delete(messages).where(eq(messages.id,msg.id));}
    const requestId=crypto.randomUUID();
    const payload={gameId:id,suspect:1,question:'好きな食べ物は？',requestId};
    const replies=await Promise.all([owner.post('/api/game/ask',{data:payload}),owner.post('/api/game/ask',{data:payload}),owner.post('/api/game/ask',{data:payload})]);
    for(const res of replies){assert.equal(res.status(),200);const d=await res.json();assert.equal(d.game.usedQuestions,1);assert.equal(d.messages.length,5);assert.equal(d.questionId,requestId);}
    data=await (await owner.get('/api/game')).json();
    const [privateGame]=await db.select().from(games).where(eq(games.id,id));const profiles=JSON.parse(privateGame.suspects);
    const answer=data.messages.filter((m:any)=>m.role==='suspect').at(-1);
    assert.ok(answer.content.includes(profiles[0].profile.favoriteFood));assert.ok(answer.timeline.pre.length>0);assert.equal(typeof answer.bio.bpm,'number');
    assert.equal((await owner.post('/api/game/ask',{data:{gameId:id,suspect:1,question:'a'.repeat(301),requestId:crypto.randomUUID()}})).status(),400);
    checks.push('Concurrent retry is idempotent; actual character facts and timeline are saved');
    for(let i=1;i<25;i++){
      const res=await owner.post('/api/game/ask',{data:{gameId:id,suspect:(i%3)+1,question:`記憶チェック${i}：昨日の昼ごはんは？`,requestId:crypto.randomUUID()}});assert.equal(res.status(),200);data=await res.json();assert.equal(data.game.usedQuestions,i+1);
    }
    assert.equal((await owner.post('/api/game/ask',{data:{gameId:id,suspect:1,question:'あと一問',requestId:crypto.randomUUID()}})).status(),409);
    const saved=await (await owner.get('/api/game')).json();assert.equal(saved.game.usedQuestions,25);assert.equal(saved.messages.length,53);
    checks.push('25-question cap and persisted conversation');
    const ai=privateGame.aiSuspect;const choices=[1,2,3].map(slot=>({slot,action:slot===ai?'execute':'release'}));
    assert.equal((await owner.post('/api/game/verdict',{data:{gameId:id,decisions:[choices[0],choices[0],choices[1]]}})).status(),400);
    data=await (await owner.post('/api/game/verdict',{data:{gameId:id,decisions:choices}})).json();assert.equal(data.game.isCorrect,true);assert.equal(data.game.reveal.aiSuspect,ai);
    const repeat=await (await owner.post('/api/game/verdict',{data:{gameId:id,decisions:[1,2,3].map(slot=>({slot,action:'release'}))}})).json();assert.equal(repeat.game.isCorrect,true);
    checks.push('Correct verdict, reveal only after judgment, and irreversible decisions');
    data=await fresh();const escape=await (await owner.post('/api/game/verdict',{data:{gameId:data.game.id,decisions:[1,2,3].map(slot=>({slot,action:'release'}))}})).json();assert.equal(escape.game.isCorrect,false);
    data=await fresh();const [g]=await db.select().from(games).where(eq(games.id,data.game.id));const human=[1,2,3].find(slot=>slot!==g.aiSuspect)!;
    const wrong=await (await owner.post('/api/game/verdict',{data:{gameId:data.game.id,decisions:[1,2,3].map(slot=>({slot,action:slot===human||slot===g.aiSuspect?'execute':'release'}))}})).json();assert.equal(wrong.game.isCorrect,false);
    checks.push('Both failure modes: released faker and executed human');
    console.log(JSON.stringify({passed:true,checks},null,2));
  }finally{
    if(ids.length)await db.delete(games).where(inArray(games.id,ids));
    await owner.dispose();await other.dispose();if(other2)await other2.dispose();await pool.end();
  }
}
main().catch(e=>{console.error(e);process.exitCode=1;});
