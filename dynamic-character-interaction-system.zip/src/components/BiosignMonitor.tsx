"use client";
import { useEffect, useRef, useState } from 'react';
import { Activity, Eye, HeartPulse, TriangleAlert } from 'lucide-react';
import { ALERT_DURATION_MS, ECG_SAMPLE_RATE, ECG_SWEEP_SPEED, EcgSimulator } from '@/lib/engine/ecg';
import type { EcgMode } from '@/lib/engine/types';

export interface MonitorAlert { id: number; reason: string; peak: number; }
interface Props {
  targetBpm: number; hrv: number; pupil: number; flat: boolean;
  ecg?: EcgMode; stress?: number; alert?: MonitorAlert | null;
  name: string; role: string; baseline?: number; compact?: boolean;
}
const W = 420;
const SAMPLE_DT = 1 / ECG_SAMPLE_RATE;

export function BiosignMonitor(props: Props) {
  const compact = props.compact ?? false;
  const H = compact ? 82 : 180;
  const canvas = useRef<HTMLCanvasElement>(null);
  const latest = useRef(props); latest.current = props;
  const alertUntil = useRef(0);
  const [reading, setReading] = useState({ bpm: props.targetBpm, pupil: props.pupil, pulse: false });
  const [alerting, setAlerting] = useState(false);
  const alertId = props.alert?.id ?? 0;

  useEffect(() => {
    if (!alertId) { alertUntil.current = 0; setAlerting(false); return; }
    alertUntil.current = performance.now() + ALERT_DURATION_MS;
    setAlerting(true);
    const timer = setTimeout(() => setAlerting(false), ALERT_DURATION_MS);
    return () => clearTimeout(timer);
  }, [alertId]);

  useEffect(() => {
    const ctx = canvas.current?.getContext('2d'); if (!ctx) return;
    const model = new EcgSimulator(latest.current.targetBpm);
    const samples = new Float32Array(W);
    const baselineY = Math.round(H * 0.57);
    const amplitude = H * 0.3;
    let raf = 0, head = 0, count = 0, timeAccumulator = 0, drawAccumulator = 0;
    let last = performance.now(), lastReading = last, pulseUntil = 0;
    let measuredBpm = latest.current.targetBpm, pupil = latest.current.pupil;
    const draw = (time: number) => {
      const dt = Math.min(0.09, (time - last) / 1000); last = time;
      const p = latest.current;
      const warning = time < alertUntil.current;
      timeAccumulator += dt;
      while (timeAccumulator >= SAMPLE_DT) {
        timeAccumulator -= SAMPLE_DT;
        const sample = model.next({ bpm: p.targetBpm, hrv: p.hrv, mode: p.ecg ?? 'steady', stress: p.stress ?? 0.1, alert: warning });
        measuredBpm = sample.bpm;
        if (sample.beat) pulseUntil = time + 140;
        drawAccumulator += ECG_SWEEP_SPEED / ECG_SAMPLE_RATE;
        if (drawAccumulator >= 1) {
          drawAccumulator -= 1;
          samples[head] = sample.value;
          head = (head + 1) % W;
          count = Math.min(W, count + 1);
        }
      }
      pupil += (p.pupil - pupil) * Math.min(1, dt * 2);
      ctx.clearRect(0, 0, W, H);
      ctx.fillStyle = warning ? '#20131c' : '#0c1920'; ctx.fillRect(0, 0, W, H);
      // A dot grid preserves the pixel-art monitor texture.
      for (let y = 6; y < H; y += 12) for (let x = 6; x < W; x += 12) {
        ctx.fillStyle = x % 60 === 6 || y % 60 === 6 ? warning ? '#65313c' : '#37544d' : warning ? '#3e242e' : '#243b3b';
        ctx.fillRect(x, y, 1, 1);
      }
      ctx.fillStyle = warning ? '#64313b' : '#264b43'; ctx.fillRect(0, baselineY, W, 1);
      let previous = baselineY;
      let joined = false;
      for (let x = 0; x < W; x++) {
        const distance = (head - 1 - x + W) % W;
        const unsampled = count < W && x >= count;
        const gap = count === W && (x - head + W) % W < 15;
        if (unsampled || gap) { joined = false; continue; }
        const y = Math.round(baselineY - samples[x] * amplitude);
        const alpha = 1 - distance / W * 0.65;
        ctx.fillStyle = warning ? `rgba(255,151,163,${alpha})` : `rgba(180,235,205,${alpha})`;
        const top = joined ? Math.min(previous, y) : y;
        const height = joined ? Math.abs(previous - y) + 2 : 2;
        ctx.fillRect(x, Math.max(0, top), 1, Math.min(H - Math.max(0, top), height));
        previous = y; joined = true;
      }
      if (count > 0) {
        const pointer = (head - 1 + W) % W;
        const y = Math.round(baselineY - samples[pointer] * amplitude);
        ctx.fillStyle = warning ? '#ffd8dc' : '#e1ffea'; ctx.fillRect(pointer - 1, y - 1, 3, 3);
        ctx.fillStyle = warning ? '#ff647a18' : '#cefbe708'; ctx.fillRect(pointer, 0, 1, H);
      }
      if (time - lastReading > 120) {
        setReading({ bpm: measuredBpm, pupil, pulse: time < pulseUntil });
        canvas.current?.setAttribute('data-sweep', String(head));
        lastReading = time;
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [H]);

  const bpm = Math.max(0, Math.round(reading.bpm));
  const diameter = (1.8 + reading.pupil * 4.6).toFixed(1);
  const pupilState = reading.pupil < 0.42 ? '収縮' : reading.pupil < 0.62 ? '平常' : '拡大';
  const delta = Math.round(reading.bpm - (props.baseline ?? props.targetBpm));
  const warning = alerting && props.alert;
  const banner = warning ? <div className="alert-banner" role="alert"><TriangleAlert size={compact ? 13 : 17} /><div><strong>BPM急上昇 ／ RED ALERT</strong>{!compact && <small>{props.alert!.reason}　{props.alert!.peak} BPM</small>}</div></div> : null;
  if (compact) return <section className={`panel compact-monitor ${warning ? 'is-alerting' : ''}`} aria-label={`${props.name}のリアルタイム心拍`}>
    <div className="compact-ecg"><canvas ref={canvas} width={W} height={H} aria-label="左から右へ流れる心電図波形" />{banner}<div className={`compact-bpm ${warning ? 'alerting' : ''}`}><HeartPulse size={12} className={reading.pulse ? 'beat-on' : ''} />{bpm}<span>BPM</span></div><div className="compact-meta">ECG II ／ HRV {props.hrv.toFixed(1)} ／ 瞳孔 {diameter}mm</div></div>
  </section>;
  return <section className={`panel vitals-panel ${warning ? 'is-alerting' : ''}`} aria-label={`${props.name}の生体モニター`}>
    <div className="panel-title"><span className="title-with-icon"><HeartPulse size={14} className="mint" />生体モニター</span><span className="eyebrow"><span className="status-dot" />{warning ? 'ALERT' : 'LIVE / ECG II'}</span></div>
    <div className="vital-primary"><div className={`vital-value ${warning ? 'alerting' : ''}`} aria-label={`心拍数 ${bpm} BPM`}>{bpm}<span>BPM</span></div><div className="vital-baseline">{props.role}<br /><span className={`vital-delta ${delta > 18 ? 'elevated' : ''}`}>{delta >= 0 ? '+' : ''}{delta} BPM</span></div></div>
    <div className="ecg-wrap"><canvas ref={canvas} width={W} height={H} className="vital-ecg" aria-label="左から右へ流れる心電図波形" />{banner}<div className="ecg-label">LEAD II ／ CONTINUOUS TRACE</div><div className={`ecg-beat ${reading.pulse ? 'beat-on' : ''}`} aria-hidden="true">♥</div><div className="ecg-scale">← 6.8 SEC →</div></div>
    <div className="vital-secondary"><div><div className="vital-label"><Activity size={11} />心拍変動</div><div className="vital-sub-value">{props.hrv.toFixed(1)}<span>ms</span></div></div><div><div className="pupil-indicator"><span style={{ width: 8 + reading.pupil * 15, height: 8 + reading.pupil * 15 }} /></div><div className="vital-label"><Eye size={11} />瞳孔径</div><div className="vital-sub-value">{diameter}<span>mm</span></div><div className="pupil-state">{pupilState}</div></div></div>
    <div className="monitor-footnote"><span>{props.name}</span><span>生体データ単独での判定は不可</span></div>
  </section>;
}
