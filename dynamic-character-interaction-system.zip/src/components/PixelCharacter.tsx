"use client";

import { useEffect, useRef, useState } from 'react';
import { EXPR_LABEL, type ExprId, type Look } from '@/lib/engine/types';

// Every state is a separately authored full portrait. No eyes pasted from another
// pose, no morphing, no face/shoulder stretching, no procedural marks or noise.
const FRAMES: Record<ExprId, number> = {
  normal: 0, smile: 1, faint: 2, confusion: 3, surprise: 4,
  unease: 5, anxiety: 6, anger: 7, sadness: 8, tension: 9,
  suspicion: 10, blank: 11, agitation: 12, deceit: 13,
  blush: 14, wink: 15, thinking: 16, excited: 17,
  sleepy: 18, relieved: 19, pout: 20, embarrassed: 21,
};
const ORIGINALS = new Set(['kei', 'mori', 'ruri', 'nagi']);
const LEGACY: Record<string, string> = {
  analyst: 'kei', noir: 'kei', blue: 'kei', ash: 'mori', rose: 'mori',
  lilac: 'ruri', peach: 'nagi', ivory: 'nagi', mint: 'nagi',
};
const cache = new Map<string, Promise<HTMLImageElement>>();
function image(src: string): Promise<HTMLImageElement> {
  if (!cache.has(src)) cache.set(src, new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = () => { cache.delete(src); reject(new Error('Portrait unavailable')); };
    img.src = src;
  }));
  return cache.get(src)!;
}
interface Props {
  look: Look;
  expr: ExprId;
  size?: number;
  className?: string;
  talking?: boolean;
  name?: string;
}

export function PixelCharacter({ look, expr, size = 280, className = '', talking = false, name = 'キャラクター' }: Props) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const frames = useRef<HTMLImageElement[]>([]);
  const settings = useRef({ expr, talking });
  settings.current = { expr, talking };
  const [loaded, setLoaded] = useState(false);
  const requested = look.portrait ?? 'ruri';
  const portrait = ORIGINALS.has(requested) ? requested : LEGACY[requested] ?? 'ruri';

  useEffect(() => {
    let live = true;
    frames.current = []; setLoaded(false);
    Promise.all(Array.from({ length: 23 }, (_, i) => image(`/portraits/${portrait}/${i}.webp`)))
      .then(images => { if (live) { frames.current = images; setLoaded(true); } })
      .catch(() => {});
    return () => { live = false; };
  }, [portrait]);

  useEffect(() => {
    const el = canvas.current;
    const ctx = el?.getContext('2d');
    if (!el || !ctx) return;
    const preference = window.matchMedia('(prefers-reduced-motion: reduce)');
    let last = 0, raf = 0, blinkUntil = 0;
    let nextBlink = performance.now() + 3300 + Math.random() * 1800;
    const draw = (time: number) => {
      if (time - last < 50) { raf = requestAnimationFrame(draw); return; }
      last = time;
      if (frames.current.length !== 23) { raf = requestAnimationFrame(draw); return; }
      const current = settings.current;
      const motion = !preference.matches;
      const canBlink = !['smile', 'wink', 'excited', 'sleepy'].includes(current.expr);
      if (motion && canBlink && time > nextBlink) {
        blinkUntil = time + 100;
        nextBlink = time + 3500 + Math.random() * 2400;
      }
      const frame = motion && canBlink && time < blinkUntil ? 22 : FRAMES[current.expr];
      const breathe = motion ? Math.round(Math.sin(time / 1500)) : 0;
      const nod = motion && current.talking ? Math.round(Math.sin(time / 320)) : 0;
      ctx.setTransform(1, 0, 0, 1, 0, 0);
      ctx.globalAlpha = 1;
      ctx.globalCompositeOperation = 'source-over';
      ctx.imageSmoothingEnabled = false;
      ctx.clearRect(0, 0, 256, 256);
      // The original image is always copied 1:1. Only whole-portrait vertical
      // breathing/nodding is allowed; anatomy is never altered.
      ctx.drawImage(frames.current[frame], 0, breathe + nod);
      el.dataset.frame = String(frame);
      el.dataset.ready = 'true';
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, []);

  return <span className={`pixel-character ${className}`} role="img"
    aria-label={`${name}：${EXPR_LABEL[expr]}`} data-build={look.build ?? 'standard'}
    data-face={look.faceShape ?? 'original'} data-portrait={portrait} data-renderer="original-art"
    style={{ width: size, height: size }}>
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src={`/portraits/${portrait}/${FRAMES[expr]}.webp`} alt="" width={256} height={256} style={{ opacity: loaded ? 0 : 1 }} />
    <canvas ref={canvas} width={256} height={256} aria-hidden="true" style={{ opacity: loaded ? 1 : 0 }} />
  </span>;
}
