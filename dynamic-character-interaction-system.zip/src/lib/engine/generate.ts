import type { Classification } from './classify';
import type { CharDef } from './chargen';
import { contextualAnswer } from './conversation';
import { EXPR_LABEL, TYPE_LABEL, type Biosign, type CharState, type EcgMode, type GameState, type GlitchLevel, type Hold, type PlanAlert, type ReplyPlan } from './types';

export const TOTAL_QUESTIONS=25;
export function emptyCharState():CharState {
  return {claims:{},repeatText:{},questionCount:0,lastAnswer:'',lastTopic:'',lastTime:'night',peakBpm:0,flatCount:0,history:[],contradictions:[]};
}
export function emptyState():GameState {
  return {chars:{'1':emptyCharState(),'2':emptyCharState(),'3':emptyCharState()},notes:[],observations:[]};
}
export function loadState(json:string|null|undefined):GameState {
  try {
    const parsed=JSON.parse(json??'{}') as Partial<GameState>;
    const state=emptyState();
    for(const id of ['1','2','3'])state.chars[id]={...emptyCharState(),...parsed.chars?.[id]};
    state.notes=parsed.notes??[];state.observations=parsed.observations??[];state.decisions=parsed.decisions;
    return state;
  }catch{return emptyState();}
}

const WEIGHTS:Record<string,number>={provocation:1,accusation:.88,AI_detection:.75,contradiction:.73,alibi:.51,emotion:.44,memory:.28,family:.25,repeated_question:.48,reconfirm:.30,personal:.15,daily:.13,greeting:.08,unknown:.22,opening:.08};
const rand=(a:number,b:number)=>a+Math.random()*(b-a);
const round1=(n:number)=>Math.round(n*10)/10;

/** 質問の重さ（0〜1）。心拍・波形の乱れ方の基準になる */
export function stressOf(cl:Classification,contradicted:boolean):number {
  let stress=WEIGHTS[cl.baseType]??.22;
  if(cl.topic==='compliment')stress=.32;
  if(cl.topic==='location'&&cl.timeBucket==='night')stress=.66;
  if(cl.topic==='companion')stress=.55;
  if(cl.topic==='fear'||cl.topic==='detention')stress=.68;
  if(cl.topic==='evidence')stress=.82;
  if(contradicted)stress=Math.max(stress,.78);
  return stress;
}

interface Reaction { bio:Biosign; alert?:PlanAlert; glitch:GlitchLevel; anomaly:boolean; }

/**
 * 生体応答・警告・グリッチを決める。
 * 人間も動揺で心拍が上がり、フェイカーも多くの場合は「正常に見える」反応を返す。
 * 異常（電子的な波形・グリッチ）は確率的にしか漏れない。
 */
export function react(c:CharDef,cl:Classification,isAI:boolean,contradicted:boolean):Reaction {
  const stress=stressOf(cl,contradicted);
  const rest=c.restBpm;
  const important=stress>=.5;
  const gain=c.persona==='hot'?1.25:c.persona==='quiet'?.7:1;
  let delta:number,hrv:number,pupil:number,ecg:EcgMode,anomaly=false;
  if(!isAI){
    delta=stress*rand(28,44)*gain;
    hrv=Math.max(1.4,rand(2.5,5.6)*(c.persona==='quiet'?.7:1));
    pupil=.34+stress*.36+rand(0,.07);
    ecg=stress>=.6?'erratic':stress>=.3?'tense':'steady';
  } else {
    const style=c.aiStyle;
    const actsNormal=Math.random()<(style==='mechanical'?.3:style==='humanlike'?.6:.5);
    if(actsNormal){
      delta=stress*rand(14,22);hrv=rand(1.6,3.0);pupil=.36+stress*.3;
      ecg=stress>=.6&&Math.random()<.4?'tense':'steady';
    } else if(style==='mechanical'){
      delta=0;hrv=rand(.2,.5);pupil=.34;ecg='synthetic';
    } else if(style==='humanlike'){
      delta=stress*rand(10,16);hrv=rand(1,2);pupil=.37+stress*.22;ecg='synthetic';
    } else {
      delta=stress*rand(12,28);hrv=rand(1.1,2.2);pupil=.43+stress*.27;ecg='synthetic';
    }
    const anomalyChance=important?(style==='mechanical'?.2:style==='humanlike'?.28:.34):.03;
    anomaly=Math.random()<anomalyChance;
    if(anomaly){delta=rand(20,34);hrv=rand(.1,.4);ecg='glitched';pupil=Math.min(.82,pupil+.18);}
  }

  // 警告の判定
  const rawDelta=delta;
  let alert:PlanAlert|undefined;
  if(contradicted)alert={kind:'lie',reason:'発言の矛盾を検知',at:'answer',peakBpm:0};
  else if(cl.baseType==='contradiction'&&(rawDelta>=14||anomaly))alert={kind:'contradiction',reason:'矛盾の指摘に強く反応',at:'reaction',peakBpm:0};
  else if(cl.topic==='evidence'&&(rawDelta>=12||anomaly))alert={kind:'evidence',reason:'証拠提示に反応',at:'reaction',peakBpm:0};
  else if(anomaly)alert={kind:'anomaly',reason:'異常波形を検知',at:'reaction',peakBpm:0};
  else if(['accusation','provocation','AI_detection'].includes(cl.baseType)&&rawDelta>=22)alert={kind:'shaken',reason:'強い動揺を検知',at:'reaction',peakBpm:0};

  if(alert&&!anomaly){
    if(delta<18)delta=rand(18,26);
    if(isAI)ecg=Math.random()<.55?'glitched':'erratic';
    else ecg='erratic';
  }
  const bpm=round1(rest+delta);
  if(alert)alert.peakBpm=Math.round(bpm);

  // Character artwork is never corrupted. Anomalies remain in the ECG only.
  const glitch:GlitchLevel=0;

  return {
    bio:{bpm,hrv:round1(hrv),pupil:Math.min(.85,Math.round(pupil*100)/100),flat:stress>.6&&Math.abs(bpm-rest)<3,ecg,stress:Math.round(stress*100)/100},
    alert,glitch,anomaly,
  };
}

export function generateReply(c:CharDef,raw:string,cl:Classification,s:CharState,isAI:boolean,state:GameState):ReplyPlan {
  const result=contextualAnswer(c,raw,cl,s,isAI);
  const reaction=react(c,cl,isAI,!!result.contradiction);
  const bio=reaction.bio;
  const important=['alibi','provocation','contradiction','accusation','AI_detection'].includes(cl.baseType);
  const delay=isAI&&c.aiStyle==='mechanical'?430:Math.round((c.persona==='quiet'?730:c.persona==='hot'?300:490)+Math.random()*(isAI?470:720));
  let pre:Hold[];
  if(cl.topic==='compliment')pre=[{expr:'surprise',ms:220},{expr:'blush',ms:340}];
  else if(cl.baseType==='provocation')pre=[{expr:'surprise',ms:180},{expr:c.persona==='hot'?'tension':'unease',ms:360}];
  else if(cl.baseType==='alibi')pre=[{expr:'normal',ms:200+Math.round(Math.random()*120)},{expr:'thinking',ms:360},{expr:c.persona==='quiet'?'suspicion':'tension',ms:240}];
  else if(cl.baseType==='contradiction')pre=[{expr:'surprise',ms:200},{expr:'confusion',ms:380}];
  else if(cl.baseType==='AI_detection')pre=[{expr:'normal',ms:270},{expr:c.persona==='hot'?'suspicion':'unease',ms:300}];
  else pre=[{expr:cl.baseType==='daily'||cl.baseType==='memory'?'thinking':'normal',ms:180+Math.round(Math.random()*230)}];
  if(cl.repeatCount>=2)pre=[{expr:'confusion',ms:250},{expr:c.persona==='hot'?'anger':'pout',ms:300}];
  if(reaction.alert)pre=[...pre.slice(0,1),{expr:reaction.anomaly||isAI?'agitation':'anxiety',ms:260},...pre.slice(1)];
  const segments:ReplyPlan['segments']=[{text:result.text}];
  if(isAI&&c.aiStyle==='emotive'&&cl.baseType==='AI_detection'&&s.history.filter(h=>h.type==='AI_detection').length===0){
    const at=result.text.indexOf('。');
    if(at>=0&&at<result.text.length-2)segments.splice(0,1,{text:result.text.slice(0,at+1)},{text:result.text.slice(at+1),before:{expr:'blank',ms:1250}});
  }
  const post:Hold[]=[{expr:result.expr,ms:430},{expr:important?'thinking':cl.topic==='compliment'?'embarrassed':'faint',ms:400}];
  const plan:ReplyPlan={delay,pre,segments,post,mainExpr:result.expr,bio,contradiction:result.contradiction,observed:important||!!reaction.alert,glitch:reaction.glitch,alert:reaction.alert};
  const responseSeconds=(delay+pre.reduce((a,h)=>a+h.ms,0))/1000;
  if(result.contradiction)state.notes.unshift(`${c.name}：証言に矛盾を確認。直前のアリバイを訂正。`);
  if(reaction.alert)state.notes.unshift(`${c.name}：RED ALERT「${reaction.alert.reason}」。BPM ${bio.bpm.toFixed(0)}（基準 ${c.restBpm}）／波形 ${bio.ecg==='glitched'?'電子的なノイズ':bio.ecg==='erratic'?'不整':'乱れ'}。`);
  else if(important)state.notes.unshift(`${c.name}：${TYPE_LABEL[cl.baseType]}に${responseSeconds.toFixed(1)}秒で応答。BPM ${bio.bpm.toFixed(0)}（基準 ${c.restBpm}）／${EXPR_LABEL[result.expr]}。`);
  if(bio.flat)state.notes.unshift(`${c.name}：感情的な問いに対し、心拍・瞳孔の変動がほとんどない。`);
  state.notes=state.notes.slice(0,40);
  s.questionCount++;s.lastAnswer=result.text;s.lastTopic=cl.topic;s.lastBio=bio;s.peakBpm=Math.max(s.peakBpm,bio.bpm);if(bio.flat)s.flatCount++;
  s.history.push({question:raw,answer:result.text,topic:cl.topic,type:cl.baseType});
  s.repeatText[cl.refKey]??=result.text;
  return plan;
}
