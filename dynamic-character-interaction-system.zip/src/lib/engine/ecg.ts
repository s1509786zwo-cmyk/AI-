import type { Biosign, EcgMode } from './types';

export const ECG_SAMPLE_RATE = 120;
export const ECG_SWEEP_SPEED = 62;
export const ALERT_DURATION_MS = 2300;
export const RECOVERY_DURATION_MS = 18000;
const clamp = (value: number, min: number, max: number) => Math.min(max, Math.max(min, value));
const lerp = (from: number, to: number, amount: number) => from + (to - from) * amount;

/** Fictional game telemetry, not a clinical diagnostic model. */
export function restingVitals(bpm: number): Biosign {
  return { bpm, hrv: 4.2, pupil: 0.38, flat: false, ecg: 'steady', stress: 0.06 };
}

/** A short response peak, then a gradual return to baseline. History retains the original peak. */
export function recoverVitals(reaction: Biosign, baseline: number, elapsedMs: number): Biosign {
  const elapsed = Math.max(0, elapsedMs);
  if (elapsed <= 3500) return { ...reaction };
  const amount = clamp((elapsed - 3500) / (RECOVERY_DURATION_MS - 3500), 0, 1);
  const remaining = Math.pow(1 - amount, 2);
  const ecg: EcgMode = remaining > 0.7
    ? reaction.ecg === 'glitched' ? 'tense' : reaction.ecg ?? 'steady'
    : remaining > 0.35 && (reaction.stress ?? 0) > 0.45 ? 'tense' : 'steady';
  return {
    bpm: lerp(baseline, reaction.bpm, remaining),
    hrv: lerp(4.2, reaction.hrv, remaining),
    pupil: lerp(0.38, reaction.pupil, remaining),
    flat: reaction.flat && remaining > 0.7,
    ecg,
    stress: lerp(0.06, reaction.stress ?? 0.2, remaining),
  };
}

export interface EcgInput {
  bpm: number;
  hrv: number;
  stress: number;
  mode: EcgMode;
  alert: boolean;
}
export interface EcgSample {
  value: number;
  bpm: number;
  beat: boolean;
  beatPhase: number;
}

/** Narrow P-QRS-T pulse: it still fits a full beat at high BPM. */
export function cardiacPulse(seconds: number, premature = false): number {
  if (seconds < 0) return 0;
  if (premature) {
    if (seconds < 0.04) return 0;
    if (seconds < 0.17) return Math.sin((seconds - 0.04) / 0.13 * Math.PI) * 0.98;
    if (seconds < 0.37) return -Math.sin((seconds - 0.17) / 0.2 * Math.PI) * 0.32;
    return 0;
  }
  if (seconds < 0.07) return Math.sin(seconds / 0.07 * Math.PI) * 0.1;
  if (seconds < 0.1) return 0;
  if (seconds < 0.115) return -0.13 * (seconds - 0.1) / 0.015;
  if (seconds < 0.145) return -0.13 + 1.13 * (seconds - 0.115) / 0.03;
  if (seconds < 0.185) return 1 - 1.3 * (seconds - 0.145) / 0.04;
  if (seconds < 0.215) return -0.3 + 0.3 * (seconds - 0.185) / 0.03;
  if (seconds < 0.26) return 0;
  if (seconds < 0.44) return Math.sin((seconds - 0.26) / 0.18 * Math.PI) * 0.23;
  return 0;
}

/** Fixed-time sampler: cadence, waveform, beat marker and BPM all use the SAME intervals. */
export class EcgSimulator {
  private elapsed = 0;
  private sinceBeat = 0;
  private interval: number;
  private target: number;
  private reading: number;
  private amplitude = 1;
  private premature = false;
  private freezeSeconds = 0;
  private frozenValue = 0;
  private noiseSeconds = 0;
  private lastMode: EcgMode = 'steady';
  private random: () => number;

  constructor(bpm = 72, random: () => number = Math.random) {
    this.target = clamp(bpm, 40, 180);
    this.reading = this.target;
    this.interval = 60 / this.target;
    this.random = random;
  }

  next(input: EcgInput, dt = 1 / ECG_SAMPLE_RATE): EcgSample {
    const seconds = clamp(dt, 0, 0.1);
    const mode = input.mode;
    this.elapsed += seconds;
    this.sinceBeat += seconds;
    this.target = lerp(this.target, clamp(input.bpm, 40, 180), Math.min(1, seconds * (input.alert ? 4 : 1.6)));
    if (mode !== this.lastMode) {
      this.freezeSeconds = 0;
      this.noiseSeconds = 0;
      this.lastMode = mode;
    }
    let beat = false;
    if (this.sinceBeat >= this.interval) {
      beat = true;
      this.sinceBeat -= this.interval;
      const base = 60 / this.target;
      // HRV in ms, with mild respiratory variability. Not an extra hidden tachycardia multiplier.
      const variance = clamp(input.hrv / 65, 0.002, 0.09);
      const mechanical = mode === 'synthetic' || mode === 'glitched';
      let interval = base + (this.random() * 2 - 1) * base * variance;
      this.premature = false;
      if (mode === 'erratic' && this.random() < 0.07) {
        this.premature = true;
        interval = base * (0.8 + this.random() * 0.1);
      }
      if (mode === 'tense') interval += Math.sin(this.elapsed * 0.9) * base * 0.026;
      if (mechanical && input.hrv < 0.7) interval = Math.round(interval * 200) / 200;
      this.interval = clamp(interval, 0.33, 1.5);
      this.reading = lerp(this.reading, 60 / this.interval, 0.62);
      this.amplitude = mechanical ? 1 : mode === 'erratic' ? 0.8 + this.random() * 0.38 : 0.94 + this.random() * 0.12;
    }
    let value = cardiacPulse(this.sinceBeat, this.premature) * this.amplitude;
    if (mode === 'steady') value += Math.sin(this.elapsed * 1.6) * 0.023 + (this.random() - 0.5) * 0.014;
    else if (mode === 'tense') value += Math.sin(this.elapsed * 2.1) * 0.05 + (this.random() - 0.5) * 0.05;
    else if (mode === 'erratic') value += Math.sin(this.elapsed * 2.9) * 0.065 + (this.random() - 0.5) * (0.07 + input.stress * 0.08);
    else if (mode === 'synthetic') value = Math.round(value * 24) / 24;
    else if (mode === 'glitched') {
      value = Math.round(value * 12) / 12;
      if (this.freezeSeconds > 0) {
        this.freezeSeconds -= seconds;
        value = this.frozenValue;
      } else if (this.noiseSeconds > 0) {
        this.noiseSeconds -= seconds;
        value += Math.sin(this.elapsed * 160) * 0.22;
      } else {
        const roll = this.random();
        // Noise is rare per SECOND (not per animation frame).
        if (roll < seconds * (input.alert ? 3 : 0.8)) value += (this.random() < 0.5 ? -1 : 1) * (0.35 + this.random() * 0.35);
        else if (roll < seconds * 1.6) { this.freezeSeconds = 0.05 + this.random() * 0.06; this.frozenValue = value; }
        else if (roll < seconds * 2.4) this.noiseSeconds = 0.1;
      }
    }
    if (input.alert) value += (this.random() - 0.5) * 0.1;
    return { value: clamp(value, -1.1, 1.25), bpm: this.reading, beat, beatPhase: this.sinceBeat };
  }
}
