import type { AiStyle, Bucket, Build, ExprId, FaceShape, FeatureId, Gender, IdleStyle, Look, Persona, PortraitId } from './types';

export type SpeechId = 'polite' | 'rough' | 'kansai' | 'ojou' | 'shy' | 'casual' | 'flat' | 'terse';
export interface CharacterProfile {
  favoriteFood: string;
  dislikedFood: string;
  drink: string;
  hobby: string;
  hobbyDetail: string;
  favoriteColor: string;
  music: string;
  family: string[];
  familyMemory: string;
  hometown: string;
  address: string;
  pet: string;
  dream: string;
  fear: string;
  childhood: string;
  distinguishing: string;
  dinner: string;
  lunch: string;
  breakfast: string;
  mealTime: string;
  companion: string;
  companionName: string;
  schedule: Record<Bucket, { location: string; activity: string; time: string; evidence: string }>;
}
export interface CharDef {
  id: string;
  name: string;
  age: number;
  job: string;
  gender: Gender;
  persona: Persona;
  personaLabel: string;
  speechId: SpeechId;
  speechLabel: string;
  trait: string;
  aiStyle: AiStyle;
  aiStyleLabel: string;
  aiReveal: string[];
  look: Look;
  opening: string;
  openingExpr: ExprId;
  idleExpr: ExprId;
  restBpm: number;
  appearance: string;
  profile: CharacterProfile;
}
export type PublicCharacter = Pick<CharDef, 'id' | 'name' | 'age' | 'job' | 'gender' | 'persona' | 'personaLabel' | 'speechId' | 'speechLabel' | 'trait' | 'look' | 'opening' | 'openingExpr' | 'idleExpr' | 'restBpm' | 'appearance'>;

export type HairGroup = 'short' | 'bob' | 'shaggy' | 'braided';
export interface ArtStyle {
  id: PortraitId; gender: Gender; label: string; hair: Look['hair']; color: string;
  outfit: Look['outfit']; glasses?: boolean; hairGroup: HairGroup; outfitGroup: string;
  hairText: string; outfitText: string; face: FaceShape; preferredBuild: Build;
  features: FeatureId[]; eyeColor: string; ageRange: [number,number];
}

// Four independent original drawings; not recolor/stretch/accessory variants.
export const ART_STYLES: ArtStyle[] = [
  { id:'kei', gender:'m', label:'ケイ', hair:'shortNeat', color:'#34364f', eyeColor:'#839eb5', outfit:'blazer', glasses:true, hairGroup:'short', outfitGroup:'trenchCoat', hairText:'額を出した紺色の短髪', outfitText:'薄茶のコート・白シャツ・細いネクタイ', face:'oval', preferredBuild:'slim', features:[], ageRange:[25,32] },
  { id:'mori', gender:'m', label:'モリ', hair:'wavyMid', color:'#574849', eyeColor:'#9c8564', outfit:'hoodie', hairGroup:'shaggy', outfitGroup:'hoodieScarf', hairText:'耳元まで伸びた、くせのある茶色の髪', outfitText:'ゆったりした緑のパーカー・厚手のマフラー', face:'round', preferredBuild:'broad', features:['stubble','eyebags'], ageRange:[34,43] },
  { id:'ruri', gender:'f', label:'ルリ', hair:'bob', color:'#a65f62', eyeColor:'#6daba9', outfit:'guard', hairGroup:'bob', outfitGroup:'utilityJacket', hairText:'片側を耳にかけた赤茶色のショートボブ', outfitText:'立ち襟の白いショートジャケット', face:'heart', preferredBuild:'petite', features:['earring'], ageRange:[22,28] },
  { id:'nagi', gender:'f', label:'ナギ', hair:'longStraight', color:'#b7b9d1', eyeColor:'#9d86bf', outfit:'sailor', hairGroup:'braided', outfitGroup:'frilledDress', hairText:'銀色の髪と、二本の長い三つ編み', outfitText:'フリル襟の紺色ワンピース・リボン・星の髪飾り', face:'angular', preferredBuild:'standard', features:[], ageRange:[23,31] },
];
export const BUILD_TEXT:Record<Build,string>={slim:'細身',standard:'すらっとした体格',broad:'大柄で広い肩幅',petite:'小柄'};
export const FEATURE_TEXT:Record<FeatureId,string>={stubble:'顎のひげ',eyebags:'目の下の隈',earring:'片耳のリングピアス',browPiercing:'眉のピアス',plaster:'絆創膏',mole:'ほくろ',scar:'傷'};
const IDLE_TEXT:Record<IdleStyle,string>={steady:'落ち着いた話し方',tired:'穏やかな口調',restless:'気持ちを言葉に出しやすい'};
const LEGACY_ART:Record<string,PortraitId>={analyst:'kei',noir:'kei',blue:'kei',ash:'mori',rose:'mori',lilac:'ruri',peach:'nagi',ivory:'nagi',mint:'nagi'};
function shuffled<T>(items:T[]):T[]{const list=[...items];for(let i=list.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[list[i],list[j]]=[list[j],list[i]];}return list;}
function artFor(id:PortraitId):ArtStyle{return ART_STYLES.find(a=>a.id===id)??ART_STYLES.find(a=>a.id===LEGACY_ART[id])??ART_STYLES[0];}
function originalLook(art:ArtStyle,idle:IdleStyle):Look {
  return {portrait:art.id,hue:0,saturation:100,build:art.preferredBuild,faceShape:art.face,nativeShape:true,wardrobe:'original',features:[...art.features],idleStyle:idle,skin:'light',hair:art.hair,hairColor:art.color,eyeColor:art.eyeColor,outfit:art.outfit,outfitColor:art.color,outfitSub:'#d1c4d9',acc:'none',accColor:'#d1c4d9',glasses:!!art.glasses};
}
function describe(art:ArtStyle):string {
  const face={oval:'細面で小さめの目',round:'丸みのある広い顔',heart:'小さな顎と切れ長の目',angular:'すっきりした輪郭と丸い瞳'}[art.face];
  return [art.hairText,face,BUILD_TEXT[art.preferredBuild],art.outfitText,...(art.glasses?['四角い眼鏡']:[]),...art.features.map(f=>FEATURE_TEXT[f])].join('・');
}
const surnames = ['白瀬','星野','天城','冬月','水無瀬','藤堂','綾瀬','東雲','久遠','九条','灰原','南','柊','八雲','橘','鳴海','真崎','花宮','月城','一ノ瀬','桐生','相馬','氷室','榊'];
const firstF = ['ゆき','ひかり','澪','奏','紬','雫','灯','咲良','結','真冬','ひより','莉子','すず','楓'];
const firstM = ['蓮','湊','律','蒼','透','翼','朔','伊織','慧','類','晴','凪','千尋','そら'];
const jobs = ['電脳書庫司書','記憶整備士','夜間カフェ店員','ネオン修理技師','声帯クリニック職員','記録局事務員','地下鉄駅員','配達ドライバー','古書店員','音楽教室講師','温室管理人','保安警備員'];
const speechLabels: Record<SpeechId,string> = { polite:'丁寧な敬語', rough:'ぶっきらぼう', kansai:'関西ことば', ojou:'上品な話し方', shy:'控えめ・人見知り', casual:'親しみやすい', flat:'落ち着いた口調', terse:'短く、静かに' };
const personaLabels: Record<Persona,string> = { gentle:'温厚', hot:'気が強い', quiet:'もの静か' };
const hobbies = [
  ['古い本を集めること','紙の端が日焼けしている本が好き。ページをめくる匂いが落ち着く'],
  ['ピアノ','夜は消音ペダルで弾く。いつか誰かの前で一曲弾いてみたい'],
  ['小さな鉢植えを育てること','窓辺に多肉植物を三つ並べている。名前もつけている'],
  ['星を見ること','街の光が強いから、屋上でいちばん暗い方角を見る'],
  ['お菓子作り','クッキーの端っこを焦がしがち。そこだけ自分で食べる'],
  ['猫の写真を撮ること','駅の裏にいる白い猫を撮る。まだ名前は決めていない'],
  ['古いゲーム','セーブできないゲームが好き。一度きりって、なんだか人間らしい'],
  ['雨の音を録音すること','屋根や傘で音が変わる。眠れない夜に聞き返す'],
];
export const pick = <T,>(items: T[]): T => items[Math.floor(Math.random()*items.length)];
const integer = (a:number,b:number) => a+Math.floor(Math.random()*(b-a+1));
export function characterVoice(cd: Pick<CharDef,'speechId'|'gender'>, plain:string, polite?:string, short?:string): string {
  const first = cd.gender === 'f' ? 'わたし' : '僕';
  let text = plain.replace(/私/g, first);
  switch (cd.speechId) {
    case 'polite': return polite ?? text;
    case 'ojou': return (polite ?? text).replace(/です([。！？])/g,'ですわ$1').replace(/ます([。！？])/g,'ますわ$1');
    case 'shy': return 'あの……'+(polite ?? text);
    case 'rough': return text.replace(/僕|わたし/g,cd.gender==='m'?'俺':'あたし').replace(/だよ/g,'だ').replace(/だね/g,'だな').replace(/なんだ/g,'なんだよ');
    case 'kansai': return text.replace(/僕|わたし/g,cd.gender==='m'?'俺':'うち').replace(/だよ/g,'やで').replace(/だね/g,'やな').replace(/なんだ/g,'なんや').replace(/かな([。？])/g,'やろか$1').replace(/だから/g,'せやから').replace(/ないよ/g,'ないねん');
    case 'flat': return polite ?? text;
    case 'terse': return '……'+(short ?? text.split(/(?<=[。！？])/)[0]);
    default: return text;
  }
}

export function generateCharacter(options: { gender?:Gender; portrait?:PortraitId; hue?:number; build?:Build; features?:FeatureId[]; idleStyle?:IdleStyle } = {}): CharDef {
  const art = options.portrait ? artFor(options.portrait) : pick(ART_STYLES.filter(a=>!options.gender || a.gender===options.gender));
  const gender = art.gender;
  const persona = pick<Persona>(['gentle','hot','quiet']);
  const speechId = pick<SpeechId>(persona==='quiet'?['terse','shy','flat','polite']:persona==='hot'?['rough','kansai','casual','ojou']:['polite','shy','casual','kansai','ojou']);
  const [hobby,hobbyDetail] = pick(hobbies);
  const food = pick(['いちごのショートケーキ','焼きたてのパン','ラーメン','オムライス','クリームシチュー','桃のタルト','焼き魚','カレー']);
  const sibling = pick(['妹','弟','姉','兄']);
  const family = pick([['母',sibling],['父','母'],['母'],['姉'],['父','母',sibling]]);
  const schedule: CharacterProfile['schedule'] = {
    morning:{location:'職場',activity:'開店前の準備をしていた',time:'8時12分',evidence:'出勤記録'},
    noon:{location:pick(['駅前の食堂','職場の休憩室','屋上のベンチ']),activity:'昼ごはんを食べていた',time:'12時18分',evidence:'食事の決済記録'},
    evening:{location:'職場',activity:'残って片付けをしていた',time:'18時37分',evidence:'退勤記録'},
    night:{location:pick(['自宅','友人の部屋','駅前のカフェ']),activity:pick(['本を読んでいた','古い音楽を聴いていた','夕食の後片付けをしていた']),time:'21時04分',evidence:pick(['通話履歴','カフェのレシート','部屋の鍵の記録'])},
    late:{location:'自宅',activity:'眠ろうとしていた',time:'23時12分',evidence:'端末の充電記録'},
  };
  const aiStyle = pick<AiStyle>(['humanlike','mechanical','emotive']);
  const cd: CharDef = {
    id:Math.random().toString(36).slice(2,10),
    name:`${pick(surnames)} ${pick(gender==='f'?firstF:firstM)}`,
    age:integer(art.ageRange[0],art.ageRange[1]),job:pick(jobs),gender,persona,personaLabel:personaLabels[persona],speechId,speechLabel:speechLabels[speechId],
    trait:pick(persona==='gentle'?['人の名前をよく覚える','褒められると目をそらす','好きな話題だとよく話す']:persona==='hot'?['嘘をつかれるのが苦手','心配を隠して強がる','納得できないと聞き返す']:['考えてから話す','沈黙を気にしない','思い出には少し饒舌']),
    aiStyle,aiStyleLabel:aiStyle==='mechanical'?'生体制御型':aiStyle==='emotive'?'感情模倣型':'高度擬態型',
    aiReveal:aiStyle==='mechanical'?['追及の前後で心拍がほとんど変わらなかった。','同じ質問に、語句まで同じ回答を返した。','感情の言葉と、瞳孔の反応が一致しなかった。']:aiStyle==='humanlike'?['思い出の語り方は自然だが、心拍変動が小さすぎた。','時刻についてだけ、過剰に詳しい記憶が現れた。','再確認されても、記憶が揺らぐ様子が少なかった。']:['表情は変わるが、生体反応の幅が整いすぎていた。','言葉の途中に、長い不自然な沈黙があった。','感情と証言の両方を見る必要があった。'],
    look:originalLook(art,options.idleStyle??pick<IdleStyle>(['steady','tired','restless'])),
    opening:'',openingExpr:persona==='hot'?'suspicion':persona==='quiet'?'normal':'faint',idleExpr:'normal',restBpm:integer(65,83),appearance:'',
    profile:{favoriteFood:food,dislikedFood:pick(['苦い野菜','辛すぎるもの','冷えたごはん']),drink:pick(['ミルクティー','ブラックコーヒー','温かいココア','桃の紅茶']),hobby,hobbyDetail,favoriteColor:pick(['ラベンダー','夜の青','淡いピンク','ミント色']),music:pick(['古いピアノ曲','雨音の入った環境音楽','昔のロック','静かなジャズ']),family,familyMemory:`${family[family.length-1]}が冬に編んでくれたマフラーを、まだ持っている`,hometown:pick(['北区','海沿いの旧市街','第五居住区','東区']),address:`第${integer(2,9)}居住区の${integer(2,12)}階`,pet:pick(['白い猫','小さな文鳥','ペットはいない']),dream:pick(['海の見える街で小さな店を開くこと','自分の作ったものを誰かに覚えてもらうこと','家族と安心して暮らすこと','一度、街の外で星を見ること']),fear:pick(['大切な人を忘れてしまうこと','誰も自分を覚えていないこと','本物の人間なのに処分されること']),childhood:pick(['夏休みに、川の石を集めていた。青い石を一つだけ宝物にしていた','雨の日に家族とホットケーキを焼いた。最初の一枚だけ真っ黒になった','駅の前で迷子になった。迎えに来た母のコートの匂いを覚えている']),distinguishing:'',dinner:pick(['焼き魚とごはん','カレー','オムライス','トマトのパスタ','野菜のスープ']),lunch:pick(['サンドイッチ','ラーメン','おにぎり']),breakfast:pick(['トーストと卵','ヨーグルト','お茶だけ']),mealTime:'19時14分',companion:pick(['一人','友人','家族']),companionName:`${pick(surnames)} ${pick(firstF)}`,schedule},
  };
  cd.profile.distinguishing=cd.trait;
  cd.look.hue=0;
  cd.idleExpr=cd.look.idleStyle==='tired'?'sleepy':'normal';
  cd.appearance=describe(art);
  cd.opening=characterVoice(cd,persona==='hot'?'何を聞きたい？ ……ちゃんと話は聞くよ。':persona==='quiet'?'何から、話せばいい？':'……何を聞きたいの？ 答えられることなら、話すよ。',persona==='hot'?'用件を聞かせてください。疑われるのは、好きじゃありません。':'……何を聞きたいんですか？ 答えられることなら、お話しします。','何を、聞きたい？');
  return cd;
}
/** Select three distinct ORIGINAL portraits. Physiology/AI identity is sampled separately. */
export function generateCast():CharDef[] {
  const arts=shuffled(ART_STYLES).slice(0,3);
  const idles=shuffled<IdleStyle>(['steady','tired','restless']);
  const names=new Set<string>();
  return arts.map((art,i)=>{
    let person=generateCharacter({portrait:art.id,idleStyle:idles[i]});
    while(names.has(person.name))person=generateCharacter({portrait:art.id,idleStyle:idles[i]});
    names.add(person.name);return person;
  });
}
/** Old saves keep their names, facts, answers, and AI assignments; only artwork changes. */
export function loadCast(json:string|null|undefined):CharDef[] {
  if(json){try{
    const list=JSON.parse(json) as CharDef[];
    if(Array.isArray(list)&&list.length===3&&list.every(c=>c.profile&&c.look)){
      const used=new Set<PortraitId>();
      return list.map(c=>{
        let art=artFor(c.look.portrait??'ruri');
        if(used.has(art.id))art=ART_STYLES.find(a=>a.gender===c.gender&&!used.has(a.id))??ART_STYLES.find(a=>!used.has(a.id))!;
        used.add(art.id);
        return {...c,look:originalLook(art,c.look.idleStyle??'steady'),appearance:describe(art)};
      });
    }
  }catch{}}
  return generateCast();
}
export function publicCharacter(c:CharDef):PublicCharacter {
  const {id,name,age,job,gender,persona,personaLabel,speechId,speechLabel,trait,look,opening,openingExpr,idleExpr,restBpm,appearance}=c;
  return {id,name,age,job,gender,persona,personaLabel,speechId,speechLabel,trait,look,opening,openingExpr,idleExpr,restBpm,appearance};
}
