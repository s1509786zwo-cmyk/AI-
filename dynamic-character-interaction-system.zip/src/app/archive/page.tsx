"use client";
import { useEffect, useState } from 'react';
import { ArrowLeft, RefreshCw, Sparkles, Play, Pause } from 'lucide-react';
import Link from 'next/link';
import { Header } from '@/components/Header';
import { Modal } from '@/components/Modal';
import { PixelCharacter } from '@/components/PixelCharacter';
import { ART_STYLES, generateCharacter, type CharDef } from '@/lib/engine/chargen';
import { EXPRESSIONS, EXPR_LABEL, type ExprId, type Gender } from '@/lib/engine/types';
function roster() { return ART_STYLES.map(a => generateCharacter({ portrait: a.id })); }

export default function Archive() {
  const [chars, setChars] = useState<CharDef[]>([]);
  const [gender, setGender] = useState<Gender | 'all'>('all');
  const [selected, setSelected] = useState<CharDef | null>(null);
  const [expression, setExpression] = useState<ExprId>('normal');
  const [playing, setPlaying] = useState(false);
  useEffect(() => setChars(roster()), []);
  useEffect(() => {
    if (!playing) return;
    let i = EXPRESSIONS.indexOf(expression);
    const timer = setInterval(() => setExpression(EXPRESSIONS[++i % EXPRESSIONS.length]), 1400);
    return () => clearInterval(timer);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [playing]);
  const filtered = chars.filter(c => gender === 'all' || c.gender === gender);
  return <div className="archive-page"><Header /><main className="archive-main">
    <div className="archive-header"><div><div className="eyebrow">ORIGINAL PORTRAITS / FOUR DISTINCT PEOPLE</div><h1>人物アーカイブ</h1><p>顔立ちも、髪型も、服も。それぞれ別の原画から描いた4人。<br />横伸ばし・色替え・ノイズ加工を使わず、そのままの絵を表示しています。</p></div><Link href="/" className="secondary-button"><ArrowLeft size={13} />尋問室へ戻る</Link></div>
    <div className="archive-toolbar"><div className="archive-filters">{(['all', 'f', 'm'] as const).map(g => <button key={g} className={`filter-button ${gender === g ? 'selected' : ''}`} onClick={() => setGender(g)}>{g === 'all' ? 'すべて' : g === 'f' ? '女性' : '男性'}</button>)}</div><button className="text-button" onClick={() => setChars(roster())}><RefreshCw size={12} />人物設定を新しく生成</button><span className="eyebrow">{filtered.length} ORIGINAL ARTWORKS</span></div>
    <div className="archive-grid original-archive-grid">{filtered.map((c, i) => <button className="archive-card" key={c.id} onClick={() => { setSelected(c); setExpression('normal'); setPlaying(false); }}>
      <div className="archive-art"><span className="suspect-num">0{i + 1} ／ {ART_STYLES.find(a => a.id === c.look.portrait)?.label}</span><PixelCharacter look={c.look} expr="normal" size={240} name={c.name} /></div>
      <div className="archive-info">{c.name}<small>{c.age}歳 ／ {c.job}</small><span className="original-art-description">{c.appearance}</span><span className="character-tag">{c.speechLabel}</span></div>
    </button>)}</div>
  </main>{selected && <Modal title="原画と表情のプレビュー" kicker={`ORIGINAL ART / ${selected.look.portrait?.toUpperCase()}`} wide onClose={() => { setSelected(null); setPlaying(false); }}>
    <div className="character-detail"><div className="character-detail-art"><PixelCharacter look={selected.look} expr={expression} size={300} name={selected.name} /></div><div><div className="eyebrow">{selected.personaLabel} ／ {selected.speechLabel}</div><h3>{selected.name}</h3><p>{selected.opening}</p><dl><dt>職業</dt><dd>{selected.job} ／ {selected.age}歳</dd><dt>特徴</dt><dd>{selected.trait}</dd><dt>外見</dt><dd>{selected.appearance}</dd><dt>好物</dt><dd>{selected.profile.favoriteFood}</dd><dt>趣味</dt><dd>{selected.profile.hobby}</dd></dl></div></div>
    <div className="section-heading" style={{ marginTop: 24, marginBottom: 8 }}><span className="expression-heading" style={{ marginTop: 0 }}><Sparkles size={13} />表情を選ぶ ／ {EXPR_LABEL[expression]}</span><button className="text-button" onClick={() => setPlaying(p => !p)}>{playing ? <Pause size={12} /> : <Play size={12} />}{playing ? '再生を停止' : '表情を連続再生'}</button></div>
    <div className="expression-picker">{EXPRESSIONS.map(e => <button key={e} className={`filter-button ${e === expression ? 'selected' : ''}`} onClick={() => { setExpression(e); setPlaying(false); }}>{EXPR_LABEL[e]}</button>)}</div>
    <p className="eyebrow" style={{ marginTop: 19, lineHeight: 1.9 }}>22種類の表情と専用の瞬き画像。肌・髪・顔の比率は原画のままです。</p>
  </Modal>}</div>;
}
