import test from 'node:test';
import assert from 'node:assert/strict';
import { cardiacPulse, EcgSimulator, ECG_SAMPLE_RATE, recoverVitals, restingVitals } from '../src/lib/engine/ecg';

const seed = (value:number) => () => { value=(value*1664525+1013904223)>>>0;return value/4294967296; };
const sample = (mode:'steady'|'tense'|'erratic'|'synthetic'|'glitched', bpm=72, alert=false) => {
  const model=new EcgSimulator(bpm,seed(33));const values:number[]=[],rates:number[]=[];const beats:number[]=[];
  for(let i=0;i<ECG_SAMPLE_RATE*45;i++){
    const s=model.next({bpm,hrv:mode==='synthetic'?.3:4.2,stress:mode==='steady'?.1:.8,mode,alert});
    values.push(s.value);rates.push(s.bpm);if(s.beat)beats.push(i/ECG_SAMPLE_RATE);
    assert.ok(Number.isFinite(s.value)&&Number.isFinite(s.bpm));assert.ok(s.value>=-1.1&&s.value<=1.25);
  }
  return {values,rates,beats};
};
test('Cardiac pulse has P/QRS/T excursions and a quiet interval',()=>{
  assert.ok(cardiacPulse(.03)>0);assert.ok(cardiacPulse(.114)<0);assert.ok(cardiacPulse(.145)>.9);assert.ok(cardiacPulse(.184)<0);assert.ok(cardiacPulse(.35)>0);assert.equal(cardiacPulse(.7),0);
});
test('ECG and BPM use identical beat cadence, including during RED ALERT',()=>{
  for(const alert of [false,true]){
    const result=sample('steady',90,alert);
    const measured=(result.beats.length-1)*60/(result.beats.at(-1)!-result.beats[0]);
    assert.ok(Math.abs(measured-90)<4,`${measured} BPM`);
    assert.ok(Math.abs(result.rates.at(-1)!-measured)<8);
  }
});
test('Heart rate is different for 60 and 120 BPM and still updates at real-time sample rate',()=>{
  const low=sample('steady',60),high=sample('steady',120);
  assert.ok(high.beats.length/low.beats.length>1.85);
  assert.ok(new Set(low.rates.map(Math.round)).size>2);
});
test('Normal, frightened, irregular and electronic traces are not the same',()=>{
  const normal=sample('steady'),fear=sample('tense'),irregular=sample('erratic'),electronic=sample('glitched');
  assert.notDeepEqual(normal.values,fear.values);assert.notDeepEqual(fear.values,irregular.values);assert.notDeepEqual(irregular.values,electronic.values);
  const deviation=(v:number[])=>v.reduce((a,x)=>a+Math.abs(x),0)/v.length;
  assert.ok(deviation(electronic.values)>deviation(normal.values));
});
test('Peak telemetry settles after the transient event, without changing its archived value',()=>{
  const reaction={bpm:120,hrv:.4,pupil:.76,flat:false,ecg:'glitched' as const,stress:.9};
  assert.deepEqual(recoverVitals(reaction,72,1500),reaction);
  const middle=recoverVitals(reaction,72,9000);
  assert.ok(middle.bpm>72&&middle.bpm<120);assert.notEqual(middle.ecg,'glitched');
  const settled=recoverVitals(reaction,72,18000);
  assert.equal(settled.bpm,72);assert.equal(settled.ecg,'steady');assert.equal(settled.pupil,.38);assert.equal(settled.hrv,4.2);
  assert.equal(reaction.bpm,120);assert.equal(reaction.ecg,'glitched');
});
test('Mild and heavy responses remain finite when browser frames are delayed',()=>{
  const model=new EcgSimulator(72,seed(12));
  for(const bpm of [72,128,82,68])for(let i=0;i<80;i++){
    const s=model.next({bpm,hrv:4,stress:.7,mode:'erratic',alert:true},.09);assert.ok(Number.isFinite(s.bpm));assert.ok(s.bpm>=40&&s.bpm<=190);
  }
  assert.deepEqual(restingVitals(72),{bpm:72,hrv:4.2,pupil:.38,flat:false,ecg:'steady',stress:.06});
});
