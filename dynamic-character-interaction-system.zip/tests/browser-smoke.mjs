import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
await mkdir('tests/artifacts',{recursive:true});
const browser=await chromium.launch({headless:true,args:['--no-sandbox']});
const context=await browser.newContext({viewport:{width:1440,height:1000}});
const page=await context.newPage();const issues=[];
page.on('pageerror',e=>issues.push(e.message));
await page.goto('http://127.0.0.1:3000',{waitUntil:'networkidle'});
await page.waitForTimeout(800);
await page.screenshot({path:'tests/artifacts/home.png',fullPage:true});
await page.getByRole('button',{name:'尋問を開始する'}).click();
await page.waitForURL('**/game**',{timeout:10000}).catch(()=>{});
await page.locator('.question-input').waitFor({state:'visible',timeout:20000});
await page.waitForTimeout(600);
const firstName=await page.locator('.suspect-card.selected .suspect-name').innerText();
await page.screenshot({path:'tests/artifacts/game.png',fullPage:true});
// Wait until the opening line is fully finished and the form is idle.
await page.waitForFunction(()=>{
  const input=document.querySelector('.question-input');
  const hint=document.querySelector('.input-hint span');
  return input && !input.disabled && /自由入力/.test(hint?.textContent??'');
},{timeout:20000});
await page.locator('.question-input').fill('名前は？');
await page.locator('.question-input').press('Enter');
const bubble=page.locator('.speech-bubble');
await page.getByRole('button',{name:'全文を表示'}).waitFor({state:'visible',timeout:8000});
await page.getByRole('button',{name:'全文を表示'}).click();
await page.waitForTimeout(400);
await bubble.waitFor({state:'visible'});
assert.ok((await bubble.innerText()).includes(firstName),'speech bubble shows the answer above the character');
assert.ok((await page.locator('.chat-item.suspect .chat-text').last().innerText()).includes(firstName));
assert.equal(await page.locator('.question-count strong').innerText(),'24');
// The start flow must survive missing cookies: rely on the ?case= parameter.
const caseId=new URL(page.url()).searchParams.get('case');
assert.ok(caseId,'game id is carried in the URL');
await context.clearCookies();
await page.goto(`http://127.0.0.1:3000/game?case=${caseId}`,{waitUntil:'networkidle'});
await page.locator('.question-input').waitFor();
assert.equal(await page.locator('.question-count strong').innerText(),'24');
await page.waitForFunction(()=>{
  const input=document.querySelector('.question-input');
  const hint=document.querySelector('.input-hint span');
  return input && !input.disabled && /自由入力/.test(hint?.textContent??'');
},{timeout:20000});
await page.locator('.question-input').fill('好きな食べ物は？');
await page.locator('.question-input').press('Enter');
{
  const ok=await page.getByRole('button',{name:'全文を表示'}).waitFor({state:'visible',timeout:8000}).then(()=>true).catch(()=>false);
  if(!ok){
    const diag=await page.evaluate(()=>({
      val:document.querySelector('.question-input')?.value,
      disabled:document.querySelector('.question-input')?.disabled,
      hint:document.querySelector('.input-hint')?.textContent?.slice(0,60),
      error:document.querySelector('.input-area .error-banner')?.textContent?.slice(0,100)??null,
      msgs:document.querySelectorAll('.chat-item').length,
    }));
    throw new Error('second question did not start: '+JSON.stringify(diag));
  }
}
await page.getByRole('button',{name:'全文を表示'}).click();
await page.waitForTimeout(250);
const favorite=await page.locator('.chat-item.suspect .chat-text').last().innerText();
assert.ok(favorite.includes('好き'));
assert.ok(!favorite.includes(firstName));
await page.reload({waitUntil:'networkidle'});
await page.locator('.question-input').waitFor();
assert.equal(await page.locator('.question-count strong').innerText(),'23');
assert.equal(await page.locator('.chat-item.suspect .chat-text').last().innerText(),favorite);
await page.locator('.suspect-card').nth(1).click();
assert.notEqual(await page.locator('.suspect-card.selected .suspect-name').innerText(),firstName);
await page.getByRole('button',{name:'すべての記録'}).click();
assert.ok((await page.getByRole('dialog').innerText()).includes(firstName));
assert.ok(await page.locator('.history-timeline').count()>0);
await page.getByRole('button',{name:'閉じる',exact:true}).click();
const state=await (await context.request.get(`http://127.0.0.1:3000/api/game?caseId=${caseId}`)).json();
assert.equal('aiSuspect' in state.game,false);
assert.equal('profile' in state.game.cast[0],false);
assert.equal('aiStyle' in state.game.cast[0],false);
await page.goto('http://127.0.0.1:3000/archive',{waitUntil:'networkidle'});
await page.locator('.archive-card').first().waitFor();
assert.equal(await page.locator('.archive-card').count(),4);
await page.getByRole('button',{name:'男性',exact:true}).click();
assert.equal(await page.locator('.archive-card').count(),2);
await page.locator('.archive-card').first().click();
assert.equal(await page.locator('.expression-picker button').count(),22);
await page.getByRole('button',{name:'照れ',exact:true}).click();
await page.waitForTimeout(500);
await page.screenshot({path:'tests/artifacts/archive.png',fullPage:true});
await page.getByRole('button',{name:'閉じる',exact:true}).click();
await page.setViewportSize({width:390,height:844});
await page.goto('http://127.0.0.1:3000/game',{waitUntil:'networkidle'});
await page.locator('.question-input').waitFor();
await page.waitForTimeout(400);
const overflow=await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
assert.equal(overflow,false);
const box=await page.locator('.question-input').boundingBox();assert.ok(box&&box.y+box.height<844);
await page.screenshot({path:'tests/artifacts/mobile.png',fullPage:true});
await page.getByRole('button',{name:'生体モニターを開く'}).click();
assert.ok(await page.getByRole('dialog').isVisible());
await page.getByRole('button',{name:'閉じる',exact:true}).click();
await page.getByRole('button',{name:'最終判定へ'}).click();
await page.locator('.verdict-option.release').nth(0).click();
await page.locator('.verdict-option.release').nth(1).click();
await page.locator('.verdict-option.execute').nth(2).click();
await page.getByRole('button',{name:'判定を執行する'}).click();
await page.locator('.result-hero').waitFor();
const final=await (await context.request.get(`http://127.0.0.1:3000/api/game?caseId=${caseId}`)).json();
assert.ok(final.game.reveal);
assert.equal(final.game.status,'verdict');
assert.equal(issues.length,0,issues.join('\n'));
await context.request.post('http://127.0.0.1:3000/api/game');
await page.setViewportSize({width:390,height:480});
await page.goto('http://127.0.0.1:3000/game',{waitUntil:'networkidle'});
await page.locator('.question-input').waitFor();
const smallBox=await page.locator('.question-input').boundingBox();
assert.ok(smallBox&&smallBox.y+smallBox.height<=480,'Input stays on screen with a short viewport');
console.log(JSON.stringify({passed:true,actor:firstName,favorite,questionsSaved:final.game.usedQuestions,verdict:final.game.isCorrect,consoleErrors:issues},null,2));
await browser.close();
