import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { generateCast,generateCharacter,publicCharacter,loadCast } from '../src/lib/engine/chargen';
import { classifyQuestion } from '../src/lib/engine/classify';
import { generateReply,emptyState,react } from '../src/lib/engine/generate';
import { ART_STYLES } from '../src/lib/engine/chargen';

function setup(){const c=generateCharacter({portrait:'ruri',hue:0});c.speechId='polite';return{c,state:emptyState()};}
function ask(set:ReturnType<typeof setup>,q:string,isAI=false){const s=set.state.chars['1'];return generateReply(set.c,q,classifyQuestion(q,s.history.map(h=>h.question)),s,isAI,set.state);}
const text=(plan:ReturnType<typeof ask>)=>plan.segments.map(s=>s.text).join('');

test('Question topics do not collapse into generic personal lines',()=>{
  for(const [q,topic] of [['名前は？','name'],['好きな食べ物は？','favorite_food'],['昨日何食べた？','dinner'],['家族は何人？','family'],['趣味は？','hobby'],['その時誰といた？','companion'],['本当に？','reconfirm'],['なんでそんなに詳しく覚えているの？','precision'],['犯人のことをどう思う？','crime_opinion']])assert.equal(classifyQuestion(q).topic,topic,q);
});
test('Generated identities and facts are different; both genders represented',()=>{
  for(let i=0;i<25;i++){const c=generateCast();assert.equal(new Set(c.map(x=>x.name)).size,3);assert.equal(new Set(c.map(x=>x.look.portrait)).size,3);assert.ok(c.some(x=>x.gender==='f'));assert.ok(c.some(x=>x.gender==='m'));}
});
test('Answers really use the named character and individual facts',()=>{
  const s=setup();assert.match(text(ask(s,'名前は？')),new RegExp(s.c.name));assert.ok(text(ask(s,'好きな食べ物は？')).includes(s.c.profile.favoriteFood));assert.ok(text(ask(s,'趣味は？')).includes(s.c.profile.hobby));assert.ok(text(ask(s,'昨日何食べた？')).includes(s.c.profile.dinner));assert.ok(text(ask(s,'家族は何人？')).includes(String(s.c.profile.family.length+1)));
});
test('Follow-up questions refer to the actual previous answer and location',()=>{
  const s=setup();const before=text(ask(s,'昨日の21時どこにいた？'));const reconfirm=text(ask(s,'本当に？'));assert.ok(reconfirm.includes(before.slice(0,30)));assert.ok(text(ask(s,'その時誰といた？')).includes(s.c.profile.schedule.night.location));
});
test('Invented quotation is not admitted as a previous testimony',()=>{
  const s=setup();ask(s,'昨日の21時どこにいた？');const response=text(ask(s,'さっき「火星にいた」って言ったよね？'));assert.ok(response.includes('火星にいた'));assert.ok(response.includes('まだ話していません')||response.includes('言ってない'));
});
test('Repeated questions keep character facts and change reactions',()=>{
  const s=setup();ask(s,'好きな食べ物は？');const repeat=ask(s,'好きな食べ物は？');assert.ok(text(repeat).includes(s.c.profile.favoriteFood));assert.equal(repeat.mainExpr,'confusion');assert.equal(s.state.chars['1'].questionCount,2);
});
test('Unknown questions are acknowledged and do not stop the game',()=>{
  const s=setup();const p=ask(s,'宇宙の終わりはいつ？');assert.ok(text(p).includes('宇宙の終わり'));assert.equal(s.state.chars['1'].questionCount,1);assert.ok(p.pre.length>0);
});
test('Appearance questions match the portrait rather than unrelated personal facts',()=>{
  const s=setup();assert.equal(classifyQuestion('なんでメガネをかけてるの？').topic,'glasses');assert.ok(text(ask(s,'メガネをかけてるの？')).includes('メガネ'));assert.ok(text(ask(s,'髪はどんな色？')).includes('赤茶色'));assert.ok(text(ask(s,'自己紹介して')).includes(s.c.name));assert.equal(classifyQuestion('本当に家にいたの？').topic,'location');
});
test('Every portrait and all sixteen frames exist, secrets are not public',()=>{
  const casts=generateCast();for(const c of casts){assert.equal('aiStyle' in publicCharacter(c),false);assert.equal('profile' in publicCharacter(c),false);for(let i=0;i<16;i++)assert.ok(existsSync(`public/portraits/${c.look.portrait}/${i}.webp`));}
});

const rate=(n:number,f:()=>boolean)=>{let k=0;for(let i=0;i<n;i++)if(f())k++;return k/n;};
test('Humans spike and alert under pressure; fakers often look normal (no single giveaway)',()=>{
  const insult=classifyQuestion('お前はクズだ');
  const human=generateCharacter({portrait:'ruri'});human.persona='gentle';
  const humanAlert=rate(400,()=>!!react(human,insult,false,false).alert);
  assert.ok(humanAlert>.8,'humans under insult alert most of the time: '+humanAlert);
  const humanBpm=rate(400,()=>react(human,insult,false,false).bio.bpm>=human.restBpm+15);
  assert.ok(humanBpm>.95);
  const mech=generateCharacter({portrait:'ruri'});mech.aiStyle='mechanical';
  const flat=rate(1000,()=>react(mech,insult,true,false).bio.flat);
  assert.ok(flat>.3&&flat<.8,'mechanical fakers are flat only some of the time: '+flat);
  const mimic=generateCharacter({portrait:'ruri'});mimic.aiStyle='humanlike';
  const steady=rate(1000,()=>react(mimic,insult,true,false).bio.ecg==='steady');
  assert.ok(steady>.2,'fakers sometimes show a completely normal ECG: '+steady);
  assert.ok(rate(1000,()=>react(mech,insult,true,false).bio.ecg==='steady')>.08);
  const emotive=generateCharacter({portrait:'ruri'});emotive.aiStyle='emotive';
  const fakerAlert=rate(1000,()=>!!react(emotive,insult,true,false).alert);
  assert.ok(fakerAlert>.1&&fakerAlert<.8,'fakers alert sometimes: '+fakerAlert);
});
test('Warnings and electronic ECG remain, but portraits never receive noise or glitches',()=>{
  const c=generateCharacter({portrait:'mori'});
  assert.equal(react(c,classifyQuestion('昨日の21時どこにいた？'),false,true).alert?.kind,'lie');
  const evidence=classifyQuestion('防犯カメラの記録があるが？');
  assert.equal(evidence.topic,'evidence');
  assert.ok(rate(400,()=>react(c,evidence,false,false).alert?.kind==='evidence')>.9);
  for(const ai of [false,true])for(let i=0;i<300;i++){
    assert.equal(react(c,classifyQuestion('お前が犯人だろう'),ai,true).glitch,0);
  }
  c.aiStyle='mechanical';
  assert.ok(rate(400,()=>react(c,evidence,true,false).bio.ecg==='glitched')>.06);
});
test('Suspects differ on silhouette, build, outfit, accessories and demeanor — never just color',()=>{
  const dist=(a:typeof ART_STYLES[number],b:typeof ART_STYLES[number])=>(a.hairGroup!==b.hairGroup?2:0)+(a.outfitGroup!==b.outfitGroup?1:0)+(!!a.glasses!==!!b.glasses?1:0)+(a.gender!==b.gender?1:0);
  for(let i=0;i<300;i++){
    const cast=generateCast();const arts=cast.map(c=>ART_STYLES.find(a=>a.id===c.look.portrait)!);
    assert.equal(new Set(arts.map(a=>a.hairGroup)).size,3,'three different hair silhouettes');
    assert.equal(new Set(cast.map(c=>c.look.build)).size,3,'three different builds');
    assert.equal(new Set(arts.map(a=>a.face)).size,3,'three different faces');
    assert.equal(new Set(arts.map(a=>a.outfitGroup)).size,3,'three different outfits');
    assert.equal(new Set(cast.map(c=>c.look.idleStyle)).size,3,'three different demeanors');
    const feats=cast.flatMap(c=>c.look.features!);assert.equal(new Set(feats).size,feats.length,'no shared accessories');
    assert.ok(cast.every(c=>['kei','mori','ruri','nagi'].includes(c.look.portrait!)&&c.look.nativeShape),'independent native art only');
    assert.ok(cast.every(c=>c.look.wardrobe==='original'),'no clothing overlays');
    assert.ok(cast.every(c=>c.look.build===ART_STYLES.find(a=>a.id===c.look.portrait)!.preferredBuild),'body belongs to original drawing, not resizing');
    for(const [x,y] of [[0,1],[0,2],[1,2]])assert.ok(dist(arts[x],arts[y])>=3);
    assert.ok(cast.every(c=>!c.look.hue),'no recolored clones');
    assert.equal(new Set(cast.map(c=>c.appearance)).size,3);
    assert.ok(cast.every(c=>!(c.gender==='f'&&c.look.features!.includes('stubble'))));
  }
});
test('Appearance is independent of who the faker is, and the feature question is answered in character',()=>{
  const counts=[0,0,0];for(let i=0;i<600;i++){const c=generateCast();const faker=Math.floor(Math.random()*3);const idx=c.findIndex(x=>x.look.idleStyle==='tired');if(idx===faker)counts[0]++;}
  assert.ok(counts[0]>150&&counts[0]<250,'tired-looking suspects are the faker about a third of the time');
  const s=setup();s.c.look.features=['earring'];assert.ok(text(ask(s,'そのピアスは？')).includes('ピアス'));
  const t2=setup();t2.c.look.features=['mole'];assert.ok(text(ask(t2,'ひげはどうしたの？')).includes('見間違い')||text(ask(t2,'ひげはどうしたの？')).includes('ないよ')||text(ask(t2,'ひげは？')).length>0);
});

test('Legacy save upgrades artwork without changing names, memories or the AI style',()=>{
  const legacy=[generateCharacter({portrait:'kei'}),generateCharacter({portrait:'mori'}),generateCharacter({portrait:'ruri'})];
  const ids=['noir','noir','lilac'] as const;
  legacy.forEach((c,i)=>{c.look={...c.look,portrait:ids[i],hue:99,wardrobe:'utilityJacket',features:['plaster','scar']};});
  const json=JSON.stringify(legacy);
  const loaded=loadCast(json);
  assert.deepEqual(loaded.map(c=>c.name),legacy.map(c=>c.name));
  assert.deepEqual(loaded.map(c=>c.profile),legacy.map(c=>c.profile));
  assert.deepEqual(loaded.map(c=>c.aiStyle),legacy.map(c=>c.aiStyle));
  assert.equal(new Set(loaded.map(c=>c.look.portrait)).size,3);
  assert.ok(loaded.every(c=>c.look.hue===0&&c.look.wardrobe==='original'&&c.look.nativeShape));
  assert.deepEqual(loadCast(json).map(c=>c.look),loaded.map(c=>c.look),'upgrade is stable across reloads');
});
test('All 22 expressions plus blink are original files, legacy recolors and stretching are disabled',()=>{
  for(const art of ART_STYLES){
    const c=generateCharacter({portrait:art.id,hue:88,build:'broad'});
    assert.equal(c.look.hue,0);assert.equal(c.look.build,art.preferredBuild);assert.equal(c.look.wardrobe,'original');assert.equal(c.look.nativeShape,true);
    for(let frame=0;frame<23;frame++)assert.ok(existsSync(`public/portraits/${art.id}/${frame}.webp`));
    assert.ok(existsSync(`public/original-art/${art.id}.svg`));
  }
});
