import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
await mkdir('tests/artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' });
const page = await context.newPage();
const errors = [];
page.on('pageerror', error => errors.push(error.message));

async function assertOriginal(locator) {
  await locator.locator('canvas[data-ready="true"]').waitFor({ state: 'visible' });
  const result = await locator.evaluate(async container => {
    const canvas = container.querySelector('canvas');
    const src = container.querySelector('img').src;
    const img = new Image();
    await new Promise((resolve, reject) => { img.onload = resolve; img.onerror = reject; img.src = src; });
    const expected = document.createElement('canvas');
    expected.width = 256; expected.height = 256;
    expected.getContext('2d').drawImage(img, 0, 0);
    const a = canvas.getContext('2d').getImageData(0, 0, 256, 256).data;
    const b = expected.getContext('2d').getImageData(0, 0, 256, 256).data;
    let different = 0;
    for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) different++;
    return { different, filter: getComputedStyle(canvas).filter, renderer: container.dataset.renderer, portrait: container.dataset.portrait, transform: canvas.getContext('2d').getTransform().toJSON() };
  });
  assert.equal(result.different, 0, `Portrait is copied exactly as drawn: ${JSON.stringify(result)}`);
  assert.equal(result.filter, 'none');
  assert.equal(result.renderer, 'original-art');
  assert.deepEqual([result.transform.a, result.transform.b, result.transform.c, result.transform.d, result.transform.e, result.transform.f], [1, 0, 0, 1, 0, 0]);
  return result.portrait;
}
try {
  await page.goto('http://127.0.0.1:3000/archive', { waitUntil: 'networkidle' });
  await page.locator('.archive-card').first().waitFor();
  assert.equal(await page.locator('.archive-card').count(), 4, 'Each original is listed exactly once, not as recolored variants');
  const sources = [];
  for (let index = 0; index < 4; index++) {
    await page.locator('.archive-card').nth(index).click();
    const target = page.locator('.character-detail-art .pixel-character');
    const id = await assertOriginal(target);
    sources.push(id);
    await page.getByRole('button', { name: '笑顔', exact: true }).click();
    await page.waitForTimeout(180);
    await assertOriginal(target);
    await page.getByRole('button', { name: '閉じる', exact: true }).click();
  }
  assert.equal(new Set(sources).size, 4);
  await page.screenshot({ path: 'tests/artifacts/original-archive.png', fullPage: true });
  await context.request.post('http://127.0.0.1:3000/api/game');
  await page.goto('http://127.0.0.1:3000/game', { waitUntil: 'networkidle' });
  await page.locator('.question-input').waitFor();
  const actors = [];
  for (let index = 0; index < 3; index++) {
    await page.locator('.suspect-card').nth(index).click();
    await page.waitForTimeout(120);
    const target = page.locator('.stage-main-character .pixel-character');
    // idle state can be sleepy. Both image and canvas use that SAME authored state.
    actors.push(await assertOriginal(target));
  }
  assert.equal(new Set(actors).size, 3, '3 suspects use 3 genuinely distinct original artworks');
  await page.screenshot({ path: 'tests/artifacts/clean-original-game.png' });
  await page.route('**/api/game/ask', async route => {
    const response = await route.fetch(); const data = await response.json();
    data.plan.glitch = 3; // Even stale old-save glitches cannot corrupt the new renderer.
    await route.fulfill({ response, json: data });
  });
  await page.locator('.question-input').fill('あなたは人間ですか？');
  await page.locator('.question-input').press('Enter');
  await page.getByRole('button', { name: '全文を表示' }).waitFor();
  await page.getByRole('button', { name: '全文を表示' }).click();
  await page.waitForTimeout(260);
  await assertOriginal(page.locator('.stage-main-character .pixel-character'));
  assert.equal(await page.locator('[data-glitch]').count(), 0);
  await page.setViewportSize({ width: 390, height: 844 });
  await page.reload({ waitUntil: 'networkidle' });
  await page.locator('.question-input').waitFor();
  await assertOriginal(page.locator('.stage-main-character .pixel-character'));
  await page.screenshot({ path: 'tests/artifacts/clean-original-mobile.png' });
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  assert.equal(errors.length, 0, errors.join('\n'));
  console.log(JSON.stringify({ passed: true, independentArtworks: sources, actors, exactSourcePixels: true, noFiltersOrDistortion: true, legacyGlitchIgnored: true, consoleErrors: errors }, null, 2));
} finally { await browser.close(); }
