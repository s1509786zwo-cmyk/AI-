// 表情シートの頭の位置ずれを補正し、整列後の変化量から目・口のアンカーを算出する
import sharp from 'sharp';
const ids=['lilac','peach','mint','ivory','ash','blue','rose','noir'];
const W=256;
const apply=process.argv.includes('--apply');
const alphaOf=d=>{const a=new Uint8Array(W*W);for(let p=0;p<W*W;p++)a[p]=d[p*4+3]>128?1:0;return a;};
function mismatch(a,ref,dx,dy,stride){
  let mis=0;
  for(let y=6;y<W-6;y+=stride)for(let x=6;x<W-6;x+=stride){
    const sx=x-dx,sy=y-dy;
    const v=(sx<0||sy<0||sx>=W||sy>=W)?ref[y*W+x]:a[sy*W+sx]; // 範囲外は不問
    if(v!==ref[y*W+x])mis++;
  }
  return mis;
}
const out={};
for(const id of ids){
  const frames=[];
  for(let f=0;f<16;f++){const {data}=await sharp(`public/portraits/${id}/${f}.webp`).ensureAlpha().raw().toBuffer({resolveWithObject:true});frames.push(Buffer.from(data));}
  const ref=alphaOf(frames[0]);
  const bbox=d=>{let x0=W,x1=0,y0=W,y1=0;for(let y=0;y<W;y++)for(let x=0;x<W;x++)if(d[(y*W+x)*4+3]>128){if(x<x0)x0=x;if(x>x1)x1=x;if(y<y0)y0=y;if(y>y1)y1=y;}return [x0,y0,x1,y1];};
  const boxes=frames.map(bbox);
  const area=ref.reduce((q,v)=>q+v,0);
  const shifts=[[0,0]],resid=[0];
  for(let f=1;f<16;f++){
    const a=alphaOf(frames[f]);
    let best=1e12,bx=0,by=0;
    for(let dy=-16;dy<=16;dy+=2)for(let dx=-16;dx<=16;dx+=2){const m=mismatch(a,ref,dx,dy,4);if(m<best){best=m;bx=dx;by=dy;}}
    let b2=1e12,fx=bx,fy=by;
    for(let dy=by-2;dy<=by+2;dy++)for(let dx=bx-2;dx<=bx+2;dx++){const m=mismatch(a,ref,dx,dy,1);if(m<b2){b2=m;fx=dx;fy=dy;}}
    shifts.push([fx,fy]);resid.push(b2/Math.max(1,area));
  }
  const ok=resid.map((r,f)=>r<=0.2&&Math.max(Math.abs(shifts[f][0]),Math.abs(shifts[f][1]))<=14);
  const aligned=frames.map((d,f)=>{
    const [dx,dy]=ok[f]?shifts[f]:[0,0];
    if(!dx&&!dy)return d;
    const o=Buffer.alloc(W*W*4);
    for(let y=0;y<W;y++)for(let x=0;x<W;x++){
      const sx=x-dx,sy=y-dy;
      if(sx>=0&&sy>=0&&sx<W&&sy<W)d.copy(o,(y*W+x)*4,(sy*W+sx)*4,(sy*W+sx)*4+4);
      else if(dy<0&&y>=W+dy||dx<0&&x>=W+dx)frames[0].copy(o,(y*W+x)*4,(y*W+x)*4,(y*W+x)*4+4); // 下端・右端は基準フレームの体で埋める
    }
    return o;
  });
  if(apply)for(let f=0;f<16;f++){if(ok[f]&&(shifts[f][0]||shifts[f][1]))await sharp(aligned[f],{raw:{width:W,height:W,channels:4}}).webp({lossless:true}).toFile(`public/portraits/${id}/${f}.webp`);}
  const V=new Float64Array(W*W);
  for(let p=0;p<W*W;p++){
    let all=true;for(let f=0;f<16;f++)if(ok[f]&&aligned[f][p*4+3]<128){all=false;break;}
    if(!all)continue;
    let m=[0,0,0],n=0;for(let f=0;f<16;f++){if(!ok[f])continue;n++;for(let c=0;c<3;c++)m[c]+=aligned[f][p*4+c];}m=m.map(x=>x/n);
    let v=0;for(let f=0;f<16;f++){if(!ok[f])continue;for(let c=0;c<3;c++){const e=aligned[f][p*4+c]-m[c];v+=e*e;}}
    V[p]=Math.sqrt(v/(3*n));
  }
  const rows=new Float64Array(W);
  for(let y=0;y<W;y++){let s=0;for(let x=36;x<220;x++)if(V[y*W+x]>14)s+=V[y*W+x];rows[y]=s;}
  const sm=rows.map((_,y)=>{let s=0,n=0;for(let k=-3;k<=3;k++)if(rows[y+k]!==undefined){s+=rows[y+k];n++;}return s/n;});
  let ey=60;for(let y=60;y<=175;y++)if(sm[y]>sm[ey])ey=y;
  let my=ey+14;for(let y=ey+14;y<=Math.min(235,ey+60);y++)if(sm[y]>sm[my])my=y;
  const cen=(y0,y1,x0,x1)=>{let sx=0,sy=0,sw=0;for(let y=y0;y<=y1;y++)for(let x=x0;x<=x1;x++){const w=V[y*W+x]>14?V[y*W+x]:0;sx+=w*x;sy+=w*y;sw+=w;}return sw?[sx/sw,sy/sw]:null;};
  const all=cen(ey-14,ey+14,36,220)||[128,ey];
  const L=cen(ey-14,ey+14,36,Math.round(all[0]))||[96,ey];
  const R=cen(ey-14,ey+14,Math.round(all[0]),220)||[160,ey];
  const M=cen(my-10,my+10,70,186)||[128,my];
  out[id]={headTop:boxes.map(b=>b[1]).join(','),usable:ok.filter(Boolean).length,maxResid:Math.max(...resid).toFixed(3),moved:shifts.filter((s,f)=>ok[f]&&(s[0]||s[1])).length,bigShifts:shifts.map((s,f)=>ok[f]&&Math.max(Math.abs(s[0]),Math.abs(s[1]))>8?`${f}:${s}`:null).filter(Boolean).join(' '),bad:ok.map((v,f)=>v?null:f).filter(v=>v!==null).join(','),eyeL:[Math.round(L[0]),Math.round(L[1])],eyeR:[Math.round(R[0]),Math.round(R[1])],mouth:[Math.round(M[0]),Math.round(M[1])],gap:Math.round(M[1]-(L[1]+R[1])/2)};
}
console.log(JSON.stringify(out).replace(/\},"/g,'},\n"'));
