// All current cast artwork is authored independently in draw-original-cast.mjs.
// Rebuild the original portraits and their expression images without stretching,
// recoloring, procedural facial overlays, or importing an old character base.
import './draw-original-cast.mjs';
