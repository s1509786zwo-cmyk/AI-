import sharp from 'sharp';
import { mkdir, writeFile } from 'node:fs/promises';

// Four individually authored characters. No imported portraits, recoloring,
// photographic noise, facial warping, or procedural face overlays.
const EXPRESSIONS = ['normal','smile','faint','confusion','surprise','unease','anxiety','anger','sadness','tension','suspicion','blank','agitation','deceit','blush','wink','thinking','excited','sleepy','relieved','pout','embarrassed','blink'];
const stroke = '#343046';
const path = (d, fill, sw=1.5, line=stroke) => `<path d="${d}" fill="${fill}" stroke="${sw?line:'none'}" stroke-width="${sw}" stroke-linejoin="round" stroke-linecap="round"/>`;
const rect = (x,y,w,h,fill,rx=0) => `<rect x="${x}" y="${y}" width="${w}" height="${h}" rx="${rx}" fill="${fill}"/>`;
const ellipse = (cx,cy,rx,ry,fill,line='none',sw=1) => `<ellipse cx="${cx}" cy="${cy}" rx="${rx}" ry="${ry}" fill="${fill}" stroke="${line}" stroke-width="${sw}"/>`;
const line = (d,color,width=1.5)=>path(d,'none',width,color);

const PEOPLE = {
  kei: {
    name:'ケイ',gender:'m',skin:'#fae2d1',shade:'#e5b6aa',cheek:'#ecadb0',hair:'#34364f',hairMid:'#505575',hairLight:'#79839b',iris:'#839eb5',irisDark:'#465772',irisLight:'#c0d9e1',
    // Thin grown-up oval face, short side-part, rectangular glasses, lapel coat.
    face:'M 79 79 Q 85 58 120 55 Q 164 56 178 92 L 176 141 Q 174 171 160 186 L 140 202 Q 128 207 116 199 L 97 182 Q 80 160 79 129 Z',
    eyeL:[100,136],eyeR:[153,136],eyeW:15,eyeH:11,mouth:[129,184],nose:[129,159],
    ears:()=>ellipse(77,140,7,12,'#efd0c3',stroke)+ellipse(179,140,7,12,'#efd0c3',stroke),
    back:()=>'',
    body:()=>[
      path('M 117 193 L 117 216 L 100 221 L 126 243 L 153 221 L 139 215 L 139 192 Z','#fae2d1'),
      path('M 85 213 L 113 207 L 126 222 L 139 207 L 169 214 Q 186 221 197 256 L 60 256 Q 67 223 85 213 Z','#b7a396'),
      path('M 95 214 L 114 208 L 126 222 L 139 208 L 158 214 L 162 256 L 92 256 Z','#fff7e9'),
      path('M 77 221 L 105 207 L 99 231 L 112 236 L 101 256 L 62 256 Z','#dac4af'),
      path('M 150 208 L 181 224 L 195 256 L 152 256 L 143 237 L 156 230 Z','#dac4af'),
      path('M 115 210 L 127 221 L 116 230 L 108 215 Z','#e6e4e7'),
      path('M 140 210 L 128 221 L 139 230 L 148 215 Z','#e6e4e7'),
      path('M 123 221 L 132 221 L 135 229 L 130 234 L 127 256 L 122 246 L 125 233 L 120 228 Z','#6d537e'),
      line('M 124 235 L 124 252','#98779b',2),
      rect(163,237,13,2,'#877788'),rect(165,228,2,10,'#37394d'),rect(169,229,2,9,'#858594'),
      ellipse(83,246,2,2,'#5b5364'),ellipse(176,246,2,2,'#5b5364'),
      line('M 71 239 L 68 254 M 185 239 L 190 254','#ad9489',2),
    ].join(''),
    hairFront:()=>[
      path('M 68 107 Q 62 83 73 62 Q 83 41 106 36 Q 116 33 143 40 Q 161 43 176 57 Q 189 74 186 111 L 177 130 L 171 105 L 169 81 Q 145 77 127 66 Q 114 88 91 91 L 84 116 L 78 131 L 72 116 Z','#34364f'),
      path('M 78 77 Q 88 44 119 44 L 126 54 Q 113 76 86 88 Z','#505575',0),
      path('M 129 48 Q 151 49 170 68 L 173 80 Q 147 68 131 60 Z','#505575',0),
      line('M 84 69 Q 96 51 114 50','#79839b',3),line('M 94 81 Q 113 67 119 59','#79839b',1.5),
      line('M 142 55 L 165 68 M 151 60 L 168 74','#79839b',1.5),
      line('M 124 43 Q 136 58 149 66','#26293e',2),
    ].join(''),
    accessory:()=>[
      `<rect x="80" y="126" width="38" height="24" rx="3" fill="none" stroke="#464453" stroke-width="2"/>`,
      `<rect x="137" y="126" width="38" height="24" rx="3" fill="none" stroke="#464453" stroke-width="2"/>`,
      line('M 118 135 Q 127 130 137 135 M 77 130 L 80 131 M 175 131 L 180 130','#464453',2),
      line('M 84 128 L 98 128 M 141 128 L 155 128','#e3f2f2',1.5),
    ].join(''),
  },
  mori: {
    name:'モリ',gender:'m',skin:'#f0ccb6',shade:'#d3a497',cheek:'#d59394',hair:'#574849',hairMid:'#806365',hairLight:'#ae8380',iris:'#9c8564',irisDark:'#5a4b4a',irisLight:'#d7ba90',
    // Wide rounded face and much smaller eyes. Broad original shoulders, wool scarf and hoodie.
    face:'M 63 80 Q 69 58 113 56 Q 161 56 185 82 L 190 130 Q 191 168 181 187 Q 163 209 128 210 Q 90 210 72 190 Q 57 173 60 126 Z',
    eyeL:[88,137],eyeR:[165,137],eyeW:16,eyeH:8,mouth:[128,184],nose:[129,158],
    ears:()=>ellipse(59,144,8,13,'#e3b9a5',stroke)+ellipse(193,144,8,13,'#e3b9a5',stroke),
    back:()=>path('M 60 90 L 55 116 L 53 150 L 62 157 L 55 170 L 72 174 L 78 136 L 181 130 L 182 175 L 201 168 L 196 157 L 204 148 L 199 116 L 190 84 Z','#574849'),
    body:()=>[
      path('M 96 195 L 96 217 L 162 217 L 159 195 Z','#ddb5a3'),
      path('M 49 211 Q 26 223 18 256 L 238 256 Q 229 223 208 214 L 165 203 L 87 204 Z','#6b7e78'),
      path('M 73 196 Q 38 203 39 224 L 62 237 L 88 214 L 167 214 L 197 237 L 218 223 Q 219 203 183 196 L 168 209 L 84 209 Z','#414f54'),
      path('M 85 207 L 78 241 L 68 256 L 187 256 L 176 240 L 171 207 Z','#e4d7c3'),
      path('M 49 224 L 80 212 L 85 229 L 77 256 L 22 256 Z','#6b7e78'),
      path('M 176 215 L 209 225 L 235 256 L 182 256 L 170 228 Z','#6b7e78'),
      path('M 80 199 Q 127 213 171 199 L 177 216 Q 159 230 126 227 Q 96 227 78 217 Z','#d4a288'),
      path('M 84 214 Q 124 230 170 211 L 165 223 Q 125 239 87 223 Z','#ecc7a6'),
      path('M 154 217 L 168 224 L 163 256 L 145 256 Z','#d4a288'),
      line('M 159 232 L 154 252 M 149 232 L 146 247','#b17b75',2),
      line('M 79 230 L 74 253 M 174 230 L 180 253','#b5c5b3',2),
      rect(72,249,4,6,'#e4e0ca'),rect(178,249,4,6,'#e4e0ca'),
      line('M 32 242 L 56 234 M 199 234 L 223 244','#89968a',2),
      line('M 99 241 L 103 249 L 99 256 M 113 241 L 117 249 L 113 256 M 127 242 L 131 250 L 127 256','#cbbda7',2),
    ].join(''),
    hairFront:()=>[
      path('M 54 118 L 45 109 L 55 94 L 47 86 L 59 75 L 55 62 L 72 58 L 79 43 L 94 49 L 106 33 L 121 43 L 139 34 L 149 45 L 171 42 L 179 58 L 195 64 L 192 79 L 205 90 L 195 99 L 200 113 L 190 123 L 187 145 L 179 133 L 171 108 L 159 91 L 150 97 L 139 84 L 121 97 L 112 89 L 93 106 L 83 100 L 72 122 L 68 148 L 61 139 Z','#574849'),
      path('M 69 74 L 84 62 L 98 62 L 109 50 L 126 61 L 140 52 L 160 61 L 176 60 L 187 79 L 179 86 L 158 74 L 139 68 L 122 76 L 109 69 L 94 84 L 75 94 Z','#806365',0),
      line('M 81 69 L 95 69 L 105 58 M 130 65 L 141 62 L 157 70 M 160 83 L 176 91','#ae8380',3),
      line('M 61 110 L 69 90 M 186 105 L 181 86','#806365',3),
    ].join(''),
    accessory:()=>[
      // A solid, naturally drawn beard contour, not randomized speckle/stubble noise.
      path('M 74 173 L 88 183 L 101 185 L 111 194 L 144 194 L 154 185 L 171 183 L 181 173 L 178 190 Q 163 208 128 209 Q 93 208 77 191 Z','#957575',0),
      path('M 102 186 Q 128 200 153 186 L 145 195 L 113 195 Z','#f0ccb6',0),
      path('M 117 178 Q 128 173 140 178 L 138 181 L 116 181 Z','#8c6b6d',0),
      line('M 74 153 Q 85 158 101 154 M 150 154 Q 164 158 180 153','#b3848b',1.5),
    ].join(''),
  },
  ruri: {
    name:'ルリ',gender:'f',skin:'#fde5d8',shade:'#eabdb6',cheek:'#eea4b3',hair:'#a65f62',hairMid:'#d88d86',hairLight:'#f1bdaa',iris:'#6daba9',irisDark:'#3f6d7b',irisLight:'#bce5d1',
    // Petite heart-shaped face, asymmetric ear-length haircut, utility jacket and hoop earring.
    face:'M 79 88 Q 89 63 124 65 Q 164 65 179 93 L 179 145 Q 176 169 162 180 L 137 198 Q 129 203 121 197 L 98 183 Q 81 174 76 146 Z',
    eyeL:[98,137],eyeR:[157,137],eyeW:18,eyeH:17,mouth:[129,181],nose:[129,160],
    ears:()=>ellipse(183,143,7,12,'#edc4b8',stroke),
    back:()=>path('M 63 89 L 55 145 L 55 174 L 66 190 L 82 184 L 82 159 L 177 157 L 177 168 L 195 163 L 199 116 L 183 74 Z','#a65f62'),
    body:()=>[
      path('M 117 193 L 116 214 L 107 219 L 129 232 L 149 219 L 138 214 L 138 192 Z','#fde5d8'),
      path('M 94 211 L 109 211 L 117 222 L 139 222 L 149 210 L 165 213 L 178 239 L 179 256 L 75 256 L 81 232 Z','#827796'),
      path('M 107 222 L 118 212 Q 129 220 140 212 L 151 225 L 161 256 L 97 256 Z','#353749'),
      path('M 87 223 L 108 211 L 115 230 L 104 244 L 106 256 L 70 256 L 73 239 Z','#e5ded4'),
      path('M 149 211 L 169 224 L 183 243 L 187 256 L 151 256 L 152 244 L 141 230 Z','#e5ded4'),
      path('M 102 210 L 111 208 L 121 231 L 105 230 L 94 219 Z','#f8f0de'),
      path('M 149 208 L 157 210 L 166 219 L 150 231 L 136 231 Z','#f8f0de'),
      line('M 116 234 L 111 255','#b9b1bd',3),line('M 116 236 L 115 248','#7c718d',1),
      line('M 79 244 L 96 241 M 161 241 L 177 244','#bfb4be',2),
      rect(164,230,8,5,'#709b9d',1),rect(166,231,4,1,'#c0e6d8'),
    ].join(''),
    hairFront:()=>[
      path('M 60 111 Q 55 84 63 68 Q 74 48 95 47 L 109 39 Q 134 41 154 53 Q 181 51 193 72 Q 202 92 195 126 L 185 144 L 179 112 L 171 100 L 168 126 L 158 127 L 157 101 L 142 90 L 136 113 L 125 110 L 127 82 Q 112 99 92 99 L 84 132 L 78 172 L 70 181 L 62 163 L 64 128 Z','#a65f62'),
      path('M 67 91 Q 74 64 96 60 L 108 52 Q 130 53 146 65 Q 140 79 118 87 L 94 90 L 85 115 L 78 144 L 71 146 Z','#d88d86',0),
      path('M 153 67 Q 178 67 186 84 L 188 110 L 179 103 L 170 89 L 158 91 Z','#d88d86',0),
      line('M 79 78 Q 90 63 103 65 M 114 62 Q 129 64 135 67','#f1bdaa',3),
      line('M 81 95 L 75 124 M 162 74 L 179 87','#f1bdaa',2),
      line('M 74 156 L 71 169','#d88d86',2),
    ].join(''),
    accessory:()=>[
      line('M 174 108 L 187 105','#eedacb',3),line('M 174 113 L 187 110','#fff4e4',2),
      ellipse(184,157,4.5,6,'none','#686075',2.5),ellipse(184,157,3.5,5,'none','#e5e3ed',1.5),
    ].join(''),
  },
  nagi: {
    name:'ナギ',gender:'f',skin:'#f7e6e1',shade:'#dfb8bb',cheek:'#dea5bf',hair:'#b7b9d1',hairMid:'#d5d4e2',hairLight:'#f3ecf0',iris:'#9d86bf',irisDark:'#625481',irisLight:'#cfb8e6',
    // Fine pointed face with big rounded violet eyes, twin braids, wide frilled collar and navy dress.
    face:'M 82 87 Q 82 67 126 62 Q 165 62 177 86 L 178 140 Q 175 169 157 182 L 140 193 Q 128 199 117 192 L 98 180 Q 81 162 81 135 Z',
    eyeL:[100,135],eyeR:[155,135],eyeW:17,eyeH:20,mouth:[128,178],nose:[128,156],
    ears:()=>ellipse(79,139,6,10,'#e8c5c1',stroke)+ellipse(180,139,6,10,'#e8c5c1',stroke),
    back:()=>[
      path('M 73 68 Q 56 82 56 111 L 62 150 L 47 173 L 53 191 L 45 211 L 49 256 L 82 256 L 89 160 L 175 160 L 179 256 L 208 256 L 211 210 L 202 185 L 209 166 L 198 141 Q 204 103 188 74 Z','#b7b9d1'),
      path('M 61 111 L 67 136 L 64 161 L 70 184 L 60 223 L 59 256 L 50 256 L 51 213 L 60 184 L 56 164 Z','#9495b3',0),
      path('M 192 111 L 187 142 L 192 166 L 185 187 L 200 220 L 200 256 L 209 256 L 209 213 L 200 184 L 204 164 Z','#9495b3',0),
    ].join(''),
    body:()=>[
      path('M 117 191 L 116 210 L 108 213 L 128 230 L 148 213 L 139 209 L 139 191 Z','#f7e6e1'),
      path('M 86 214 L 112 205 L 128 221 L 144 205 L 172 216 Q 196 228 204 256 L 51 256 Q 61 228 86 214 Z','#656180'),
      path('M 109 206 L 123 221 L 127 232 L 104 236 L 83 217 Z','#f4ebeb'),
      path('M 146 205 L 173 218 L 149 237 L 130 232 L 132 221 Z','#f4ebeb'),
      path('M 85 216 L 89 220 L 83 225 L 92 229 L 90 233 L 100 235 L 102 239 L 111 237 L 118 241 L 127 232','#f4ebeb'),
      path('M 173 216 L 170 221 L 175 226 L 166 230 L 168 234 L 158 236 L 155 240 L 145 237 L 137 241 L 130 232','#f4ebeb'),
      path('M 110 227 Q 98 221 94 228 L 97 239 L 119 232 Z','#9d87b8'),
      path('M 140 227 Q 155 220 159 228 L 155 240 L 135 232 Z','#9d87b8'),
      rect(123,227,10,9,'#725e91',2),
      path('M 122 235 L 114 255 L 125 249 L 127 236 Z','#b7a0c7'),
      path('M 132 235 L 135 249 L 145 255 L 136 235 Z','#b7a0c7'),
      line('M 74 237 L 69 255 M 183 237 L 188 255','#aaa2ba',2),
    ].join(''),
    hairFront:()=>[
      path('M 70 116 Q 64 88 76 64 Q 92 44 120 44 Q 149 42 170 57 Q 190 69 189 111 L 180 139 L 177 120 L 173 92 L 167 102 L 158 105 L 157 86 L 141 103 L 131 101 L 128 83 L 112 99 L 104 97 L 103 83 L 91 103 L 85 145 L 77 147 L 75 128 Z','#b7b9d1'),
      path('M 81 81 Q 96 54 125 53 Q 151 51 171 74 L 174 88 L 166 88 L 158 73 L 147 88 L 137 90 L 132 74 L 116 86 L 107 86 L 104 71 L 93 88 L 82 108 Z','#d5d4e2',0),
      line('M 95 67 L 110 61 L 122 61 M 139 62 L 154 67 M 84 93 L 80 117','#f3ecf0',3),
      // Individually designed braids, not copies of the head shape.
      path('M 77 149 Q 65 152 67 167 Q 66 179 74 188 Q 65 201 69 216 Q 68 229 78 237 L 88 229 Q 94 213 85 201 Q 93 188 85 176 Q 94 159 85 149 Z','#b7b9d1'),
      path('M 182 149 Q 193 152 191 167 Q 192 180 185 188 Q 195 201 189 216 Q 191 229 180 237 L 169 229 Q 165 214 174 201 Q 165 188 173 176 Q 165 159 173 149 Z','#b7b9d1'),
      line('M 72 161 L 85 173 L 72 187 L 85 201 L 73 215 L 85 227 M 187 161 L 174 173 L 187 187 L 174 201 L 186 215 L 174 227','#9495b3',2),
      line('M 73 156 L 82 164 M 73 190 L 82 197 M 73 220 L 81 225 M 179 155 L 185 162 M 178 190 L 185 197','#e8e2ed',2),
    ].join(''),
    accessory:()=>[
      path('M 78 224 L 88 225 L 88 231 L 77 231 Z','#65587f'),
      path('M 170 225 L 181 224 L 182 231 L 170 231 Z','#65587f'),
      path('M 177 87 L 179 93 L 186 93 L 181 97 L 183 103 L 177 100 L 171 103 L 172 97 L 168 93 L 175 93 Z','#e3c89e',1,'#998caa'),
    ].join(''),
  },
};

function drawEyes(c, expression) {
  let s='';
  const happy=['smile','excited','relieved'].includes(expression);
  const wink=expression==='wink';
  const closed=expression==='blink';
  const surprise=['surprise','agitation'].includes(expression);
  const narrow=['anger','pout','suspicion','sleepy','blank'].includes(expression);
  const sad=['sadness','unease','anxiety','tension','embarrassed'].includes(expression);
  const gaze=['deceit','suspicion','thinking'].includes(expression)?3:expression==='anxiety'?-3:0;
  const eyes=[c.eyeL,c.eyeR];
  eyes.forEach(([cx,cy],index)=>{
    const w=c.eyeW;
    let h=c.eyeH+(surprise?3:0);
    if(narrow)h=Math.max(6,Math.round(h*.65));
    if(happy||closed||(wink&&index===0)){
      s+=line(happy?`M ${cx-w} ${cy+2} Q ${cx} ${cy-8} ${cx+w} ${cy+2}`:`M ${cx-w} ${cy} Q ${cx} ${cy+4} ${cx+w} ${cy}`,stroke,c.id==='mori'?2:2.5);
    }else{
      const top=cy-h/2;
      const bounds=`M ${cx-w} ${top+3} Q ${cx-3} ${top-3} ${cx+w} ${top+1} L ${cx+w-2} ${cy+h/2} Q ${cx} ${cy+h/2+3} ${cx-w+1} ${cy+h/2-1} Z`;
      s+=`<defs><clipPath id="eye-${index}"><path d="${bounds}"/></clipPath></defs>`;
      s+=path(bounds,'#fff7f1',0);
      s+=`<g clip-path="url(#eye-${index})">`;
      const rw=Math.max(6,w*.53);
      s+=ellipse(cx+gaze,cy+1,rw,h*.65,c.irisDark);
      s+=ellipse(cx+gaze,cy+3,rw-1,h*.49,c.iris);
      s+=ellipse(cx+gaze,cy+Math.max(4,h*.25),rw-2,h*.23,c.irisLight);
      s+=ellipse(cx+gaze,cy,Math.max(2,rw*.32),Math.max(3,h*.31),stroke);
      if(expression!=='blank'){
        s+=rect(cx+gaze-rw+1,cy-Math.round(h*.22),Math.max(3,rw*.55),Math.max(3,rw*.6),'#fffaf6',1);
        s+=rect(cx+gaze+rw-4,cy+Math.round(h*.22),2,2,'#fffaf6');
      }
      s+='</g>';
      s+=line(`M ${cx-w-2} ${top+2} Q ${cx-2} ${top-4} ${cx+w+1} ${top+1}`,stroke,c.gender==='f'?3:2);
      if(c.id==='ruri')s+=line(`M ${cx+w} ${top+1} L ${cx+w+5} ${top-3}`,stroke,2);
      if(c.id==='nagi')s+=line(`M ${cx+w} ${top+1} L ${cx+w+4} ${top-2}`,stroke,2);
      s+=line(`M ${cx-w+3} ${cy+h/2+2} Q ${cx} ${cy+h/2+5} ${cx+w-4} ${cy+h/2+2}`,c.shade,1);
    }
    // Eyebrow differs with expression but does not change the underlying face.
    let browY=cy-c.eyeH-6;
    if(surprise)browY-=4;
    if(expression==='thinking'||expression==='confusion')browY+=index===0?-3:2;
    const angle=['anger','pout'].includes(expression)?(index===0?4:-4):sad?(index===0?-3:3):0;
    const bw=c.id==='mori'?12:11;
    s+=line(`M ${cx-bw} ${browY-angle} Q ${cx} ${browY-2} ${cx+bw} ${browY+angle}`,c.hair,c.id==='mori'?3:1.5);
  });
  return s;
}

function drawMouth(c,e){
  const [x,y]=c.mouth;
  if(e==='blink')return line(`M ${x-3} ${y} L ${x+3} ${y}`,'#a16875',1.5);
  if(['smile','excited'].includes(e))return path(`M ${x-7} ${y-3} Q ${x} ${y} ${x+7} ${y-3} Q ${x+5} ${y+7} ${x} ${y+7} Q ${x-5} ${y+7} ${x-7} ${y-3} Z`,'#965968',1,'#755161')+rect(x-4,y-2,8,2,'#fff4df')+ellipse(x,y+5,3,1.5,'#da9196');
  if(['surprise','agitation'].includes(e))return ellipse(x,y,3.5,5,'#a26a76','#895969',1);
  if(e==='anger')return path(`M ${x-5} ${y-1} L ${x+6} ${y-1} L ${x+4} ${y+4} L ${x-4} ${y+4} Z`,'#fff0e9',1.5,'#a16875');
  if(['confusion','anxiety','deceit'].includes(e))return line(`M ${x-6} ${y} L ${x-3} ${y+2} L ${x} ${y} L ${x+3} ${y+2} L ${x+6} ${y}`,'#a16875',1.5);
  if(['sadness','unease'].includes(e))return line(`M ${x-4} ${y+2} Q ${x} ${y-2} ${x+4} ${y+2}`,'#a16875',1.5);
  if(e==='pout')return path(`M ${x-3} ${y-1} Q ${x} ${y-4} ${x+4} ${y} Q ${x} ${y+3} ${x-3} ${y+1} Z`,'#cf8b9a',0);
  if(e==='thinking')return line(`M ${x-3} ${y} L ${x+2} ${y+1}`,'#a16875',1.5);
  if(['faint','wink','blush','relieved','embarrassed'].includes(e))return line(`M ${x-4} ${y-1} Q ${x} ${y+4} ${x+5} ${y-1}`,'#ad6b7b',1.5);
  return line(`M ${x-3} ${y} L ${x+3} ${y}`,'#b57780',1.5);
}

function portrait(id,expression){
  const c={...PEOPLE[id],id};
  let s=c.back()+c.body()+c.ears()+path(c.face,c.skin,1.5);
  s+=path(c.face,c.shade,0);
  s+=`<defs><clipPath id="face"><path d="${c.face}"/></clipPath></defs>`;
  s+=`<g clip-path="url(#face)">`;
  // Skin lighting is authored solid geometry, with no grain or dotted dither.
  s+=path('M 70 54 L 170 54 L 178 155 Q 157 186 128 194 Q 91 193 67 157 Z',c.skin,0);
  if(expression!=='blank'){
    const blush=['blush','embarrassed','excited'].includes(expression)?0.65:0.3;
    s+=`<g opacity="${blush}">`+ellipse(c.eyeL[0]-1,c.eyeL[1]+c.eyeH+9,12,4,c.cheek)+ellipse(c.eyeR[0]+1,c.eyeR[1]+c.eyeH+9,12,4,c.cheek)+'</g>';
  }
  s+=drawEyes(c,expression);
  const [nx,ny]=c.nose;
  s+=c.id==='mori'?path(`M ${nx-5} ${ny-5} L ${nx+5} ${ny-5} L ${nx+6} ${ny+2} Q ${nx} ${ny+6} ${nx-6} ${ny+2} Z`,c.shade,0):line(`M ${nx} ${ny-2} L ${nx+1} ${ny+2} L ${nx+3} ${ny+2}`,c.shade,1.5);
  s+=drawMouth(c,expression);
  if(expression==='sadness')s+=ellipse(c.eyeL[0]-7,c.eyeL[1]+c.eyeH+7,2,4,'#abd3de')+ellipse(c.eyeR[0]+7,c.eyeR[1]+c.eyeH+7,2,4,'#abd3de');
  s+='</g>'+c.hairFront()+c.accessory();
  if(['anxiety','agitation','deceit'].includes(expression))s+=path('M 196 94 L 199 101 Q 201 107 196 109 Q 190 106 193 101 Z','#b9deec',1,'#7eb0c2');
  return `<svg xmlns="http://www.w3.org/2000/svg" width="256" height="256" viewBox="0 0 256 256">${s}</svg>`;
}

await mkdir('public/original-art',{recursive:true});
await mkdir('public/portraits',{recursive:true});
const manifest=[];
for(const id of Object.keys(PEOPLE)){
  await mkdir(`public/portraits/${id}`,{recursive:true});
  for(let index=0;index<EXPRESSIONS.length;index++){
    const svg=portrait(id,EXPRESSIONS[index]);
    // Actual pixel clusters: rasterize original at128, then nearest-neighbor256.
    // This is UNIFORM resolution sampling, never anatomical resizing/warping.
    const small=await sharp(Buffer.from(svg)).resize(128,128).png().toBuffer();
    await sharp(small).resize(256,256,{kernel:'nearest'}).webp({lossless:true}).toFile(`public/portraits/${id}/${index}.webp`);
    if(index===0){
      await writeFile(`public/original-art/${id}.svg`,svg);
      await sharp(small).resize(768,768,{kernel:'nearest'}).png().toFile(`public/original-art/${id}.png`);
    }
  }
  manifest.push({id,frames:EXPRESSIONS.length,resolution:256,source:'individually-authored',expressions:EXPRESSIONS});
  console.log(`${id}: ${EXPRESSIONS.length} separately drawn expression images`);
}
await writeFile('public/portraits/manifest.json',JSON.stringify(manifest,null,2));
await mkdir('tests/artifacts',{recursive:true});
await sharp({create:{width:1024,height:300,channels:4,background:'#1b1b2b'}})
  .composite(await Promise.all(Object.keys(PEOPLE).map(async(id,i)=>({input:await sharp(`public/portraits/${id}/0.webp`).png().toBuffer(),left:i*256,top:24}))))
  .png().toFile('tests/artifacts/original-cast.png');
