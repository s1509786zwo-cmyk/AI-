import sharp from 'sharp';
import { mkdir } from 'node:fs/promises';

await mkdir('public/portraits/analyst', { recursive: true });
const meta = await sharp('public/characters/analyst.png').metadata();
const cellW = Math.floor(meta.width / 4), cellH = Math.floor(meta.height / 4);
for (let frame = 0; frame < 16; frame++) {
  const { data, info } = await sharp('public/characters/analyst.png')
    .extract({ left: frame % 4 * cellW, top: Math.floor(frame / 4) * cellH, width: cellW, height: cellH })
    .resize(256, 256, { kernel: 'nearest' }).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
  const width = info.width;
  const samples = [[2, 2], [width - 3, 2], [2, width - 3], [width - 3, width - 3], [width / 2, 2]].map(([x, y]) => {
    const offset = (Math.floor(y) * width + Math.floor(x)) * 4;
    return [data[offset], data[offset + 1], data[offset + 2]];
  });
  const background = [0, 1, 2].map(c => samples.map(s => s[c]).sort((a, b) => a - b)[2]);
  const seen = new Uint8Array(width * width);
  const queue = [];
  for (let i = 0; i < width; i++) queue.push(i, (width - 1) * width + i, i * width, i * width + width - 1);
  let head = 0;
  while (head < queue.length) {
    const pixel = queue[head++];
    if (seen[pixel]) continue;
    seen[pixel] = 1;
    const at = pixel * 4;
    if (Math.hypot(data[at] - background[0], data[at + 1] - background[1], data[at + 2] - background[2]) > 26) continue;
    data[at + 3] = 0;
    const x = pixel % width, y = Math.floor(pixel / width);
    if (x > 0) queue.push(pixel - 1);
    if (x < width - 1) queue.push(pixel + 1);
    if (y > 0) queue.push(pixel - width);
    if (y < width - 1) queue.push(pixel + width);
  }
  await sharp(data, { raw: { width, height: width, channels: 4 } }).webp({ lossless: true }).toFile(`public/portraits/analyst/${frame}.webp`);
}
console.log('Analyst: 16 expression portraits prepared');
