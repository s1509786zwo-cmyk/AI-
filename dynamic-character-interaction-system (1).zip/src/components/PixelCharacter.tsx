"use client";

import { useEffect, useRef, useState } from 'react';
import { EXPR_LABEL, type ExprId, type Look } from '@/lib/engine/types';
import { glitchPass } from './glitch';

/** 表情 → シート内フレーム番号 */
const FRAMES: Record<ExprId, number> = { normal: 0, smile: 1, faint: 2, confusion: 3, surprise: 4, unease: 5, anxiety: 6, anger: 7, sadness: 8, tension: 9, suspicion: 10, blank: 11, agitation: 12, deceit: 13, blush: 14, wink: 15, thinking: 3, excited: 1, sleepy: 11, relieved: 2, pout: 7, embarrassed: 14 };
/** フレームの位置が揃っていないシートは、揃っている先頭4枚だけを使う（絵が飛ばないように） */
const USABLE_FRAMES: Record<string, number> = { peach: 4, blue: 4 };
const FALLBACK_WITHIN_FOUR: Record<ExprId, number> = { normal: 0, smile: 1, faint: 2, confusion: 3, surprise: 3, unease: 0, anxiety: 3, anger: 0, sadness: 0, tension: 0, suspicion: 3, blank: 0, agitation: 3, deceit: 2, blush: 2, wink: 1, thinking: 3, excited: 1, sleepy: 0, relieved: 2, pout: 0, embarrassed: 2 };
const GLITCH_FRAMES: Record<number, number> = { 1: 3, 2: 4, 3: 5 };

const cache = new Map<string, Promise<HTMLImageElement>>();
function image(src: string): Promise<HTMLImageElement> {
  if (!cache.has(src)) cache.set(src, new Promise((resolve, reject) => { const img = new Image(); img.onload = () => resolve(img); img.onerror = () => { cache.delete(src); reject(new Error('Portrait unavailable')); }; img.src = src; }));
  return cache.get(src)!;
}
function frameFor(portrait: string, expr: ExprId): number {
  const limit = USABLE_FRAMES[portrait];
  return limit ? FALLBACK_WITHIN_FOUR[expr] : FRAMES[expr];
}

export interface GlitchSignal { id: number; level: number; }
interface Props { look: Look; expr: ExprId; size?: number; glitchSignal?: GlitchSignal | null; className?: string; talking?: boolean; name?: string; }

/**
 * 原画をそのまま表示する。フィルタ・引き伸ばし・顔への描き足しは一切行わない。
 * 動きは「呼吸」「疲れた人のうつむき」「落ち着きのない人の身じろぎ」と、尋問中の短いグリッチだけ。
 */
export function PixelCharacter({ look, expr, size = 280, glitchSignal = null, className = '', talking = false, name = 'キャラクター' }: Props) {
  const canvas = useRef<HTMLCanvasElement>(null);
  const frames = useRef<HTMLImageElement[]>([]);
  const current = useRef(expr);
  const settings = useRef({ look, expr, talking });
  settings.current = { look, expr, talking };
  const glitch = useRef({ active: false, start: 0, level: 1, lastId: glitchSignal?.id ?? 0 });
  const [loaded, setLoaded] = useState(false);
  const portrait = look.portrait ?? 'lilac';

  useEffect(() => {
    if (!glitchSignal) { glitch.current.active = false; canvas.current?.parentElement?.removeAttribute('data-glitch'); return; }
    if (glitchSignal.id !== glitch.current.lastId) {
      glitch.current = { active: true, start: performance.now(), level: Math.max(1, Math.min(3, glitchSignal.level)), lastId: glitchSignal.id };
      canvas.current?.parentElement?.setAttribute('data-glitch', String(glitch.current.level));
    }
  }, [glitchSignal]);

  useEffect(() => {
    let live = true; setLoaded(false);
    Promise.all(Array.from({ length: 16 }, (_, i) => image(`/portraits/${portrait}/${i}.webp`))).then(images => {
      if (live) { frames.current = images; setLoaded(true); }
    }).catch(() => {});
    return () => { live = false; };
  }, [portrait]);

  useEffect(() => {
    const el = canvas.current; const ctx = el?.getContext('2d', { willReadFrequently: true }); if (!el || !ctx) return;
    const scratchEl = document.createElement('canvas'); scratchEl.width = 256; scratchEl.height = 256;
    const scratch = scratchEl.getContext('2d'); if (!scratch) return;
    let raf = 0, last = 0, changed = 0, old = expr;
    let flickerUntil = 0, nextFlicker = performance.now() + 2600 + Math.random() * 1800;
    let fidgetUntil = 0, nextFidget = performance.now() + 1500;
    const motion = !window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const draw = (t: number) => {
      if (t - last < 42) { raf = requestAnimationFrame(draw); return; } last = t;
      const props = settings.current;
      const imgs = frames.current;
      if (imgs.length !== 16) { raf = requestAnimationFrame(draw); return; }
      const style = props.look.idleStyle ?? 'steady';
      const id = props.look.portrait ?? 'lilac';
      if (current.current !== props.expr) { old = current.current; current.current = props.expr; changed = t; }
      let shown = props.expr;
      if (motion && style === 'restless' && props.expr === 'normal') {
        if (t > nextFlicker) { flickerUntil = t + 420; nextFlicker = t + 3000 + Math.random() * 2800; }
        if (t < flickerUntil) shown = 'unease';
      }
      const progress = Math.min(1, (t - changed) / 140);
      ctx.clearRect(0, 0, 256, 256); ctx.imageSmoothingEnabled = false;
      const shake = motion && props.expr === 'agitation' ? Math.round(Math.sin(t / 70) * 2) : 0;
      const breathe = motion ? Math.round(Math.sin(t / (style === 'tired' ? 1500 : 980)) * (style === 'tired' ? 2.4 : 1.5)) : 0;
      const sag = style === 'tired' ? 4 : 0;
      const nod = props.talking && motion ? Math.round(Math.sin(t / 190)) : 0;
      if (motion && style === 'restless' && t > nextFidget) { fidgetUntil = t + 160; nextFidget = t + 1400 + Math.random() * 2200; }
      const fidget = motion && style === 'restless' && t < fidgetUntil ? (Math.sin(t / 37) > 0 ? 2 : -2) : 0;
      ctx.save();
      ctx.translate(shake + fidget, breathe + nod + sag);
      if (progress < 1) { ctx.globalAlpha = 1; ctx.drawImage(imgs[frameFor(id, old)], 0, 0, 256, 256); ctx.globalAlpha = progress; }
      ctx.drawImage(imgs[frameFor(id, shown)], 0, 0, 256, 256); ctx.globalAlpha = 1;
      if (props.expr === 'excited' || props.expr === 'wink') {
        ctx.fillStyle = '#f6e9be'; const sparkle = Math.floor(t / 450) % 2; ctx.fillRect(207, 57 + sparkle * 2, 3, 9); ctx.fillRect(204, 60 + sparkle * 2, 9, 3);
      }
      if (props.expr === 'thinking') {
        ctx.fillStyle = '#d5c7ef'; for (let i = 0; i < 3; i++) if (Math.floor(t / 400) % 3 >= i) ctx.fillRect(203 + i * 8, 54, 3, 3);
      }
      ctx.restore();
      const g = glitch.current;
      if (g.active) {
        const k = Math.floor((t - g.start) / 42);
        const total = motion ? (GLITCH_FRAMES[g.level] ?? 3) : 1;
        if (k >= total) { g.active = false; el.parentElement?.removeAttribute('data-glitch'); }
        else glitchPass(ctx, scratch, k, g.level, imgs, motion);
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => { cancelAnimationFrame(raf); el.parentElement?.removeAttribute('data-glitch'); };
    // The animation consumes the latest props through settings.current.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return <span className={`pixel-character ${className}`} role="img" aria-label={`${name}：${EXPR_LABEL[expr]}`} data-portrait={portrait} style={{ width: size, height: size }}>
    {/* eslint-disable-next-line @next/next/no-img-element */}
    <img src={`/portraits/${portrait}/${frameFor(portrait, expr)}.webp`} alt="" width={256} height={256} style={{ opacity: loaded ? 0 : 1 }} />
    <canvas ref={canvas} width={256} height={256} aria-hidden="true" style={{ opacity: loaded ? 1 : 0 }} />
  </span>;
}
