"use client";
import { useCallback, useEffect, useRef, useState } from 'react';
import { ALERT_DURATION_MS, recoverVitals, restingVitals } from '@/lib/engine/ecg';
import type { Biosign, ReplyPlan } from '@/lib/engine/types';
import type { MonitorAlert } from './BiosignMonitor';
import type { GlitchSignal } from './PixelCharacter';

interface Options { scope: string; baseline: number; sound: boolean; }
interface Response { bio: Biosign; at: number; }

/** Scope-bound, cancellable effects. Skipping text does not skip a physical reaction. */
export function useObservationEffects({ scope, baseline, sound }: Options) {
  const [bio, setBio] = useState<Biosign>(() => restingVitals(baseline));
  const [alert, setAlert] = useState<MonitorAlert | null>(null);
  const [glitch, setGlitch] = useState<GlitchSignal | null>(null);
  const [flash, setFlash] = useState(0);
  const latest = useRef({ scope, baseline, sound });
  latest.current = { scope, baseline, sound };
  const currentScope = useRef(scope);
  const response = useRef<Response | null>(null);
  const stored = useRef(new Map<string, Response>());
  const played = useRef(new Set<string>());
  const fxId = useRef(0);
  const timers = useRef(new Set<ReturnType<typeof setTimeout>>());
  const audio = useRef<AudioContext | null>(null);
  const voices = useRef(new Set<OscillatorNode>());

  const clear = useCallback(() => {
    timers.current.forEach(clearTimeout);
    timers.current.clear();
    voices.current.forEach(oscillator => { try { oscillator.stop(); } catch {} });
    voices.current.clear();
    setAlert(null); setGlitch(null); setFlash(0);
  }, []);

  const later = useCallback((fn: () => void, ms: number, owner: string) => {
    const timer = setTimeout(() => {
      timers.current.delete(timer);
      if (latest.current.scope === owner) fn();
    }, ms);
    timers.current.add(timer);
  }, []);

  // Only called during a user gesture. Browser autoplay restrictions are respected.
  const unlock = useCallback(() => {
    if (!latest.current.sound) return;
    try {
      const context = audio.current ?? new AudioContext();
      audio.current = context;
      if (context.state === 'suspended') void context.resume();
    } catch {}
  }, []);

  const warningSound = useCallback(() => {
    if (!latest.current.sound) return;
    try {
      const context = audio.current ?? new AudioContext();
      audio.current = context;
      if (context.state === 'suspended') void context.resume();
      for (let i = 0; i < 3; i++) {
        const oscillator = context.createOscillator();
        const volume = context.createGain();
        const at = context.currentTime + i * 0.16;
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(i % 2 ? 640 : 860, at);
        volume.gain.setValueAtTime(0.001, at);
        volume.gain.linearRampToValueAtTime(0.04, at + 0.014);
        volume.gain.exponentialRampToValueAtTime(0.001, at + 0.12);
        oscillator.connect(volume); volume.connect(context.destination);
        voices.current.add(oscillator);
        oscillator.onended = () => voices.current.delete(oscillator);
        oscillator.start(at); oscillator.stop(at + 0.13);
      }
    } catch {}
  }, []);

  useEffect(() => {
    clear(); currentScope.current = scope;
    response.current = stored.current.get(scope) ?? null;
    setBio(response.current ? recoverVitals(response.current.bio, baseline, Date.now() - response.current.at) : restingVitals(baseline));
    const update = setInterval(() => {
      if (currentScope.current !== latest.current.scope) return;
      const r = response.current;
      setBio(r ? recoverVitals(r.bio, latest.current.baseline, Date.now() - r.at) : restingVitals(latest.current.baseline));
    }, 160);
    return () => { clearInterval(update); clear(); };
  }, [scope, baseline, clear]);

  useEffect(() => {
    if (!sound) {
      voices.current.forEach(o => { try { o.stop(); } catch {} });
      voices.current.clear();
    }
  }, [sound]);
  useEffect(() => () => { void audio.current?.close(); }, []);

  const trigger = useCallback((plan: ReplyPlan, answerId: string) => {
    const owner = latest.current.scope;
    const key = `${owner}/${answerId}`;
    if (played.current.has(key)) return;
    played.current.add(key);
    if (played.current.size > 200) played.current.delete(played.current.values().next().value!);
    clear();
    const r: Response = { bio: plan.bio, at: Date.now() };
    response.current = r; stored.current.set(owner, r); setBio(plan.bio);
    if (plan.alert) {
      const id = ++fxId.current;
      setAlert({ id, reason: plan.alert.reason, peak: plan.alert.peakBpm });
      setFlash(id); warningSound();
      later(() => setAlert(null), ALERT_DURATION_MS, owner);
      later(() => setFlash(0), 650, owner);
    }
    if (plan.glitch && plan.glitch > 0) {
      const level = plan.glitch;
      later(() => setGlitch({ id: ++fxId.current, level }), plan.alert ? 100 : 0, owner);
    }
  }, [clear, later, warningSound]);

  return { bio, alert, glitch, flash, trigger, clear, unlock, active: alert !== null };
}
