/** 数フレームだけの映像破壊。RGBずれ・横ずれ・走査線・別表情の混入。通常時は一切呼ばれない */
export function glitchPass(
  ctx: CanvasRenderingContext2D,
  scratch: CanvasRenderingContext2D,
  frame: number,
  level: number,
  images: HTMLImageElement[],
  animate: boolean,
): void {
  const W = 256;
  const rnd = (a: number, b: number) => a + Math.random() * (b - a);
  const d = animate ? Math.min(3, level) : 1;
  const src = ctx.getImageData(0, 0, W, W);
  const out = ctx.createImageData(W, W);
  const s = src.data, o = out.data;
  for (let y = 0; y < W; y++) {
    for (let x = 0; x < W; x++) {
      const i = (y * W + x) * 4;
      const ir = (y * W + Math.max(0, x - d)) * 4;
      const ib = (y * W + Math.min(W - 1, x + d)) * 4;
      o[i] = s[ir];
      o[i + 1] = s[i + 1];
      o[i + 2] = s[ib + 2];
      o[i + 3] = Math.max(s[ir + 3], s[i + 3], s[ib + 3]);
    }
  }
  ctx.putImageData(out, 0, 0);
  if (!animate) return;

  scratch.clearRect(0, 0, W, W);
  scratch.drawImage(ctx.canvas, 0, 0);
  const bands = level + 1;
  for (let b = 0; b < bands; b++) {
    const y = Math.floor(rnd(30, 226)), h = Math.floor(rnd(4, 16));
    const dx = (Math.random() < 0.5 ? -1 : 1) * Math.floor(rnd(2, 5) * level);
    ctx.clearRect(0, y, W, h);
    ctx.drawImage(scratch.canvas, 0, y, W, h, dx, y, W, h);
  }
  for (let n = 0; n < level + 1; n++) {
    ctx.fillStyle = Math.random() < 0.5 ? 'rgba(210,240,255,.55)' : 'rgba(255,90,120,.45)';
    ctx.fillRect(Math.floor(rnd(0, 70)), Math.floor(rnd(20, 240)), Math.floor(rnd(70, 190)), 1);
  }
  if (level >= 2 && frame % 2 === 1 && images.length) {
    const other = images[Math.floor(Math.random() * images.length)];
    const y = Math.floor(rnd(70, 150)), h = Math.floor(rnd(14, 30));
    ctx.save();
    ctx.beginPath();
    ctx.rect(0, y, W, h);
    ctx.clip();
    ctx.globalAlpha = 0.4;
    ctx.drawImage(other, 0, 0, W, W);
    ctx.restore();
  }
  if (level === 3) {
    const sx = Math.floor(rnd(40, 190)), sy = Math.floor(rnd(60, 200));
    ctx.drawImage(scratch.canvas, sx, sy, 28, 12, Math.floor(rnd(30, 200)), Math.floor(rnd(60, 200)), 28, 12);
    if (frame === 2) {
      ctx.clearRect(0, 0, W, W);
      ctx.drawImage(scratch.canvas, 4, 0);
    }
  }
}
