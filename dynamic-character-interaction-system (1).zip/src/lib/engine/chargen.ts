import type { AiStyle, Bucket, ExprId, Gender, IdleStyle, Look, Persona, PortraitId } from './types';

export type SpeechId = 'polite' | 'rough' | 'kansai' | 'ojou' | 'shy' | 'casual' | 'flat' | 'terse';
export interface CharacterProfile {
  favoriteFood: string;
  dislikedFood: string;
  drink: string;
  hobby: string;
  hobbyDetail: string;
  favoriteColor: string;
  music: string;
  family: string[];
  familyMemory: string;
  hometown: string;
  address: string;
  pet: string;
  dream: string;
  fear: string;
  childhood: string;
  distinguishing: string;
  dinner: string;
  lunch: string;
  breakfast: string;
  mealTime: string;
  companion: string;
  companionName: string;
  schedule: Record<Bucket, { location: string; activity: string; time: string; evidence: string }>;
}
export interface CharDef {
  id: string;
  name: string;
  age: number;
  job: string;
  gender: Gender;
  persona: Persona;
  personaLabel: string;
  speechId: SpeechId;
  speechLabel: string;
  trait: string;
  aiStyle: AiStyle;
  aiStyleLabel: string;
  aiReveal: string[];
  look: Look;
  opening: string;
  openingExpr: ExprId;
  idleExpr: ExprId;
  restBpm: number;
  appearance: string;
  profile: CharacterProfile;
}
export type PublicCharacter = Pick<CharDef, 'id' | 'name' | 'age' | 'job' | 'gender' | 'persona' | 'personaLabel' | 'speechId' | 'speechLabel' | 'trait' | 'look' | 'opening' | 'openingExpr' | 'idleExpr' | 'restBpm' | 'appearance'>;

export type HairGroup = 'long' | 'medium' | 'short' | 'tied';
/** 見た目の系統。同じ系統から2人は選ばない（別人に見えることを保証する） */
export type Family = 'longHairGirl' | 'twinTailGlasses' | 'shortHairBoy' | 'ponytailGlasses' | 'sidePartTie';
export interface ArtStyle {
  id: PortraitId; gender: Gender; label: string; family: Family;
  hair: Look['hair']; color: string; outfit: Look['outfit']; glasses?: boolean;
  hairGroup: HairGroup; outfitGroup: string; hairText: string; faceText: string; outfitText: string;
  /** 表情フレームの位置が揃っていないシートは選出対象から外す */
  retired?: boolean;
}
export const ART_STYLES: ArtStyle[] = [
  { id:'lilac',   gender:'f', label:'ライラック', family:'longHairGirl',    hair:'wavyMid',      color:'#b7abdd', outfit:'sailor',  hairGroup:'medium', outfitGroup:'sailor',   hairText:'淡いラベンダーのふわりとした髪', faceText:'やわらかな丸みのある顔', outfitText:'白いセーラー襟に紺のリボン' },
  { id:'mint',    gender:'f', label:'ミント',     family:'longHairGirl',    hair:'longStraight', color:'#a5cbd5', outfit:'sailor',  hairGroup:'long',   outfitGroup:'blouse',   hairText:'ミントグレーの長い三つ編み', faceText:'面長で静かな顔立ち', outfitText:'フリルのブラウスとギンガムのベスト' },
  { id:'ivory',   gender:'f', label:'アイボリー', family:'longHairGirl',    hair:'longStraight', color:'#e7d9ce', outfit:'knit',    hairGroup:'long',   outfitGroup:'cardigan', hairText:'白金色のウェーブのかかった長い髪', faceText:'小さな顎の華奢な顔', outfitText:'チャコールのカーディガンとラベンダーのリボン' },
  { id:'peach',   gender:'f', label:'ピーチ',     family:'twinTailGlasses', hair:'twinTails',    color:'#efc6c4', outfit:'blazer',  glasses:true, hairGroup:'long', outfitGroup:'shirt', hairText:'桃色のツインテール', faceText:'丸い大きなメガネの奥の丸顔', outfitText:'白シャツに黒いネクタイ', retired:true },
  { id:'ash',     gender:'m', label:'アッシュ',   family:'shortHairBoy',    hair:'shortMessy',   color:'#b5b3d0', outfit:'knit',    hairGroup:'short',  outfitGroup:'cardigan', hairText:'銀灰色の無造作な短髪', faceText:'輪郭のはっきりした中性的な顔', outfitText:'黒いタートルネックに淡い紫のカーディガン' },
  { id:'rose',    gender:'m', label:'ローズ',     family:'shortHairBoy',    hair:'shortMessy',   color:'#debcc7', outfit:'hoodie',  hairGroup:'short',  outfitGroup:'hoodie',   hairText:'ふわふわした桃色の短髪とアホ毛', faceText:'丸くて幼い印象の顔', outfitText:'ゆったりした薄紫のパーカー' },
  { id:'blue',    gender:'m', label:'ブルー',     family:'shortHairBoy',    hair:'shortNeat',    color:'#a9c0dc', outfit:'blazer',  hairGroup:'short',  outfitGroup:'shirt',    hairText:'淡い青灰色の短髪', faceText:'卵型のすっきりした顔', outfitText:'白シャツと紺のベスト', retired:true },
  { id:'noir',    gender:'m', label:'ノワール',   family:'ponytailGlasses', hair:'ponytail',     color:'#726c88', outfit:'blazer',  glasses:true, hairGroup:'tied', outfitGroup:'waistcoat', hairText:'低い位置で束ねた黒髪', faceText:'丸いメガネをかけたシャープな輪郭', outfitText:'チャコールのウエストコートに梅色のネクタイ' },
  { id:'analyst', gender:'m', label:'アナリスト', family:'sidePartTie',     hair:'shortNeat',    color:'#36384f', outfit:'blazer',  glasses:true, hairGroup:'short', outfitGroup:'formal', hairText:'きちんと横分けにした紺色の短髪', faceText:'細い長方形のメガネをかけた細面', outfitText:'クリーム色のシャツに細い紺のネクタイとIDストラップ' },
];
export const ACTIVE_STYLES = ART_STYLES.filter(a=>!a.retired);
const IDLE_TEXT: Record<IdleStyle,string> = { steady:'落ち着いた表情', tired:'疲れたような表情', restless:'落ち着きのない様子' };
function shuffled<T>(items:T[]):T[]{const a=[...items];for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]];}return a;}
const surnames = ['白瀬','星野','天城','冬月','水無瀬','藤堂','綾瀬','東雲','久遠','九条','灰原','南','柊','八雲','橘','鳴海','真崎','花宮','月城','一ノ瀬','桐生','相馬','氷室','榊'];
const firstF = ['ゆき','ひかり','澪','奏','紬','雫','灯','咲良','結','真冬','ひより','莉子','すず','楓'];
const firstM = ['蓮','湊','律','蒼','透','翼','朔','伊織','慧','類','晴','凪','千尋','そら'];
const jobs = ['電脳書庫司書','記憶整備士','夜間カフェ店員','ネオン修理技師','声帯クリニック職員','記録局事務員','地下鉄駅員','配達ドライバー','古書店員','音楽教室講師','温室管理人','保安警備員'];
const speechLabels: Record<SpeechId,string> = { polite:'丁寧な敬語', rough:'ぶっきらぼう', kansai:'関西ことば', ojou:'上品な話し方', shy:'控えめ・人見知り', casual:'親しみやすい', flat:'落ち着いた口調', terse:'短く、静かに' };
const personaLabels: Record<Persona,string> = { gentle:'温厚', hot:'気が強い', quiet:'もの静か' };
const hobbies = [
  ['古い本を集めること','紙の端が日焼けしている本が好き。ページをめくる匂いが落ち着く'],
  ['ピアノ','夜は消音ペダルで弾く。いつか誰かの前で一曲弾いてみたい'],
  ['小さな鉢植えを育てること','窓辺に多肉植物を三つ並べている。名前もつけている'],
  ['星を見ること','街の光が強いから、屋上でいちばん暗い方角を見る'],
  ['お菓子作り','クッキーの端っこを焦がしがち。そこだけ自分で食べる'],
  ['猫の写真を撮ること','駅の裏にいる白い猫を撮る。まだ名前は決めていない'],
  ['古いゲーム','セーブできないゲームが好き。一度きりって、なんだか人間らしい'],
  ['雨の音を録音すること','屋根や傘で音が変わる。眠れない夜に聞き返す'],
];
export const pick = <T,>(items: T[]): T => items[Math.floor(Math.random()*items.length)];
const integer = (a:number,b:number) => a+Math.floor(Math.random()*(b-a+1));
export function characterVoice(cd: Pick<CharDef,'speechId'|'gender'>, plain:string, polite?:string, short?:string): string {
  const first = cd.gender === 'f' ? 'わたし' : '僕';
  let text = plain.replace(/私/g, first);
  switch (cd.speechId) {
    case 'polite': return polite ?? text;
    case 'ojou': return (polite ?? text).replace(/です([。！？])/g,'ですわ$1').replace(/ます([。！？])/g,'ますわ$1');
    case 'shy': return 'あの……'+(polite ?? text);
    case 'rough': return text.replace(/僕|わたし/g,cd.gender==='m'?'俺':'あたし').replace(/だよ/g,'だ').replace(/だね/g,'だな').replace(/なんだ/g,'なんだよ');
    case 'kansai': return text.replace(/僕|わたし/g,cd.gender==='m'?'俺':'うち').replace(/だよ/g,'やで').replace(/だね/g,'やな').replace(/なんだ/g,'なんや').replace(/かな([。？])/g,'やろか$1').replace(/だから/g,'せやから').replace(/ないよ/g,'ないねん');
    case 'flat': return polite ?? text;
    case 'terse': return '……'+(short ?? text.split(/(?<=[。！？])/)[0]);
    default: return text;
  }
}

export function generateCharacter(options: { gender?:Gender; portrait?:PortraitId; idleStyle?:IdleStyle } = {}): CharDef {
  const art = options.portrait ? ART_STYLES.find(a=>a.id===options.portrait)! : pick(ACTIVE_STYLES.filter(a=>!options.gender || a.gender===options.gender));
  const gender = art.gender;
  const persona = pick<Persona>(['gentle','hot','quiet']);
  const speechId = pick<SpeechId>(persona==='quiet'?['terse','shy','flat','polite']:persona==='hot'?['rough','kansai','casual','ojou']:['polite','shy','casual','kansai','ojou']);
  const [hobby,hobbyDetail] = pick(hobbies);
  const food = pick(['いちごのショートケーキ','焼きたてのパン','ラーメン','オムライス','クリームシチュー','桃のタルト','焼き魚','カレー']);
  const sibling = pick(['妹','弟','姉','兄']);
  const family = pick([['母',sibling],['父','母'],['母'],['姉'],['父','母',sibling]]);
  const schedule: CharacterProfile['schedule'] = {
    morning:{location:'職場',activity:'開店前の準備をしていた',time:'8時12分',evidence:'出勤記録'},
    noon:{location:pick(['駅前の食堂','職場の休憩室','屋上のベンチ']),activity:'昼ごはんを食べていた',time:'12時18分',evidence:'食事の決済記録'},
    evening:{location:'職場',activity:'残って片付けをしていた',time:'18時37分',evidence:'退勤記録'},
    night:{location:pick(['自宅','友人の部屋','駅前のカフェ']),activity:pick(['本を読んでいた','古い音楽を聴いていた','夕食の後片付けをしていた']),time:'21時04分',evidence:pick(['通話履歴','カフェのレシート','部屋の鍵の記録'])},
    late:{location:'自宅',activity:'眠ろうとしていた',time:'23時12分',evidence:'端末の充電記録'},
  };
  const aiStyle = pick<AiStyle>(['humanlike','mechanical','emotive']);
  const cd: CharDef = {
    id:Math.random().toString(36).slice(2,10),
    name:`${pick(surnames)} ${pick(gender==='f'?firstF:firstM)}`,
    age:integer(20,34),job:pick(jobs),gender,persona,personaLabel:personaLabels[persona],speechId,speechLabel:speechLabels[speechId],
    trait:pick(persona==='gentle'?['人の名前をよく覚える','褒められると目をそらす','好きな話題だとよく話す']:persona==='hot'?['嘘をつかれるのが苦手','心配を隠して強がる','納得できないと聞き返す']:['考えてから話す','沈黙を気にしない','思い出には少し饒舌']),
    aiStyle,aiStyleLabel:aiStyle==='mechanical'?'生体制御型':aiStyle==='emotive'?'感情模倣型':'高度擬態型',
    aiReveal:aiStyle==='mechanical'?['追及の前後で心拍がほとんど変わらなかった。','同じ質問に、語句まで同じ回答を返した。','感情の言葉と、瞳孔の反応が一致しなかった。']:aiStyle==='humanlike'?['思い出の語り方は自然だが、心拍変動が小さすぎた。','時刻についてだけ、過剰に詳しい記憶が現れた。','再確認されても、記憶が揺らぐ様子が少なかった。']:['表情は変わるが、生体反応の幅が整いすぎていた。','言葉の途中に、長い不自然な沈黙があった。','感情と証言の両方を見る必要があった。'],
    look:{portrait:art.id,idleStyle:options.idleStyle??pick<IdleStyle>(['steady','tired','restless']),skin:'light',hair:art.hair,hairColor:art.color,eyeColor:art.color,outfit:art.outfit,outfitColor:art.color,outfitSub:'#c8bde8',acc:'clip',accColor:'#e9e3f4',glasses:art.glasses},
    opening:'',openingExpr:persona==='hot'?'suspicion':persona==='quiet'?'normal':'faint',idleExpr:'normal',restBpm:integer(65,83),appearance:'',
    profile:{favoriteFood:food,dislikedFood:pick(['苦い野菜','辛すぎるもの','冷えたごはん']),drink:pick(['ミルクティー','ブラックコーヒー','温かいココア','桃の紅茶']),hobby,hobbyDetail,favoriteColor:pick(['ラベンダー','夜の青','淡いピンク','ミント色']),music:pick(['古いピアノ曲','雨音の入った環境音楽','昔のロック','静かなジャズ']),family,familyMemory:`${family[family.length-1]}が冬に編んでくれたマフラーを、まだ持っている`,hometown:pick(['北区','海沿いの旧市街','第五居住区','東区']),address:`第${integer(2,9)}居住区の${integer(2,12)}階`,pet:pick(['白い猫','小さな文鳥','ペットはいない']),dream:pick(['海の見える街で小さな店を開くこと','自分の作ったものを誰かに覚えてもらうこと','家族と安心して暮らすこと','一度、街の外で星を見ること']),fear:pick(['大切な人を忘れてしまうこと','誰も自分を覚えていないこと','本物の人間なのに処分されること']),childhood:pick(['夏休みに、川の石を集めていた。青い石を一つだけ宝物にしていた','雨の日に家族とホットケーキを焼いた。最初の一枚だけ真っ黒になった','駅の前で迷子になった。迎えに来た母のコートの匂いを覚えている']),distinguishing:'',dinner:pick(['焼き魚とごはん','カレー','オムライス','トマトのパスタ','野菜のスープ']),lunch:pick(['サンドイッチ','ラーメン','おにぎり']),breakfast:pick(['トーストと卵','ヨーグルト','お茶だけ']),mealTime:'19時14分',companion:pick(['一人','友人','家族']),companionName:`${pick(surnames)} ${pick(firstF)}`,schedule},
  };
  cd.profile.distinguishing=cd.trait;
  cd.idleExpr=cd.look.idleStyle==='tired'?'sleepy':'normal';
  cd.appearance=[art.hairText,art.faceText,art.outfitText,IDLE_TEXT[cd.look.idleStyle??'steady']].join('・');
  cd.opening=characterVoice(cd,persona==='hot'?'何を聞きたい？ ……ちゃんと話は聞くよ。':persona==='quiet'?'何から、話せばいい？':'……何を聞きたいの？ 答えられることなら、話すよ。',persona==='hot'?'用件を聞かせてください。疑われるのは、好きじゃありません。':'……何を聞きたいんですか？ 答えられることなら、お話しします。','何を、聞きたい？');
  return cd;
}
/** 3人は必ず別系統（髪型・顔立ち・服装・メガネ・性別の組み合わせが違う）から選ぶ */
export function generateCast(): CharDef[] {
  const families=shuffled(Array.from(new Set(ACTIVE_STYLES.map(a=>a.family))));
  let chosen:ArtStyle[]=[];
  for(let attempt=0;attempt<40&&chosen.length<3;attempt++){
    const picked=shuffled(families).slice(0,3).map(f=>pick(ACTIVE_STYLES.filter(a=>a.family===f)));
    if(picked.some(a=>a.gender==='f')&&picked.some(a=>a.gender==='m'))chosen=picked;
  }
  if(chosen.length<3)chosen=[ACTIVE_STYLES[0],ACTIVE_STYLES.find(a=>a.family==='shortHairBoy')!,ACTIVE_STYLES.find(a=>a.family==='sidePartTie')!];
  const idles=shuffled<IdleStyle>(['steady','tired','restless']);
  const people:CharDef[]=[];
  const names=new Set<string>();
  shuffled(chosen).forEach((art,i)=>{
    let person=generateCharacter({portrait:art.id,idleStyle:idles[i]});
    while(names.has(person.name))person=generateCharacter({portrait:art.id,idleStyle:idles[i]});
    names.add(person.name);people.push(person);
  });
  return people;
}
export function loadCast(json:string|null|undefined):CharDef[] {
  if (json) { try { const list=JSON.parse(json); if (Array.isArray(list)&&list.length===3&&list.every(c=>c.profile&&c.look?.portrait&&ART_STYLES.some(a=>a.id===c.look.portrait))) return list.map(c=>({...c,look:{...c.look,features:[],build:undefined,faceShape:undefined,wardrobe:undefined,hue:0}})); } catch {} }
  return generateCast();
}
export function publicCharacter(c:CharDef):PublicCharacter {
  const {id,name,age,job,gender,persona,personaLabel,speechId,speechLabel,trait,look,opening,openingExpr,idleExpr,restBpm,appearance}=c;
  return {id,name,age,job,gender,persona,personaLabel,speechId,speechLabel,trait,look,opening,openingExpr,idleExpr,restBpm,appearance};
}
