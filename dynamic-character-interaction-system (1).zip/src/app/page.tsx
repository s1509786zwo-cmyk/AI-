"use client";
import { useEffect,useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import { ArrowRight,RefreshCw,MessageSquare,HeartPulse,ScanFace,Sparkles,LoaderCircle,UsersRound } from 'lucide-react';
import { Header } from '@/components/Header';
import { PixelCharacter } from '@/components/PixelCharacter';
import { generateCharacter,generateCast,type PublicCharacter } from '@/lib/engine/chargen';
import { EXPR_LABEL,type ExprId,type Look } from '@/lib/engine/types';
import type { GameCase } from '@/lib/game-view';

const defaultLook:Look={portrait:'lilac',hue:0,saturation:100,skin:'light',hair:'wavyMid',hairColor:'#b7abdd',eyeColor:'#c6b5e7',outfit:'sailor',outfitColor:'#c5c4dd',outfitSub:'#403f60',acc:'clip',accColor:'#eee7f6'};
const fallback:PublicCharacter={id:'preview',name:'白瀬 ゆき',age:23,job:'電脳書庫司書',gender:'f',persona:'quiet',personaLabel:'もの静か',speechId:'shy',speechLabel:'控えめ・人見知り',trait:'思い出には少し饒舌',look:defaultLook,opening:'……何から、話せばいいですか。',openingExpr:'normal',idleExpr:'normal',restBpm:72,appearance:''};
const cycle:ExprId[]=['normal','faint','blush','thinking','normal','wink'];
export default function Home(){
  const router=useRouter();const [cast,setCast]=useState<PublicCharacter[]>([]);const [selected,setSelected]=useState(0);const [expr,setExpr]=useState<ExprId>('normal');const [active,setActive]=useState<GameCase|null>(null);const [starting,setStarting]=useState(false);const [error,setError]=useState('');
  useEffect(()=>{
    setCast(generateCast());
    fetch('/api/game').then(r=>r.json()).then(d=>{if(d.game?.status==='interrogating')setActive(d.game);}).catch(()=>{});
    let step=0;const timer=setInterval(()=>{setExpr(cycle[++step%cycle.length]);},4300);return()=>clearInterval(timer);
  },[]);
  const current=cast[selected]??fallback;
  const start=async()=>{
    if(starting)return;setStarting(true);setError('');
    try{
      const r=await fetch('/api/game',{method:'POST'});
      const d=await r.json();
      if(!r.ok)throw new Error(d.error);
      if(typeof window!=='undefined'){try{sessionStorage.setItem('aid_last_case',d.game.id);}catch{}}
      router.push(`/game?case=${encodeURIComponent(d.game.id)}`);
    }catch(e){setError(e instanceof Error?e.message:'移送に失敗しました。もう一度お試しください。');setStarting(false);}
  };
  return <div className="home-page"><Header/><main className="home-main"><div className="home-intro"><span className="eyebrow">A.I.D. TERMINAL ／ SECTOR 07</span><span>20XX年　午前 02:14　雨</span></div><section className="home-hero"><div className="hero-copy"><div className="hero-badge"><span className="status-dot"/>執行官、新たな任務です。</div><h1>その顔は、<br/><span className="accent">人間のものか。</span></h1><p className="hero-description">優しい声。懐かしい記憶。ほんの一瞬の微笑み。<br/>人間のすべてをまとうAI〈フェイカー〉は、<br/>今もこの街のどこかで、息をしている。</p><p className="hero-description" style={{marginTop:14}}>3人の被疑者と、25回の質問。<br/>あなたの言葉で、隠された正体を見つけてください。</p><div className="hero-actions">{active?<button className="primary-button" onClick={()=>router.push('/game')}>尋問を再開する <ArrowRight size={16}/></button>:<button className="primary-button" onClick={start} disabled={starting}>{starting?<LoaderCircle size={15} className="spin"/>:<ScanFace size={16}/>} {starting?'被疑者を移送中':'尋問を開始する'}<ArrowRight size={16}/></button>}<Link href="/archive" className="secondary-button"><UsersRound size={14}/>人物アーカイブ</Link></div><div className="hero-caption">{active?<>残り {active.totalQuestions-active.usedQuestions} 回 ／ <button className="text-button" style={{fontSize:9}} onClick={start} disabled={starting}>別の任務を開始</button></>:'選択肢はありません。何を聞くかは、あなた次第。'}</div>{error&&<div className="error-banner" style={{marginTop:15}} role="alert">{error}</div>}</div><div className="hero-stage"><div className="city-background"/><span className="corner tl"/><span className="corner tr"/><span className="corner bl"/><span className="corner br"/><div className="stage-label"><ScanFace size={13}/> SUBJECT PREVIEW / 0{selected+1}</div><div className="stage-live"><span className="status-dot"/>LIVE PORTRAIT</div><div className="hero-portrait"><PixelCharacter look={current.look} expr={expr} size={365} name={current.name}/></div><div className="portrait-nameplate"><div><div className="nameplate-name">{current.name}</div><div className="nameplate-details">{current.age}歳 ／ {current.job} ／ {current.personaLabel}</div></div><span className="expression-badge"><Sparkles size={11}/>{EXPR_LABEL[expr]}</span></div></div></section><section><div className="section-heading"><h2>まだ、誰のことも知らない。 <span>SUBJECT DATABASE</span></h2><button className="text-button" onClick={()=>{setCast(generateCast());setSelected(0);setExpr('normal');}}><RefreshCw size={12}/>新しい人物を生成</button></div><div className="preview-roster">{(cast.length?cast:[fallback,fallback,fallback]).map((c,i)=><button key={`${c.id}-${i}`} className="preview-card" onClick={()=>{setSelected(i);setExpr(i===selected?'blush':'normal');}} aria-label={`${c.name}をプレビュー`}><PixelCharacter look={c.look} expr={i===selected?expr:'normal'} size={105} name={c.name}/><div className="preview-details"><div className="preview-id">SUBJECT / 0{i+1}</div><div className="preview-name">{c.name}</div><div className="preview-job">{c.age}歳 ／ {c.job}</div><span className="character-tag">{c.speechLabel}</span></div></button>)}</div></section><section className="protocol-grid" aria-label="ゲームの特徴"><div className="protocol-item"><div className="protocol-icon"><MessageSquare size={18}/></div><div><h3>あなたの言葉で、尋問する。</h3><p>自由な質問に、その人物らしい返答を。<br/>名前も好物も、思い出も、毎回変わります。</p></div></div><div className="protocol-item"><div className="protocol-icon"><HeartPulse size={18}/></div><div><h3>言葉にならない反応を、観る。</h3><p>22種類の表情、心拍、瞳孔、応答の間。<br/>完璧すぎる平静にも、秘密があります。</p></div></div><div className="protocol-item"><div className="protocol-icon"><ScanFace size={18}/></div><div><h3>釈放か、強制停止か。</h3><p>あなたの判断が、誰かの明日を決める。<br/>人間を疑うことも、機械を信じることも。</p></div></div></section><footer className="site-footer"><span>ZERO. ／ AGENCY FOR INHUMAN DETECTION</span><span>可愛い顔の向こう側に、何がいる？</span><span>PIXEL PORTRAITS / V.04</span></footer></main></div>;
}
