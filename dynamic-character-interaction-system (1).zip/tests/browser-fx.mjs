import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import { mkdir } from 'node:fs/promises';
await mkdir('tests/artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const context = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
const page = await context.newPage();
const issues = [];
page.on('pageerror', e => issues.push(e.message));
page.on('console', m => { if (m.type() === 'error') issues.push(m.text()); });
await page.addInitScript(() => {
  window.__alarmPulses = [];
  const create = AudioContext.prototype.createGain;
  AudioContext.prototype.createGain = function (...args) {
    const node = create.apply(this, args);
    const ramp = node.gain.linearRampToValueAtTime.bind(node.gain);
    node.gain.linearRampToValueAtTime = function (value, time) {
      if (value >= 0.03) window.__alarmPulses.push({ value, time });
      return ramp(value, time);
    };
    return node;
  };
});
const idle = () => page.waitForFunction(() => {
  const input = document.querySelector('.question-input');
  return input && !input.disabled && /自由入力/.test(document.querySelector('.input-hint')?.textContent ?? '');
}, null, { timeout: 20000 });
try {
  await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: '尋問を開始する' }).click();
  await page.locator('.question-input').waitFor({ state: 'visible', timeout: 20000 });
  await idle();
  const box = await page.locator('.vitals-panel .vital-ecg').boundingBox();
  assert.ok(box.width >= 300 && box.height >= 135 && box.y < 400, JSON.stringify(box));
  const head1 = await page.locator('.vitals-panel canvas').getAttribute('data-sweep');
  await page.waitForTimeout(500);
  const head2 = await page.locator('.vitals-panel canvas').getAttribute('data-sweep');
  assert.ok(Number(head2) > Number(head1), 'ECG writes from left to right');
  const pixels = () => page.evaluate(() => {
    const c = document.querySelector('.vitals-panel canvas');
    return c.getContext('2d').getImageData(0, 0, c.width, c.height).data.reduce((a, v, i) => (a * 31 + v + i) % 1000003, 7);
  });
  const a = await pixels(); await page.waitForTimeout(350); assert.notEqual(await pixels(), a);
  const rates = new Set();
  for (let i = 0; i < 15; i++) { rates.add(await page.locator('.vital-value').innerText()); await page.waitForTimeout(400); }
  assert.ok(rates.size >= 2, [...rates].join(','));
  const names = [], looks = [], faces = [];
  for (let slot = 0; slot < 3; slot++) {
    await page.locator('.suspect-card').nth(slot).click();
    names.push(await page.locator('.suspect-card.selected .suspect-name').innerText());
    looks.push(await page.locator('.appearance-line').innerText());
    faces.push(await page.locator('.stage-main-character .pixel-character').getAttribute('data-portrait'));
  }
  assert.equal(new Set(names).size, 3); assert.equal(new Set(looks).size, 3); assert.equal(new Set(faces).size, 3, 'three different portrait sheets: '+faces.join(','));
  assert.ok(faces.every(f=>!['peach','blue'].includes(f)), 'misaligned sheets are not used');
  await page.waitForTimeout(500); await page.screenshot({ path: 'tests/artifacts/cast.png' });
  await page.locator('.suspect-card').nth(0).click(); await idle();
  await page.route('**/api/game/ask', async route => {
    const res = await route.fetch(); const json = await res.json();
    json.plan.delay = 800;
    json.plan.pre = [{ expr: 'normal', ms: 600 }, { expr: 'anxiety', ms: 500 }];
    json.plan.alert = { kind: 'lie', reason: '発言の矛盾を検知', at: 'answer', peakBpm: 118 };
    json.plan.glitch = 3;
    json.plan.bio = { ...json.plan.bio, bpm: 118, hrv: 0.3, ecg: 'glitched', stress: 0.9, flat: false };
    const saved = json.messages.find(m => m.id === json.answerId);
    if (saved) { saved.timeline = json.plan; saved.bio = json.plan.bio; }
    await route.fulfill({ response: res, json });
  });
  await page.evaluate(() => {
    window.__glitchLog = [];
    new MutationObserver(list => { for (const m of list) if (m.attributeName === 'data-glitch') window.__glitchLog.push({ t: performance.now(), level: m.target.getAttribute('data-glitch') }); })
      .observe(document.body, { attributes: true, subtree: true, attributeFilter: ['data-glitch'] });
  });
  await page.locator('.question-input').fill('昨日の21時、どこにいた？');
  await page.locator('.question-input').press('Enter');
  await page.getByRole('button', { name: '全文を表示' }).waitFor({ state: 'visible' });
  assert.equal(await page.locator('.alert-banner').count(), 0, 'Peak is not leaked before the reaction');
  await page.getByRole('button', { name: '全文を表示' }).click();
  const banner = page.locator('.vitals-panel .alert-banner'); await banner.waitFor({ state: 'visible' });
  assert.match(await banner.innerText(), /BPM急上昇.*RED ALERT/);
  assert.ok(await page.locator('.vital-value.alerting').count());
  assert.ok(await page.locator('.red-flash').count());
  assert.equal(await page.locator('.interrogation-stage.alert-stage').count(), 1);
  await page.waitForFunction(() => window.__glitchLog.length >= 2, null, { timeout: 3000 });
  const log = await page.evaluate(() => window.__glitchLog);
  assert.equal(log[0].level, '3'); assert.equal(log[1].level, null);
  const glitchDuration = log[1].t - log[0].t;
  assert.ok(glitchDuration >= 120 && glitchDuration <= 500, `${glitchDuration}ms`);
  assert.equal(await page.evaluate(() => window.__alarmPulses.length), 3, 'A single warning schedules three audio pulses');
  await page.screenshot({ path: 'tests/artifacts/alert.png' });
  await page.waitForFunction(() => !document.querySelector('.alert-banner'), null, { timeout: 3500 });
  assert.equal(await page.locator('.red-flash').count(), 0, 'Flash is removed, not a stale overlay');
  await page.getByRole('button', { name: 'すべての記録' }).click();
  assert.match(await page.getByRole('dialog').innerText(), /RED ALERT/);
  assert.match(await page.getByRole('dialog').innerText(), /映像が一瞬乱れた/);
  await page.getByRole('button', { name: '閉じる', exact: true }).click();

  // A mute setting silences later warnings. Changing actor cancels pending effects.
  await page.getByRole('button', { name: '効果音をオフにする' }).click();
  await idle();
  await page.locator('.question-input').fill('さっきの証言と矛盾していない？');
  await page.locator('.question-input').press('Enter');
  await page.getByRole('button', { name: '全文を表示' }).waitFor({ state: 'visible' });
  await page.getByRole('button', { name: '全文を表示' }).click();
  await banner.waitFor({ state: 'visible' });
  await page.locator('.suspect-card').nth(1).click();
  await page.waitForTimeout(350);
  assert.equal(await page.locator('.alert-banner').count(), 0);
  assert.equal(await page.locator('.red-flash').count(), 0);
  assert.equal(await page.locator('[data-glitch]').count(), 0);
  assert.equal(await page.evaluate(() => window.__alarmPulses.length), 3, 'Muted warning does not schedule sound');
  await page.unroute('**/api/game/ask');

  await page.setViewportSize({ width: 390, height: 844 });
  await page.reload({ waitUntil: 'networkidle' }); await page.locator('.question-input').waitFor();
  const compact = page.locator('.compact-monitor canvas'); await compact.waitFor({ state: 'visible' });
  const mobileBox = await compact.boundingBox(); assert.ok(mobileBox.width > 300 && mobileBox.height >= 60);
  assert.equal(await page.evaluate(() => document.documentElement.scrollWidth > innerWidth), false);
  const inputBox = await page.locator('.question-input').boundingBox(); assert.ok(inputBox.y + inputBox.height <= 844);
  await page.screenshot({ path: 'tests/artifacts/mobile-fx.png' });

  // Reduced-motion users get the information without flashing or full-screen pulses.
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.reload({ waitUntil: 'networkidle' }); await idle();
  await page.route('**/api/game/ask', async route => {
    const res = await route.fetch(); const json = await res.json();
    json.plan.alert = { kind: 'shaken', reason: '強い動揺を検知', at: 'reaction', peakBpm: 108 };
    json.plan.glitch = 1; json.plan.bio.bpm = 108;
    await route.fulfill({ response: res, json });
  });
  await page.locator('.question-input').fill('本当に人間なの？'); await page.locator('.question-input').press('Enter');
  await page.getByRole('button', { name: '全文を表示' }).waitFor({ state: 'visible' });
  await page.getByRole('button', { name: '全文を表示' }).click();
  await page.locator('.compact-monitor .alert-banner').waitFor({ state: 'visible' });
  assert.equal(await page.locator('.compact-monitor .alert-banner').evaluate(el => getComputedStyle(el).animationName), 'none');
  if (await page.locator('.red-flash').count()) assert.equal(await page.locator('.red-flash').evaluate(el => getComputedStyle(el).display), 'none');
  assert.equal(issues.length, 0, issues.join('\n'));
  console.log(JSON.stringify({ passed: true, names, looks, bpmSamples: [...rates], glitchDuration: Math.round(glitchDuration), alarmPulses: 3, skippedReactionVerified: true, scopedEffectsVerified: true, reducedMotionVerified: true }, null, 2));
} finally {
  await browser.close();
}
