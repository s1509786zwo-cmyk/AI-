import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync } from 'node:fs';
import { generateCast,generateCharacter,publicCharacter } from '../src/lib/engine/chargen';
import { classifyQuestion } from '../src/lib/engine/classify';
import { generateReply,emptyState,react } from '../src/lib/engine/generate';
import { ART_STYLES,ACTIVE_STYLES } from '../src/lib/engine/chargen';

function setup(){const c=generateCharacter({portrait:'noir'});c.speechId='polite';return{c,state:emptyState()};}
function ask(set:ReturnType<typeof setup>,q:string,isAI=false){const s=set.state.chars['1'];return generateReply(set.c,q,classifyQuestion(q,s.history.map(h=>h.question)),s,isAI,set.state);}
const text=(plan:ReturnType<typeof ask>)=>plan.segments.map(s=>s.text).join('');

test('Question topics do not collapse into generic personal lines',()=>{
  for(const [q,topic] of [['名前は？','name'],['好きな食べ物は？','favorite_food'],['昨日何食べた？','dinner'],['家族は何人？','family'],['趣味は？','hobby'],['その時誰といた？','companion'],['本当に？','reconfirm'],['なんでそんなに詳しく覚えているの？','precision'],['犯人のことをどう思う？','crime_opinion']])assert.equal(classifyQuestion(q).topic,topic,q);
});
test('Generated identities and facts are different; both genders represented',()=>{
  for(let i=0;i<25;i++){const c=generateCast();assert.equal(new Set(c.map(x=>x.name)).size,3);assert.equal(new Set(c.map(x=>x.look.portrait)).size,3);assert.ok(c.some(x=>x.gender==='f'));assert.ok(c.some(x=>x.gender==='m'));}
});
test('Answers really use the named character and individual facts',()=>{
  const s=setup();assert.match(text(ask(s,'名前は？')),new RegExp(s.c.name));assert.ok(text(ask(s,'好きな食べ物は？')).includes(s.c.profile.favoriteFood));assert.ok(text(ask(s,'趣味は？')).includes(s.c.profile.hobby));assert.ok(text(ask(s,'昨日何食べた？')).includes(s.c.profile.dinner));assert.ok(text(ask(s,'家族は何人？')).includes(String(s.c.profile.family.length+1)));
});
test('Follow-up questions refer to the actual previous answer and location',()=>{
  const s=setup();const before=text(ask(s,'昨日の21時どこにいた？'));const reconfirm=text(ask(s,'本当に？'));assert.ok(reconfirm.includes(before.slice(0,30)));assert.ok(text(ask(s,'その時誰といた？')).includes(s.c.profile.schedule.night.location));
});
test('Invented quotation is not admitted as a previous testimony',()=>{
  const s=setup();ask(s,'昨日の21時どこにいた？');const response=text(ask(s,'さっき「火星にいた」って言ったよね？'));assert.ok(response.includes('火星にいた'));assert.ok(response.includes('まだ話していません')||response.includes('言ってない'));
});
test('Repeated questions keep character facts and change reactions',()=>{
  const s=setup();ask(s,'好きな食べ物は？');const repeat=ask(s,'好きな食べ物は？');assert.ok(text(repeat).includes(s.c.profile.favoriteFood));assert.equal(repeat.mainExpr,'confusion');assert.equal(s.state.chars['1'].questionCount,2);
});
test('Unknown questions are acknowledged and do not stop the game',()=>{
  const s=setup();const p=ask(s,'宇宙の終わりはいつ？');assert.ok(text(p).includes('宇宙の終わり'));assert.equal(s.state.chars['1'].questionCount,1);assert.ok(p.pre.length>0);
});
test('Appearance questions match the portrait rather than unrelated personal facts',()=>{
  const s=setup();assert.equal(classifyQuestion('なんでメガネをかけてるの？').topic,'glasses');assert.ok(text(ask(s,'メガネをかけてるの？')).includes('メガネ'));assert.ok(text(ask(s,'髪はどんな色？')).includes('黒髪'));assert.ok(text(ask(s,'自己紹介して')).includes(s.c.name));assert.equal(classifyQuestion('本当に家にいたの？').topic,'location');
});
test('Every portrait and all sixteen frames exist, secrets are not public',()=>{
  const casts=generateCast();for(const c of casts){assert.equal('aiStyle' in publicCharacter(c),false);assert.equal('profile' in publicCharacter(c),false);for(let i=0;i<16;i++)assert.ok(existsSync(`public/portraits/${c.look.portrait}/${i}.webp`));}
});

const rate=(n:number,f:()=>boolean)=>{let k=0;for(let i=0;i<n;i++)if(f())k++;return k/n;};
test('Humans spike and alert under pressure; fakers often look normal (no single giveaway)',()=>{
  const insult=classifyQuestion('お前はクズだ');
  const human=generateCharacter({portrait:'peach'});human.persona='gentle';
  const humanAlert=rate(400,()=>!!react(human,insult,false,false).alert);
  assert.ok(humanAlert>.8,'humans under insult alert most of the time: '+humanAlert);
  const humanBpm=rate(400,()=>react(human,insult,false,false).bio.bpm>=human.restBpm+15);
  assert.ok(humanBpm>.95);
  const mech=generateCharacter({portrait:'peach'});mech.aiStyle='mechanical';
  const flat=rate(1000,()=>react(mech,insult,true,false).bio.flat);
  assert.ok(flat>.3&&flat<.8,'mechanical fakers are flat only some of the time: '+flat);
  const mimic=generateCharacter({portrait:'peach'});mimic.aiStyle='humanlike';
  const steady=rate(1000,()=>react(mimic,insult,true,false).bio.ecg==='steady');
  assert.ok(steady>.2,'fakers sometimes show a completely normal ECG: '+steady);
  assert.ok(rate(1000,()=>react(mech,insult,true,false).bio.ecg==='steady')>.08);
  const emotive=generateCharacter({portrait:'peach'});emotive.aiStyle='emotive';
  const fakerAlert=rate(1000,()=>!!react(emotive,insult,true,false).alert);
  assert.ok(fakerAlert>.1&&fakerAlert<.8,'fakers alert sometimes: '+fakerAlert);
});
test('Alerts follow lies, evidence and contradictions; glitches are rare and not exclusive to fakers',()=>{
  const human=generateCharacter({portrait:'ash'});
  assert.equal(react(human,classifyQuestion('昨日の21時どこにいた？'),false,true).alert?.kind,'lie');
  const evidence=classifyQuestion('防犯カメラの記録があるが？');
  assert.equal(evidence.topic,'evidence');
  assert.ok(rate(300,()=>react(human,evidence,false,false).alert?.kind==='evidence')>.9);
  const faker=generateCharacter({portrait:'ash'});faker.aiStyle='humanlike';
  const casual=classifyQuestion('好きな食べ物は？');
  assert.ok(rate(2000,()=>react(faker,casual,true,false).glitch>0)<.06,'no constant glitching on harmless questions');
  const pressure=classifyQuestion('お前が犯人だろう');
  const fakerGlitch=rate(2000,()=>react(faker,pressure,true,false).glitch>0);
  assert.ok(fakerGlitch>.05&&fakerGlitch<.6,'fakers glitch only sometimes: '+fakerGlitch);
  assert.ok(rate(3000,()=>react(human,pressure,false,true).glitch>0)>.05,'humans can show interference too');
  assert.equal(react(human,pressure,false,false).bio.ecg,'erratic');
});
test('Suspects are three genuinely different people — different art family, hair, face and outfit; no stretching, no overlays',()=>{
  for(let i=0;i<300;i++){
    const cast=generateCast();const arts=cast.map(c=>ART_STYLES.find(a=>a.id===c.look.portrait)!);
    assert.equal(new Set(arts.map(a=>a.family)).size,3,'three different visual families');
    assert.equal(new Set(arts.map(a=>a.hairText)).size,3,'three different hairstyles');
    assert.equal(new Set(arts.map(a=>a.faceText)).size,3,'three different faces');
    assert.equal(new Set(arts.map(a=>a.outfitText)).size,3,'three different outfits');
    assert.ok(arts.some(a=>a.gender==='f')&&arts.some(a=>a.gender==='m'));
    assert.ok(arts.every(a=>!a.retired),'misaligned sheets are never used for new cases');
    assert.equal(new Set(cast.map(c=>c.look.idleStyle)).size,3,'three different demeanors');
    assert.ok(cast.every(c=>!c.look.hue&&!c.look.build&&!(c.look.features?.length)&&!c.look.wardrobe),'no recolor, no face stretching, no painted-on features');
    assert.equal(new Set(cast.map(c=>c.appearance)).size,3);
  }
  assert.ok(ACTIVE_STYLES.length>=7);
});
test('Appearance is independent of who the faker is, and the feature question is answered in character',()=>{
  const counts=[0,0,0];for(let i=0;i<600;i++){const c=generateCast();const faker=Math.floor(Math.random()*3);const idx=c.findIndex(x=>x.look.idleStyle==='tired');if(idx===faker)counts[0]++;}
  assert.ok(counts[0]>150&&counts[0]<250,'tired-looking suspects are the faker about a third of the time');
  const s=setup();assert.ok(text(ask(s,'そのピアスは？')).length>0);
  assert.ok(text(ask(setup(),'メガネをかけてるの？')).includes('メガネ'));
});
