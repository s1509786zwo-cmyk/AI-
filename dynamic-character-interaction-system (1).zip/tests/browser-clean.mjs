// 表示されたキャラクターが「原画そのまま」であり、ノイズや引き伸ばしが無いことを画素単位で確認する
import { chromium } from '@playwright/test';
import assert from 'node:assert/strict';
import sharp from 'sharp';
import { mkdir } from 'node:fs/promises';
await mkdir('tests/artifacts', { recursive: true });
const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
const page = await (await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'reduce' })).newPage();
const issues = []; page.on('pageerror', e => issues.push(e.message));
try {
  await page.goto('http://127.0.0.1:3000', { waitUntil: 'networkidle' });
  await page.getByRole('button', { name: '尋問を開始する' }).click();
  await page.locator('.question-input').waitFor({ state: 'visible', timeout: 20000 });
  await page.waitForFunction(() => { const i = document.querySelector('.question-input'); return i && !i.disabled; }, null, { timeout: 20000 });
  const report = [];
  for (let slot = 0; slot < 3; slot++) {
    await page.locator('.suspect-card').nth(slot).click();
    await page.waitForTimeout(600);
    const portrait = await page.locator('.stage-main-character .pixel-character').getAttribute('data-portrait');
    const frame = await page.evaluate(() => {
      const c = document.querySelector('.stage-main-character canvas');
      return Array.from(c.getContext('2d').getImageData(0, 0, 256, 256).data);
    });
    const expr = await page.locator('.stage-main-character .pixel-character').getAttribute('aria-label');
    const frameIndex = /眠そう/.test(expr) ? 11 : 0;
    const { data: original } = await sharp(`public/portraits/${portrait}/${frameIndex}.webp`).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    // 描画結果と原画の差分（アルファ>0の画素のみ）。整数オフセット（呼吸・うつむき）を許容して最小差分を探す
    let best = Infinity;
    for (let dy = -6; dy <= 6; dy++) {
      let diff = 0, n = 0;
      for (let y = 8; y < 248; y++) for (let x = 8; x < 248; x++) {
        const sy = y - dy; if (sy < 0 || sy >= 256) continue;
        const i = (y * 256 + x) * 4, j = (sy * 256 + x) * 4;
        if (original[j + 3] < 128 && frame[i + 3] < 128) continue;
        n++;
        diff += Math.abs(original[j] - frame[i]) + Math.abs(original[j + 1] - frame[i + 1]) + Math.abs(original[j + 2] - frame[i + 2]) + Math.abs(original[j + 3] - frame[i + 3]);
      }
      best = Math.min(best, diff / Math.max(1, n));
    }
    report.push({ slot: slot + 1, portrait, meanDiffPerPixel: Number(best.toFixed(3)) });
    assert.ok(best < 1.5, `Slot ${slot + 1} (${portrait}) is drawn pixel-identical to the source art (mean diff ${best.toFixed(2)})`);
  }
  assert.equal(new Set(report.map(r => r.portrait)).size, 3, 'three different portrait sheets');
  await page.screenshot({ path: 'tests/artifacts/clean-cast.png' });
  assert.equal(issues.length, 0, issues.join('\n'));
  console.log(JSON.stringify({ passed: true, report }, null, 2));
} finally { await browser.close(); }
