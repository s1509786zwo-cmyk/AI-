import sharp from 'sharp';
import { mkdir, writeFile } from 'node:fs/promises';

const ids = ['lilac', 'peach', 'mint', 'ivory', 'ash', 'blue', 'rose', 'noir', 'analyst'];
const manifest = [];
await mkdir('public/portraits', { recursive: true });
for (const id of ids) {
  const input = `public/characters/${id}.png`;
  const meta = await sharp(input).metadata();
  const cell = Math.floor(meta.width / 4);
  await mkdir(`public/portraits/${id}`, { recursive: true });
  for (let frame = 0; frame < 16; frame++) {
    const { data, info } = await sharp(input).extract({ left: (frame % 4) * cell, top: Math.floor(frame / 4) * cell, width: cell, height: cell }).resize(256, 256, { kernel: 'nearest' }).ensureAlpha().raw().toBuffer({ resolveWithObject: true });
    const w = info.width;
    // Remove only the connected flat background, preserving enclosed dark details.
    const samples = [[3,3], [w-4,3], [3,w-4], [w-4,w-4], [w/2,3]].map(([x,y]) => {
      const p = (Math.floor(y) * w + Math.floor(x)) * 4;
      return [data[p], data[p+1], data[p+2]];
    });
    const bg = [0,1,2].map(c => samples.map(s=>s[c]).sort((a,b)=>a-b)[2]);
    const seen = new Uint8Array(w*w);
    const queue = [];
    for (let i=0;i<w;i++) queue.push(i, (w-1)*w+i, i*w, i*w+w-1);
    let head = 0;
    while (head < queue.length) {
      const p = queue[head++];
      if (p < 0 || p >= w*w || seen[p]) continue;
      seen[p] = 1;
      const at=p*4;
      const dist=Math.hypot(data[at]-bg[0], data[at+1]-bg[1], data[at+2]-bg[2]);
      if (dist > 28) continue;
      data[at+3]=0;
      const x=p%w, y=Math.floor(p/w);
      if (x>0) queue.push(p-1);
      if (x<w-1) queue.push(p+1);
      if (y>0) queue.push(p-w);
      if (y<w-1) queue.push(p+w);
    }
    await sharp(data,{ raw:{ width:w, height:w, channels:4 } }).webp({ lossless:true }).toFile(`public/portraits/${id}/${frame}.webp`);
  }
  manifest.push({ id, frames: 16, resolution:256 });
  console.log(`${id}: 16 transparent portrait frames prepared`);
}
await writeFile('public/portraits/manifest.json', JSON.stringify(manifest));
